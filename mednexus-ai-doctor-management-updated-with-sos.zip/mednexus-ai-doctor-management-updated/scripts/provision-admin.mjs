#!/usr/bin/env node
import { DatabaseSync } from "node:sqlite";
import { randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { createInterface } from "node:readline";
import { execFileSync } from "node:child_process";
import { chmodSync, writeFileSync } from "node:fs";

const dbPath = process.env.MEDNEXUS_SQLITE_PATH || new URL("../.data/mednexus.sqlite", import.meta.url).pathname;
const temporary = process.argv.includes("--temporary");
const arg = name => { const index = process.argv.indexOf(name); return index >= 0 ? process.argv[index + 1] : ""; };

function ask(prompt, hidden = false) {
  return new Promise((resolve, reject) => {
    const rl = createInterface({ input: process.stdin, output: process.stderr, terminal: true });
    if (hidden) execFileSync("stty", ["-echo"], { stdio: ["inherit", "inherit", "inherit"] });
    rl.question(prompt, answer => {
      if (hidden) execFileSync("stty", ["echo"], { stdio: ["inherit", "inherit", "inherit"] });
      rl.close();
      if (hidden) process.stderr.write("\n");
      resolve(answer);
    });
    rl.on("SIGINT", () => {
      if (hidden) execFileSync("stty", ["echo"], { stdio: ["inherit", "inherit", "inherit"] });
      rl.close();
      reject(new Error("Cancelled."));
    });
  });
}

const emailPattern = /^[^@\s]+admin@medicarehospital\.com$/i;
const hashPassword = password => {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64);
  return `scrypt$${salt}$${derived.toString("hex")}`;
};

try {
  if (!temporary && !process.stdin.isTTY) throw new Error("This command must run from an authorized interactive terminal.");
  const db = new DatabaseSync(dbPath);
  const adminCount = Number(db.prepare("SELECT COUNT(*) AS count FROM administrators").get().count);
  if (adminCount > 0) throw new Error("Administrator provisioning has already been completed.");
  const name = (temporary ? arg("--name") : await ask("Administrator full name: ")).trim();
  const email = (temporary ? arg("--email") : await ask("Administrator email: ")).trim().toLowerCase();
  if (name.length < 2) throw new Error("Administrator name is invalid.");
  if (!emailPattern.test(email)) throw new Error("Email must match nameadmin@medicarehospital.com.");
  const password = temporary ? randomBytes(32).toString("base64url") : await ask("Administrator password: ", true);
  const confirmation = temporary ? password : await ask("Confirm password: ", true);
  if (password.length < 8) throw new Error("Password must be at least 8 characters.");
  if (password !== confirmation) throw new Error("Passwords do not match.");

  const openId = `local_admin_${randomUUID()}`;
  const now = new Date().toISOString();
  const passwordHash = hashPassword(password);
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = db.prepare(`INSERT INTO users (open_id,name,email,password_hash,login_method,role,created_at,updated_at,last_signed_in) VALUES (?,?,?,?,?,?,?,?,?)`)
      .run(openId, name, email, passwordHash, "password", "admin", now, now, now);
    db.prepare("INSERT INTO administrators (user_id,email) VALUES (?,?)").run(Number(result.lastInsertRowid), email);
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
  if (temporary) {
    const credentialsFile = arg("--credentials-file") || "/home/ubuntu/.mednexus-admin-credentials";
    writeFileSync(credentialsFile, `Email: ${email}\nTemporary password: ${password}\n`, { mode: 0o600 });
    chmodSync(credentialsFile, 0o600);
    console.log(`Administrator account created. Private credentials saved to ${credentialsFile}.`);
  } else {
    console.log("Administrator account created. You may now sign in through the website.");
  }
} catch (error) {
  console.error(`Administrator provisioning failed: ${error instanceof Error ? error.message : "unknown error"}`);
  process.exitCode = 1;
}
