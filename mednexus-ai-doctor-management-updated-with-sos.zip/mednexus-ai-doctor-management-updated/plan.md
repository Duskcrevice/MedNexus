# MedRisq AI — Implementation Plan

## Scope

Build a polished, responsive healthcare operations console and public entry experience for **MedRisq AI — One Connected Network. Safer Medicines. Smarter Emergency Response.** The implementation prioritizes three complete demo workflows: medicine verification with evidence-based risk indicators, resource discovery with freshness awareness, and emergency resource exchange from request through receipt. All records are synthetic demo data and explicitly labelled.

## Implementation approach

- Keep the initialized React + TypeScript + Vite frontend, Express server, tRPC router, and Drizzle MySQL schema.
- Extend the schema with organizations, resources, medicine registry records, verification checks, emergency requests, offers/transfers, alerts, and audit events; include a migration for the new tables.
- Add server-side tRPC procedures for dashboard data, resource search, medicine verification, request creation, deterministic supplier matching, transfer state transitions, alert acknowledgement, and demo reset. Use backend validation and role checks for sensitive mutations.
- Seed a fictional district network with hospitals, pharmacies, medicine examples, inventory freshness, active alerts, and transfers in multiple stages. If the managed database is unavailable during local preview, keep the UI functional with a deterministic in-memory demo store and surface the demo-mode notice.
- Build the UI as a single operations shell with route-aware pages: overview, resources, medicine verification, emergency exchange, inventory, alerts, and audit trail. Provide a controlled role switch for demo personas and make the central workflow demonstrable without external credentials.
- Keep mapping and AI integrations simulated/optional: show list view by default and distinguish authoritative registry checks from AI observations.
- Add `public/manus-routes.json`, application metadata, and a concise README covering setup, environment variables, demo mode, integrations, known limitations, and actual validation results.

## Design system

### Design Movement

Editorial clinical operations: a calm, information-dense healthcare control room influenced by modern Swiss editorial systems and hospital wayfinding rather than generic SaaS dashboards.

### Core Principles

1. **Signal over decoration** — prioritise status, freshness, evidence, and next action.
2. **Human-readable trust** — every risk or match includes the reason and data source.
3. **Operational calm** — use a pale canvas, firm navy type, and a restrained teal signature color.
4. **Progressive disclosure** — surface the decision first, with evidence and audit trail one level deeper.

### Color Philosophy

Warm off-white and cool mist backgrounds reduce visual fatigue; deep ink/navy establishes clinical seriousness; teal marks trusted, actionable, or synchronized states; amber and coral are reserved for attention and risk. No gradients or decorative glow effects.

### Layout Paradigm

A persistent left rail anchors the product identity and active workflow. The main area uses an asymmetric editorial layout: a wide decision surface beside a narrower evidence rail, then full-width tables/timelines where operational detail benefits from breathing room.

### Signature Elements

- A small teal “signal dot” system for freshness and sync status.
- Evidence strips that pair a decision label with source, timestamp, and reason.
- An audit timeline with a strong vertical rule and compact event markers.

### Interaction Philosophy

Actions should read like safe operational handoffs: clear verb labels, explicit confirmation states, disabled invalid transitions, and concise toasts. Destructive or irreversible operations require a clear second step. Role switching is explicit and always visible.

### Animation

Use short 160–220ms opacity/translate transitions for panels, tab changes, and status updates. Avoid loops except for a subtle sync pulse while a mutation is in flight. Respect reduced-motion preferences.

### Typography System

Use a clean sans-serif stack for the application body and a slightly condensed system stack for numerals and metadata. Oversized editorial section titles are reserved for the landing page; operations pages use compact 12–30px hierarchy with tabular numerals.

### Brand Essence

A trustworthy district-level healthcare coordination layer for people who need to verify, find, and move essential resources before time runs out. **Calm, exacting, connective.**

### Brand Voice

Headlines are direct and human; CTAs name the next safe action; microcopy states limitations plainly.

- “Find the next available resource, with freshness in view.”
- “A registry match is evidence — not a guarantee.”

### Wordmark & Logo

A custom wordmark treatment pairs “MedRisq” in strong ink with a compact teal crosshair/signal mark: a four-corner bracket around a central dot, representing verification and coordination. In-app, the mark appears as a 28px rounded square with a teal center signal and two offset ink brackets.

### Signature Brand Color

**Signal teal — #0C8B83** — ownable, clinical, and legible against the warm paper background.

## Project structure

- `client/src/App.tsx`: route shell and page composition.
- `client/src/pages/Home.tsx`: public-facing overview / landing entry.
- `client/src/pages/Operations.tsx`: authenticated-style demo operations console and workflow pages.
- `client/src/index.css`: design tokens, responsive layout, tables, state indicators, and shell styles.
- `server/routers.ts`: typed API surface and state transitions.
- `server/db.ts`: database access plus demo-store fallback helpers.
- `drizzle/schema.ts` and `drizzle/migrations/`: durable entities and migration.
- `public/manus-routes.json`: route manifest for the managed preview.
- `README.md`: setup, demo credentials/personas, environment variables, validation, and limitations.

## Material constraints and limitations

No real healthcare API, map provider, or AI key is required for the demo. Availability is synthetic and not live; every resource and medicine result must show that limitation. Registry matching and transfer state transitions remain deterministic. AI-assisted observations are represented as optional explanatory text only and never certify authenticity or approve a transfer.

## Upgrade: connected innovation lab

The existing operations shell is extended with a route-aware Innovation Lab rather than replacing the current workflows. Five tabbed modules share one synthetic regional network: a five-hospital digital twin with 6/12/24-hour shortage forecasts, a 15-record medicine trust passport index, capability-based emergency referral matching, an inter-hospital medicine rescue table with storage and verification gates, and a disaster swarm simulator with severity-driven projections. New server procedures own simulation, referral, and rescue state transitions; the existing resource, verification, exchange, alert, and audit procedures remain intact. All map, forecast, registry, and hospital feeds are explicitly demo adapters.


## Landing launch direction

The public homepage is now a cinematic media-launch surface rather than a dashboard preview. Its design movement is **editorial systems cinema**: oversized compressed headlines, deep navy negative space, teal signal light, orbital network geometry, and scroll-staged chapters. The layout uses a split hero, floating CSS-only network visualization, a horizontal signal band, sticky chapter cards, and an evidence-to-approval proof panel. Motion is restrained and purposeful: CSS keyframes handle the orbit float and core pulse, CSS view timelines reveal sections when supported, and reduced-motion users receive a static equivalent. The brand essence remains “the operating layer between a healthcare warning and a safe handoff,” with a voice that is direct, evidence-led, and calm under pressure.


## Reference-inspired refinement

The landing hero borrows the reference’s composition principles rather than its copy or asset: a quiet nav, edge-to-edge human healthcare scene, dark green readability overlay, oversized editorial headline, pale proof band, and compact CTA set. MedRisq-specific signal tags sit on top of the original image to connect the emotional human scene to hospital capacity, medicine verification, and evidence-ranked handoffs. The source image is an original generated campaign asset and remains clearly separate from the synthetic-data disclaimer.



## Security-first hospital platform upgrade

The next implementation phase converts the controlled demo into a real role-separated hospital platform while preserving the existing MedRisq AI innovation console. The backend uses the existing Manus session identity plus managed MySQL records for portal membership, staff applications, patient profiles, appointments, service requests, notifications, and audit events. Public enrollment may create a patient profile or a pending staff application, but it never grants staff/admin privileges. Staff access is determined server-side from an approved, non-suspended staff application; admin actions require the existing server-side admin role and cannot be created through public registration. Patient procedures scope every query by the authenticated user; staff procedures scope by approved organization membership and permission set. Client portals are separate from the demo console and direct protected URL/API requests are rejected by protected procedures.

The implementation adds a portal workspace with separate patient, approved-staff, pending-staff, and restricted admin views, server-validated appointment and service-request workflows, approval/rejection/suspension transitions, logout and clear unauthorized states, and append-only security audit events. The current synthetic MedRisq AI console remains available for the hackathon demonstration but its persona picker is not treated as an authorization boundary; the new portals and their APIs are the secure path for account-scoped workflows. All patient data remains synthetic and the UI states that production privacy/compliance review is still required.


## Patient doctor directory

The protected patient portal now adds a care-team directory before appointment booking. Four original portrait assets are delivered through project-managed storage and shown as responsive doctor cards with name, specialty, experience, rating/review count, languages, hospital, and next availability. Selecting a card sets the appointment hospital and clinician fields, and the appointment request keeps the selected doctor in the existing persistent workflow. The visual treatment stays within the existing clinical editorial system: soft neutral cards, teal verification accents, amber ratings, responsive grid-to-list behavior, and no decorative motion that competes with patient choices.


## Integrated Patient Portal routing

The patient workspace is now surfaced inside the main MedRisq application at `/app/patient`. Public landing navigation, the operations sidebar, and the role selector use the single label “Patient portal”; selecting it navigates within the MedRisq app rather than presenting a separate public-user destination. The previous `/portal` path remains only as a compatibility route for existing links.


## Embedded portal merge

The incoming portal archive contributed the final shell integration: Patient Portal is rendered by the Operations page for `/app/patient` and `/portal`, so the shared MedRisq sidebar, active Patient portal navigation, header context, and role control remain visible around the protected portal content. The standalone Portal component remains the content/workflow implementation, while `embedded-portal` styles adapt its login and authenticated layouts to the application frame.

## Patient, doctor, and staff access upgrade

The existing protected portal is extended with two distinct in-app entry paths: `/app/patient` for patient sign-in and `/app/staff` for doctor/staff sign-in or registration. Both remain inside the shared MedRisq operations shell, while the server resolves the authoritative role from the authenticated account and staff approval record. A client role selector does not grant privileges.

The patient dashboard keeps its existing profile, appointment, request, and notification workflows and adds ownership-scoped medical records and prescriptions. The approved-staff dashboard retains organization-scoped appointment/request actions and adds a validated prescription-upload workflow that targets only an authorized patient tied to an appointment in the staff member’s approved organization. Additive Drizzle/MySQL tables and migrations persist records and prescriptions; test mode continues using isolated in-memory state.

The doctor directory uses four realistic stock-photo portraits stored as project assets, mapped to the exact synthetic clinician names supplied by the user. Each card shows specialization, experience, rating/reviews, hospital, languages, availability, and a clear illustrative/synthetic-data note. Existing MedRisq operations, innovation, emergency exchange, medicine verification, and secure portal authorization boundaries remain intact.


## User-directed reference rebuild (2026-10-23)

The latest user-provided MEDNEXUS AI design image supersedes the earlier landing and operations-console visual direction. Retain the existing backend, schema, authentication and reusable protected portal workflows; remove the legacy operations console from the user-facing router rather than deleting its source or APIs. The reference-led frontend consists of a split mint landing/sign-in entry and a compact dark-navy sidebar shell for Patient, Doctor, Hospital Staff and Administrator workspaces. Use #062B38 navy, #0D9488 teal, #DFF5F0 mint, #EAF5FF light blue, white surfaces, rounded cards, clear headings, responsive behavior and the supplied reference's quick actions and dashboard composition.

`client/src/pages/Home.tsx` is the split landing experience; `client/src/pages/DashboardSuite.tsx` and `dashboard-suite.css` provide the four fictional preview personas and shared in-session flows; `client/src/pages/Portal.tsx` remains the protected account route and does not show hard-coded clinicians; `client/src/App.tsx` exposes only the redesigned top-level and protected portal routes; `client/public/manus-routes.json` is the served page-route list. Demo role selection is only a visual, fictional preview and grants no account authority. The urgent hackathon update below supersedes the earlier client-memory limitation: demo appointments, profiles, prescriptions and resource edits persist in browser localStorage for the same profile across refreshes, but are not shared across devices and are not private or authenticated. Sample clinicians are isolated in the explicit demo suite; the protected directory stays empty until an administrator-managed catalogue exists.

OAuth/identity-provider URL and durable database configuration were not recovered in this non-project session, and no working Google provider was verified. Therefore the live sign-in provider is shown as unavailable in preview; no claim is made that authentication, production storage or external healthcare integrations work. The protected portal's existing server-side authorization remains distinct from the open fictional preview. Outstanding administrator account provisioning/imports, full database-backed doctor/availability/consultation/review/resource models, file/OCR and medical-report processing, offline sync, and production end-to-end verification remain unimplemented and must not be described as complete.


## Urgent hackathon demo persistence (2026-10-23)

Supersede the earlier client-memory limitation without changing the existing interface, layout, theme, fonts, routes or application architecture. Keep the current React + TypeScript/Vite client and the existing four-role DashboardSuite. Implement a small `client/src/lib/demoStore.ts` browser-local store using versioned localStorage for fictional demo accounts, clinicians, appointments, availability blocks, consultation notes and prescriptions; all four role dashboards read/write this same store, which survives refresh in the same browser but is not shared across browsers/devices and is not secure production authentication or a clinical database. Seed only fictional admin/patient/staff demo identities; administrator-created doctors receive demo accounts and visible one-time fictional credentials. The doctor directory starts empty. Support CSV and Excel clinician import with validation and optional photo URLs; manual photo upload stores a resized data URL locally to reduce quota risk. Preserve all existing dashboard pages/actions, adding only the minimum login/availability/notes/upload controls needed to make the demo coherent. Do not add external OAuth/S3 services or claim live verification, stock or clinical integrations. Main folders/modules remain the existing `client/src/pages` UI, shared `client/src/lib` demo persistence, and existing server/schema untouched.


## Login and Patient Portal visual alignment (2026-10-23)

Update only the root login presentation and the Patient role presentation in the existing React/Vite application; retain the four-role demoStore and all existing server/tRPC authentication, APIs, data, appointment, prescription, availability, and feature workflows. Use the published MEDNEXUS login as the visual reference: split full-height dark-navy brand panel and white rounded secure-access card, with mint/teal accents, large headline, 2×2 role choices, existing local-demo credentials, and provider sign-in wired only to `isManusLoginConfigured()`/`startLogin()` (disabled with an honest explanation when unconfigured). Do not let visual role selection authorize protected actions. Scope the Patient-only portal refinements to existing patient components and styles; preserve all other role layouts and retain existing doctors/photos/records, with clear empty states where the current model lacks data. Keep the existing system architecture, routes, databases, and real-account access checks unchanged.


### Status after implementation

The landing page and Patient-only demo/authenticated Portal presentations have been updated. Existing login credential checks, OAuth `startLogin`, protected tRPC procedures, database schema, patient ownership rules and non-patient portal presentation remain unchanged. The local demo Patient directory filters active stored clinicians and verifies slots with existing collision logic; the authenticated Patient Portal filters only the existing server-managed directory and retains current account-scoped mutation calls. Typecheck, 20 automated tests, and the production build passed; browser review confirmed root login, local Patient dashboard, doctor search filtering and the unauthenticated protected-route gate. The protected profile/appointment mutation paths remain untestable until the existing auth provider is configured; mobile browser review remains pending.
