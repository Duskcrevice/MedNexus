# Doctor portrait sources

These portraits are used only as illustrative photos for synthetic clinician records in the MedRisq AI demo. The displayed names, ratings, specializations, hospitals, availability, medical records, and prescriptions are fictional demo data. Production use should verify the applicable stock-photo license and attribution requirements.

- `srikant-sharma.jpg` — search result titled “Doctor Headshot Images – Browse 540,940 Stock Photos, Vectors, and Video” (Dreamstime-style stock result); source image URL: https://files.manuscdn.com/search-media/310519664017814778/J35Z6spKuGxKOJQg0SEnQY/RmtMnPAjUZtH9UkCMzxPgE.jpg
- `om-mishra.jpg` — Pexels result titled “Doctor Headshot Videos, Download The BEST Free 4k Stock Video Footage”; source image URL: https://files.manuscdn.com/search-media/310519664017814778/J35Z6spKuGxKOJQg0SEnQY/qMyk5ALgDvzMQbkwmd9c5D.jpeg
- `michael-darvis.jpg` — free stock result titled “A Smiling Doctor with His Arms Crossed”; source image URL: https://files.manuscdn.com/search-media/310519664017814778/J35Z6spKuGxKOJQg0SEnQY/aKWmXGPfBpSreKb48wpJC4.jpeg
- `elena-fernandez.jpg` — Unsplash result titled “Doctor Smiling Pictures”; source image URL: https://files.manuscdn.com/search-media/310519664017814778/J35Z6spKuGxKOJQg0SEnQY/FyijzaLv3oMhw9q36F4TU8.jpg
