import Portal from "./Portal";
import { FormEvent, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import InnovationPage from "@/pages/InnovationPage";
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bell,
  Check,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  Clock3,
  Crosshair,
  FileCheck2,
  Filter,
  Hospital,
  LayoutDashboard,
  LifeBuoy,
  ListFilter,
  MapPin,
  Menu,
  PackageCheck,
  RefreshCcw,
  RotateCcw,
  ScanLine,
  Search,
  Send,
  ShieldAlert,
  ShieldCheck,
  Stethoscope,
  Truck,
  UserRound,
  X,
  type LucideIcon,
} from "lucide-react";
import type {
  Alert,
  DemoRole,
  DemoSnapshot,
  Match,
  Medicine,
  Resource,
} from "../../../server/demoStore";

type Page =
  | "overview"
  | "innovations"
  | "resources"
  | "verify"
  | "exchange"
  | "inventory"
  | "alerts"
  | "audit";

const navItems: { id: Page; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "innovations", label: "Innovation lab", icon: Crosshair },
  { id: "resources", label: "Find resources", icon: MapPin },
  { id: "verify", label: "Verify medicine", icon: ScanLine },
  { id: "exchange", label: "Emergency exchange", icon: LifeBuoy },
  { id: "inventory", label: "Inventory", icon: PackageCheck },
  { id: "alerts", label: "Alerts", icon: Bell },
  { id: "audit", label: "Audit trail", icon: ClipboardList },
];

const roleOptions: { value: DemoRole; label: string; description: string }[] = [
  {
    value: "hospital",
    label: "Hospital staff",
    description: "Report shortages and confirm receipts",
  },
  {
    value: "pharmacist",
    label: "Pharmacist",
    description: "Verify medicines and manage batches",
  },
  {
    value: "coordinator",
    label: "Emergency coordinator",
    description: "Approve offers and oversee transfers",
  },
  {
    value: "admin",
    label: "Administrator",
    description: "Review alerts, audit, and settings",
  },
  {
    value: "public",
    label: "Patient portal",
    description: "Access appointments and care requests",
  },
];

function pageFromPath(path: string): Page {
  const segment = path.split("/")[2] as Page | undefined;
  return navItems.some(item => item.id === segment)
    ? (segment as Page)
    : "overview";
}

function timeAgo(date?: string) {
  if (!date) return "Pending";
  const diff = Math.max(0, Date.now() - new Date(date).getTime());
  const minutes = Math.floor(diff / 60000);
  if (minutes < 2) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;
  return `${Math.floor(hours / 24)} d ago`;
}

function statusClass(value: string) {
  return value.toLowerCase().replace(/\s+/g, "-");
}

function MetricCard({
  label,
  value,
  change,
  direction,
  icon: Icon,
  tone,
}: {
  label: string;
  value: string | number;
  change: string;
  direction: "up" | "down" | "flat";
  icon: LucideIcon;
  tone: string;
}) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}>
        <Icon size={18} />
      </div>
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
      <div className={`metric-change ${direction}`}>
        {direction === "up" ? (
          <ArrowUpRight size={13} />
        ) : direction === "down" ? (
          <ArrowDownRight size={13} />
        ) : (
          <Activity size={13} />
        )}{" "}
        {change}
      </div>
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  copy,
}: {
  icon: typeof Search;
  title: string;
  copy: string;
}) {
  return (
    <div className="empty-state">
      <div className="empty-icon">
        <Icon size={21} />
      </div>
      <strong>{title}</strong>
      <p>{copy}</p>
    </div>
  );
}

function OverviewPage({
  snapshot,
  setPage,
}: {
  snapshot: DemoSnapshot;
  setPage: (page: Page) => void;
}) {
  const criticalAlerts = snapshot.alerts
    .filter(alert => !alert.acknowledged)
    .slice(0, 3);
  const activeRequest = snapshot.requests.find(
    request =>
      request.status === "awaiting_approval" || request.status === "matched"
  );
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Monday · 12 October 2026 · 09:42</div>
          <h1>Morning operations brief</h1>
          <p>One view of the signals that need a human decision today.</p>
        </div>
        <button
          className="button button-secondary small"
          onClick={() => toast.success("Workspace data is already current")}
        >
          <RefreshCcw size={14} /> Refresh data
        </button>
      </div>
      <div className="metric-grid">
        <MetricCard
          label="Open alerts"
          value={snapshot.metrics.openAlerts.toString().padStart(2, "0")}
          change="2 critical"
          direction="up"
          icon={Bell}
          tone="coral"
        />
        <MetricCard
          label="Active requests"
          value={snapshot.metrics.activeRequests.toString().padStart(2, "0")}
          change="1 awaiting approval"
          direction="flat"
          icon={LifeBuoy}
          tone="amber"
        />
        <MetricCard
          label="Resources tracked"
          value={snapshot.metrics.resourcesTracked.toString().padStart(2, "0")}
          change="3 fresh reports"
          direction="up"
          icon={MapPin}
          tone="teal"
        />
        <MetricCard
          label="Checks today"
          value={snapshot.metrics.verifiedToday}
          change="5 need review"
          direction="down"
          icon={ScanLine}
          tone="navy"
        />
      </div>
      <section className="overview-innovation-strip">
        <div className="overview-innovation-heading">
          <div>
            <div className="eyebrow">Five connected innovations</div>
            <strong>From forecast to handoff</strong>
          </div>
          <button
            className="text-button"
            onClick={() => setPage("innovations")}
          >
            Open innovation lab <ArrowRight size={14} />
          </button>
        </div>
        <div className="overview-innovation-cards">
          <button onClick={() => setPage("innovations")}>
            <Crosshair size={16} />
            <span>
              <strong>Digital twin</strong>
              <small>Forecast shortages</small>
            </span>
          </button>
          <button onClick={() => setPage("innovations")}>
            <FileCheck2 size={16} />
            <span>
              <strong>Trust passport</strong>
              <small>Verify supply</small>
            </span>
          </button>
          <button onClick={() => setPage("innovations")}>
            <LifeBuoy size={16} />
            <span>
              <strong>Emergency matching</strong>
              <small>Route referrals</small>
            </span>
          </button>
          <button onClick={() => setPage("innovations")}>
            <PackageCheck size={16} />
            <span>
              <strong>Medicine rescue</strong>
              <small>Move surplus</small>
            </span>
          </button>
          <button onClick={() => setPage("innovations")}>
            <LifeBuoy size={16} />
            <span>
              <strong>Disaster swarm</strong>
              <small>Simulate demand</small>
            </span>
          </button>
        </div>
      </section>
      <div className="overview-grid">
        <section className="panel attention-panel">
          <div className="panel-heading">
            <div>
              <div className="eyebrow">Priority queue</div>
              <h2>Human attention needed</h2>
            </div>
            <button className="text-button" onClick={() => setPage("alerts")}>
              View all <ArrowRight size={14} />
            </button>
          </div>
          {criticalAlerts.map(alert => (
            <AlertRow alert={alert} key={alert.id} compact />
          ))}
          {criticalAlerts.length === 0 && (
            <EmptyState
              icon={CheckCircle2}
              title="Nothing urgent"
              copy="All current alerts are acknowledged."
            />
          )}
        </section>
        <section className="panel request-panel">
          <div className="panel-heading">
            <div>
              <div className="eyebrow">Emergency exchange</div>
              <h2>Next safe handoff</h2>
            </div>
            <span className="live-label">
              <i /> Preview live
            </span>
          </div>
          {activeRequest ? (
            <>
              <div className="request-summary">
                <div className="request-badge">
                  <LifeBuoy size={18} />
                </div>
                <div>
                  <span className="status-pill critical">
                    {activeRequest.urgency}
                  </span>
                  <h3>
                    {activeRequest.quantity} {activeRequest.unit}
                  </h3>
                  <p>
                    {activeRequest.resource} · {activeRequest.destination}
                  </p>
                </div>
              </div>
              <div className="match-callout">
                <div className="match-score">
                  <strong>{activeRequest.matches[0]?.score}</strong>
                  <span>match</span>
                </div>
                <div>
                  <strong>{activeRequest.matches[0]?.supplier}</strong>
                  <p>
                    {activeRequest.matches[0]?.reasons[0]} ·{" "}
                    {activeRequest.matches[0]?.freshness}
                  </p>
                </div>
                <ChevronRight size={18} />
              </div>
              <button
                className="button button-primary full-width"
                onClick={() => setPage("exchange")}
              >
                Review request <ArrowRight size={16} />
              </button>
            </>
          ) : (
            <EmptyState
              icon={CheckCircle2}
              title="No pending handoffs"
              copy="The exchange board is clear."
            />
          )}
        </section>
      </div>
      <div className="overview-grid lower">
        <section className="panel audit-preview">
          <div className="panel-heading">
            <div>
              <div className="eyebrow">Append-only activity</div>
              <h2>Latest audit events</h2>
            </div>
            <button className="text-button" onClick={() => setPage("audit")}>
              Full trail <ArrowRight size={14} />
            </button>
          </div>
          <div className="audit-list">
            {snapshot.audit.slice(0, 4).map(event => (
              <AuditItem key={event.id} event={event} />
            ))}
          </div>
        </section>
        <section className="panel freshness-panel">
          <div className="panel-heading">
            <div>
              <div className="eyebrow">Data confidence</div>
              <h2>District freshness</h2>
            </div>
            <span className="freshness-score">78%</span>
          </div>
          <div className="freshness-bars">
            <div>
              <span>Central District</span>
              <b>
                <i style={{ width: "92%" }} />
              </b>
              <strong>92</strong>
            </div>
            <div>
              <span>East Ward</span>
              <b>
                <i style={{ width: "68%" }} />
              </b>
              <strong>68</strong>
            </div>
            <div>
              <span>West Ward</span>
              <b>
                <i style={{ width: "44%" }} />
              </b>
              <strong>44</strong>
            </div>
          </div>
          <p className="panel-footnote">
            <span className="signal-dot teal" /> Freshness weights every match;
            it never turns a report into a guarantee.
          </p>
        </section>
      </div>
    </div>
  );
}

function ResourceCard({
  resource,
  selected,
  onSelect,
}: {
  resource: Resource;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      className={`resource-card ${selected ? "selected" : ""}`}
      onClick={onSelect}
    >
      <div className="resource-card-top">
        <span className={`facility-icon ${resource.kind.toLowerCase()}`}>
          {resource.kind === "Hospital" ? (
            <Hospital size={17} />
          ) : (
            <Stethoscope size={17} />
          )}
        </span>
        <span className={`freshness-tag ${statusClass(resource.freshness)}`}>
          <i /> {resource.freshness}
        </span>
      </div>
      <div className="resource-name">{resource.name}</div>
      <div className="resource-meta">
        <MapPin size={13} /> {resource.district} <span>·</span>{" "}
        {resource.address}
      </div>
      <div className="resource-numbers">
        {resource.kind === "Hospital" ? (
          <>
            <div>
              <strong>{resource.beds}</strong>
              <span>open beds</span>
            </div>
            <div>
              <strong>{resource.icu}</strong>
              <span>ICU beds</span>
            </div>
            <div>
              <strong>{resource.oxygen}</strong>
              <span>oxygen</span>
            </div>
          </>
        ) : (
          <>
            <div>
              <strong>84</strong>
              <span>tracked items</span>
            </div>
            <div>
              <strong>{resource.reliability}%</strong>
              <span>reliability</span>
            </div>
            <div>
              <strong>{resource.confirmed ? "Yes" : "No"}</strong>
              <span>confirmed</span>
            </div>
          </>
        )}
      </div>
      <div className="resource-card-foot">
        <span>Updated {timeAgo(resource.updatedAt)}</span>
        <ChevronRight size={15} />
      </div>
    </button>
  );
}

function ResourcesPage({ snapshot }: { snapshot: DemoSnapshot }) {
  const [query, setQuery] = useState("");
  const [district, setDistrict] = useState("All districts");
  const [kind, setKind] = useState("All types");
  const [selectedId, setSelectedId] = useState(snapshot.resources[0]?.id);
  const resourcesQuery = trpc.demo.resources.useQuery({
    query,
    district,
    kind,
  });
  const resources = resourcesQuery.data || [];
  const selected =
    resources.find(resource => resource.id === selectedId) || resources[0];
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Discovery · Reported availability</div>
          <h1>Find resources</h1>
          <p>
            Search the district network with freshness and source confidence in
            view.
          </p>
        </div>
        <span className="demo-chip large">Reported network · Preview</span>
      </div>
      <section className="search-panel">
        <div className="search-box">
          <Search size={17} />
          <input
            value={query}
            onChange={event => setQuery(event.target.value)}
            placeholder="Search hospitals, pharmacies, or neighbourhoods"
          />
        </div>
        <select
          value={district}
          onChange={event => setDistrict(event.target.value)}
        >
          <option>All districts</option>
          <option>Central District</option>
          <option>East Ward</option>
          <option>West Ward</option>
        </select>
        <select value={kind} onChange={event => setKind(event.target.value)}>
          <option>All types</option>
          <option>Hospital</option>
          <option>Pharmacy</option>
        </select>
        <button className="filter-button">
          <Filter size={15} /> More filters
        </button>
      </section>
      <div className="results-meta">
        <span>
          <strong>{resources.length}</strong> facilities reporting
        </span>
        <span className="list-mode">
          <ListFilter size={15} /> List view{" "}
          <span>· Map provider not configured</span>
        </span>
      </div>
      <div className="resource-layout">
        <div className="resource-grid">
          {resources.map(resource => (
            <ResourceCard
              resource={resource}
              key={resource.id}
              selected={resource.id === selected?.id}
              onSelect={() => setSelectedId(resource.id)}
            />
          ))}
          {resources.length === 0 && (
            <EmptyState
              icon={Search}
              title="No facilities found"
              copy="Try a different district, type, or search term."
            />
          )}
        </div>
        {selected && (
          <aside className="detail-panel">
            <div className="detail-panel-top">
              <span className={`facility-icon ${selected.kind.toLowerCase()}`}>
                {selected.kind === "Hospital" ? (
                  <Hospital size={17} />
                ) : (
                  <Stethoscope size={17} />
                )}
              </span>
              <span
                className={`freshness-tag ${statusClass(selected.freshness)}`}
              >
                <i /> {selected.freshness}
              </span>
            </div>
            <h2>{selected.name}</h2>
            <p className="detail-address">
              <MapPin size={14} /> {selected.address}, {selected.district}
            </p>
            <div className="detail-divider" />
            <div className="detail-label">Reported capacity</div>
            <div className="detail-capacity">
              {selected.kind === "Hospital" ? (
                <>
                  <div>
                    <strong>{selected.beds}</strong>
                    <span>general beds</span>
                  </div>
                  <div>
                    <strong>{selected.icu}</strong>
                    <span>ICU beds</span>
                  </div>
                  <div>
                    <strong>{selected.oxygen}</strong>
                    <span>oxygen cylinders</span>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <strong>84</strong>
                    <span>stock lines</span>
                  </div>
                  <div>
                    <strong>{selected.reliability}%</strong>
                    <span>source reliability</span>
                  </div>
                  <div>
                    <strong>{selected.confirmed ? "Yes" : "No"}</strong>
                    <span>confirmation</span>
                  </div>
                </>
              )}
            </div>
            <div className="detail-label">Essential supplies</div>
            <div className="supply-line">
              <span>{selected.essential}</span>
              <span className="signal-dot teal" />
            </div>
            <div className="detail-label">Data provenance</div>
            <div className="provenance">
              <ShieldCheck size={16} />
              <div>
                <strong>Reported by facility</strong>
                <span>
                  Last updated {timeAgo(selected.updatedAt)} ·{" "}
                  {selected.confirmed
                    ? "confirmed by staff"
                    : "awaiting confirmation"}
                </span>
              </div>
            </div>
            <button
              className="button button-primary full-width"
              onClick={() =>
                toast.success(`Confirmation request sent to ${selected.name}`)
              }
            >
              Request confirmation <Send size={15} />
            </button>
            <p className="detail-note">
              Availability is reported, not guaranteed. Revalidate with the
              facility before acting.
            </p>
          </aside>
        )}
      </div>
    </div>
  );
}

function outcomeClass(outcome: Medicine["outcome"]) {
  return outcome === "Registry Match"
    ? "match"
    : outcome === "Suspicious"
      ? "critical"
      : outcome === "Expired"
        ? "expired"
        : "unverified";
}

function VerifyPage({
  snapshot,
  refresh,
}: {
  snapshot: DemoSnapshot;
  refresh: () => void;
}) {
  const [identifier, setIdentifier] = useState("MR-7719-C");
  const [batch, setBatch] = useState("IG-24-009");
  const [result, setResult] = useState<Medicine | null>(
    snapshot.medicines.find(medicine => medicine.identifier === "MR-7719-C") ||
      null
  );
  const verifyMutation = trpc.demo.verifyMedicine.useMutation({
    onSuccess: value => {
      setResult(value);
      refresh();
      toast.success("Verification saved to audit trail");
    },
    onError: error => toast.error(error.message),
  });
  const submit = (event: FormEvent) => {
    event.preventDefault();
    verifyMutation.mutate({ identifier, batch });
  };
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Pharmacy safety · Evidence review</div>
          <h1>Verify medicine</h1>
          <p>
            Registry checks are deterministic. AI observations, where available,
            never certify authenticity.
          </p>
        </div>
        <span className="demo-chip large">Pharmacy workspace</span>
      </div>
      <div className="verify-layout">
        <section className="panel verify-form-panel">
          <div className="panel-heading">
            <div>
              <h2>Check a pack</h2>
              <p>
                Enter the unique identifier from the package. Batch is optional
                but recommended.
              </p>
            </div>
            <div className="scan-button">
              <ScanLine size={20} />
              <span>
                Scan QR
                <br />
                <small>Camera ready</small>
              </span>
            </div>
          </div>
          <form onSubmit={submit}>
            <label>
              Medicine identifier
              <input
                value={identifier}
                onChange={event => setIdentifier(event.target.value)}
                placeholder="e.g. MR-9841-A"
              />
            </label>
            <label>
              Batch number <span className="optional">optional</span>
              <input
                value={batch}
                onChange={event => setBatch(event.target.value)}
                placeholder="e.g. AT-24-113"
              />
            </label>
            <div className="quick-checks">
              <span>Use a registry record</span>
              {snapshot.medicines.slice(0, 4).map(medicine => (
                <button
                  type="button"
                  key={medicine.identifier}
                  onClick={() => {
                    setIdentifier(medicine.identifier);
                    setBatch(medicine.batch);
                  }}
                >
                  {medicine.identifier}
                </button>
              ))}
            </div>
            <div className="upload-row">
              <button type="button" className="upload-control">
                <FileCheck2 size={15} /> Attach packaging photo
              </button>
              <span>Optional · visual notes remain human-reviewed</span>
            </div>
            <button
              className="button button-primary full-width"
              type="submit"
              disabled={verifyMutation.isPending}
            >
              {verifyMutation.isPending ? (
                <RefreshCcw className="spin" size={16} />
              ) : (
                <ShieldCheck size={16} />
              )}{" "}
              {verifyMutation.isPending
                ? "Checking registry…"
                : "Run verification"}
            </button>
          </form>
          <div className="verification-limit">
            <AlertTriangle size={15} />
            <span>
              A registry match is evidence of consistency, not definitive proof
              of authenticity. A missing record does not prove counterfeiting.
            </span>
          </div>
        </section>
        <section
          className={`panel result-panel ${result ? outcomeClass(result.outcome) : ""}`}
        >
          <div className="result-top">
            <div className="eyebrow">
              Latest result ·{" "}
              {result ? timeAgo(result.lastChecked) : "Awaiting scan"}
            </div>
            {result && (
              <span className={`status-pill ${outcomeClass(result.outcome)}`}>
                {result.outcome}
              </span>
            )}
          </div>
          {result ? (
            <>
              <div className="result-symbol">
                {result.outcome === "Registry Match" ? (
                  <CheckCircle2 size={27} />
                ) : result.outcome === "Suspicious" ? (
                  <ShieldAlert size={27} />
                ) : (
                  <AlertTriangle size={27} />
                )}
              </div>
              <h2>
                {result.outcome === "Registry Match"
                  ? "Evidence is consistent"
                  : result.outcome === "Suspicious"
                    ? "Review before release"
                    : result.outcome === "Expired"
                      ? "Do not dispense"
                      : "No reliable match"}
              </h2>
              <p className="result-reason">{result.reason}</p>
              <div className="evidence-table">
                <div>
                  <span>Identifier</span>
                  <strong>{result.identifier}</strong>
                </div>
                <div>
                  <span>Product</span>
                  <strong>{result.product}</strong>
                </div>
                <div>
                  <span>Manufacturer</span>
                  <strong>{result.manufacturer}</strong>
                </div>
                <div>
                  <span>Batch</span>
                  <strong>{result.batch}</strong>
                </div>
                <div>
                  <span>Expiry</span>
                  <strong>{result.expiry}</strong>
                </div>
                <div>
                  <span>Source</span>
                  <strong>{result.source}</strong>
                </div>
              </div>
              <div className="next-step">
                <span className="eyebrow">Recommended next step</span>
                <strong>
                  {result.outcome === "Registry Match"
                    ? "Retain the check as evidence and follow local dispensing protocols."
                    : "Quarantine the pack and route it to pharmacist review."}
                </strong>
              </div>
            </>
          ) : (
            <EmptyState
              icon={ScanLine}
              title="Ready for a medicine identifier"
              copy="Use a registry record or enter a pack identifier to begin."
            />
          )}
        </section>
      </div>
      <section className="panel verification-history">
        <div className="panel-heading">
          <div>
            <div className="eyebrow">Recent checks</div>
            <h2>Verification history</h2>
          </div>
          <span className="source-label">
            <i /> Registry source · Preview
          </span>
        </div>
        <div className="history-table">
          <div className="history-head">
            <span>Identifier</span>
            <span>Product</span>
            <span>Outcome</span>
            <span>Checked</span>
          </div>
          {snapshot.medicines.map(medicine => (
            <button
              className="history-row"
              key={medicine.id}
              onClick={() => {
                setIdentifier(medicine.identifier);
                setBatch(medicine.batch);
                setResult(medicine);
              }}
            >
              <strong>{medicine.identifier}</strong>
              <span>{medicine.product}</span>
              <span className={`status-pill ${outcomeClass(medicine.outcome)}`}>
                {medicine.outcome}
              </span>
              <span>
                {timeAgo(medicine.lastChecked)} <ChevronRight size={14} />
              </span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

function MatchCard({ match }: { match: Match }) {
  return (
    <div className="match-card">
      <div className="match-card-score">
        <strong>{match.score}</strong>
        <span>match</span>
      </div>
      <div className="match-card-content">
        <div className="match-card-head">
          <strong>{match.supplier}</strong>
          <span>{match.distance}</span>
        </div>
        <div className="match-resource">
          {match.available} {match.unit} available · report {match.freshness}
        </div>
        <div className="reason-list">
          {match.reasons.map(reason => (
            <span key={reason}>
              <Check size={13} /> {reason}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function ExchangePage({
  snapshot,
  role,
  refresh,
}: {
  snapshot: DemoSnapshot;
  role: DemoRole;
  refresh: () => void;
}) {
  const [selectedId, setSelectedId] = useState(snapshot.requests[0]?.id);
  const [showCreate, setShowCreate] = useState(false);
  const selected =
    snapshot.requests.find(request => request.id === selectedId) ||
    snapshot.requests[0];
  const transitionMutation = trpc.demo.transitionRequest.useMutation({
    onSuccess: () => {
      refresh();
      toast.success("Request state updated and audit event recorded");
    },
    onError: error => toast.error(error.message),
  });
  const createMutation = trpc.demo.createRequest.useMutation({
    onSuccess: request => {
      refresh();
      setSelectedId(request.id);
      setShowCreate(false);
      toast.success(`${request.id} matched to a supplier`);
    },
    onError: error => toast.error(error.message),
  });
  const [form, setForm] = useState({
    requester: "Saint Elara Medical Centre",
    resource: "Oxygen cylinders",
    quantity: "30",
    unit: "cylinders",
    urgency: "Critical" as "Critical" | "High" | "Routine",
    note: "",
  });
  const actionFor = selected
    ? selected.status === "awaiting_approval" || selected.status === "matched"
      ? "approve"
      : selected.status === "approved" || selected.status === "partial"
        ? "dispatch"
        : selected.status === "dispatched"
          ? "receive"
          : null
    : null;
  const canAct =
    actionFor &&
    ((actionFor === "approve" &&
      (role === "coordinator" || role === "admin")) ||
      (actionFor === "dispatch" &&
        ["coordinator", "admin", "hospital"].includes(role)) ||
      (actionFor === "receive" &&
        ["hospital", "coordinator", "admin"].includes(role)));
  const submit = (event: FormEvent) => {
    event.preventDefault();
    createMutation.mutate({ ...form, quantity: Number(form.quantity) });
  };
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Request → match → offer → receipt</div>
          <h1>Emergency exchange</h1>
          <p>
            Every transition is explicit, role-aware, and written to the audit
            trail.
          </p>
        </div>
        <button
          className="button button-primary"
          onClick={() => setShowCreate(value => !value)}
        >
          {showCreate ? <X size={16} /> : <LifeBuoy size={16} />}{" "}
          {showCreate ? "Close form" : "Report shortage"}
        </button>
      </div>
      {showCreate && (
        <section className="panel create-request-panel">
          <div className="panel-heading">
            <div>
              <div className="eyebrow">New shortage request</div>
              <h2>Tell the network what is needed.</h2>
            </div>
            <span className="demo-chip">Preview workflow</span>
          </div>
          <form className="request-form" onSubmit={submit}>
            <label>
              Requesting organization
              <select
                value={form.requester}
                onChange={event =>
                  setForm({ ...form, requester: event.target.value })
                }
              >
                <option>Saint Elara Medical Centre</option>
                <option>Northbridge General Hospital</option>
              </select>
            </label>
            <label>
              Resource
              <input
                value={form.resource}
                onChange={event =>
                  setForm({ ...form, resource: event.target.value })
                }
              />
            </label>
            <label>
              Quantity
              <input
                type="number"
                min="1"
                value={form.quantity}
                onChange={event =>
                  setForm({ ...form, quantity: event.target.value })
                }
              />
            </label>
            <label>
              Unit
              <input
                value={form.unit}
                onChange={event =>
                  setForm({ ...form, unit: event.target.value })
                }
              />
            </label>
            <label>
              Urgency
              <select
                value={form.urgency}
                onChange={event =>
                  setForm({
                    ...form,
                    urgency: event.target.value as typeof form.urgency,
                  })
                }
              >
                <option>Critical</option>
                <option>High</option>
                <option>Routine</option>
              </select>
            </label>
            <label className="wide">
              Context note <span className="optional">optional</span>
              <textarea
                value={form.note}
                onChange={event =>
                  setForm({ ...form, note: event.target.value })
                }
                placeholder="What should a supplier know?"
              />
            </label>
            <div className="wide form-actions">
              <span className="form-help">
                <ShieldCheck size={15} /> Matching uses quantity, distance,
                freshness, reliability, and reserve.
              </span>
              <button
                className="button button-primary"
                type="submit"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending
                  ? "Finding suppliers…"
                  : "Create and match request"}{" "}
                <ArrowRight size={15} />
              </button>
            </div>
          </form>
        </section>
      )}
      <div className="exchange-layout">
        <section className="panel request-list-panel">
          <div className="panel-heading">
            <div>
              <div className="eyebrow">Network queue</div>
              <h2>{snapshot.requests.length} requests</h2>
            </div>
            <span className="source-label">
              <i /> Shared workspace state
            </span>
          </div>
          <div className="request-list">
            {snapshot.requests.map(request => (
              <button
                key={request.id}
                className={`request-list-item ${request.id === selected?.id ? "selected" : ""}`}
                onClick={() => setSelectedId(request.id)}
              >
                <div
                  className={`request-list-icon ${statusClass(request.status)}`}
                >
                  <LifeBuoy size={16} />
                </div>
                <div className="request-list-copy">
                  <div>
                    <strong>{request.id}</strong>
                    <span
                      className={`status-pill ${request.urgency.toLowerCase()}`}
                    >
                      {request.urgency}
                    </span>
                  </div>
                  <h3>
                    {request.quantity} {request.unit} · {request.resource}
                  </h3>
                  <p>{request.requester}</p>
                </div>
                <div className="request-list-side">
                  <span
                    className={`status-text ${statusClass(request.status)}`}
                  >
                    {request.status.replace("_", " ")}
                  </span>
                  <small>{timeAgo(request.createdAt)}</small>
                </div>
              </button>
            ))}
          </div>
        </section>
        {selected && (
          <section className="panel exchange-detail">
            <div className="detail-header-row">
              <div>
                <div className="eyebrow">
                  {selected.id} · {timeAgo(selected.createdAt)}
                </div>
                <h2>
                  {selected.quantity} {selected.unit} of {selected.resource}
                </h2>
                <p>
                  {selected.requester} <ArrowRight size={14} />{" "}
                  {selected.destination}
                </p>
              </div>
              <span className={`status-pill ${statusClass(selected.status)}`}>
                {selected.status.replace("_", " ")}
              </span>
            </div>
            <div className="decision-strip">
              <div>
                <span className="eyebrow">Current role</span>
                <strong>
                  {roleOptions.find(option => option.value === role)?.label}
                </strong>
              </div>
              <div>
                <span className="eyebrow">Next safe action</span>
                <strong>
                  {actionFor
                    ? actionFor === "approve"
                      ? "Review supplier offer"
                      : actionFor === "dispatch"
                        ? "Record dispatch"
                        : "Confirm receipt"
                    : "No action pending"}
                </strong>
              </div>
              {canAct && actionFor && (
                <button
                  className="button button-primary"
                  onClick={() =>
                    transitionMutation.mutate({
                      requestId: selected.id,
                      action: actionFor,
                      role,
                    })
                  }
                  disabled={transitionMutation.isPending}
                >
                  {actionFor === "approve"
                    ? "Approve offer"
                    : actionFor === "dispatch"
                      ? "Record dispatch"
                      : "Confirm receipt"}{" "}
                  <ArrowRight size={15} />
                </button>
              )}
              {!canAct && actionFor && (
                <span className="role-lock">
                  <ShieldAlert size={15} /> Coordinator role required
                </span>
              )}
            </div>
            <div className="section-label">
              <span>Why this supplier?</span>
              <small>Deterministic match evidence</small>
            </div>
            <div className="match-stack">
              {selected.matches.map(match => (
                <MatchCard match={match} key={match.supplier} />
              ))}
            </div>
            <div className="section-label timeline-label">
              <span>Event timeline</span>
              <small>Append-only audit trail</small>
            </div>
            <div className="event-timeline">
              {selected.timeline.map(event => (
                <div className={`timeline-event ${event.tone}`} key={event.id}>
                  <span className="timeline-marker">
                    {event.tone === "done" ? (
                      <Check size={12} />
                    ) : event.tone === "danger" ? (
                      <X size={12} />
                    ) : (
                      <span />
                    )}
                  </span>
                  <div>
                    <strong>{event.label}</strong>
                    <p>{event.detail}</p>
                  </div>
                  <time>{event.at ? timeAgo(event.at) : "Pending"}</time>
                </div>
              ))}
            </div>
            <div className="request-note">
              <ClipboardList size={15} />
              <span>{selected.note}</span>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function InventoryPage({ snapshot }: { snapshot: DemoSnapshot }) {
  const [category, setCategory] = useState("All inventory");
  const inventory = snapshot.inventory.filter(
    item => category === "All inventory" || item.category === category
  );
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Inventory · Threshold intelligence</div>
          <h1>Inventory health</h1>
          <p>
            Reported counts across participating facilities, with low-stock and
            freshness context.
          </p>
        </div>
        <button
          className="button button-secondary small"
          onClick={() => toast.success("Inventory report requested")}
        >
          <Send size={14} /> Request fresh report
        </button>
      </div>
      <div className="tab-row">
        {["All inventory", "Oxygen", "Beds", "Medicine", "Supplies"].map(
          item => (
            <button
              className={category === item ? "active" : ""}
              onClick={() => setCategory(item)}
              key={item}
            >
              {item}
            </button>
          )
        )}
      </div>
      <section className="panel inventory-panel">
        <div className="panel-heading">
          <div>
            <div className="eyebrow">{inventory.length} reported lines</div>
            <h2>Facility inventory</h2>
          </div>
          <span className="source-label">
            <i /> Reported data · Preview
          </span>
        </div>
        <div className="inventory-table">
          <div className="inventory-head">
            <span>Item</span>
            <span>Organization</span>
            <span>Quantity</span>
            <span>Threshold</span>
            <span>Status</span>
            <span>Updated</span>
          </div>
          {inventory.map(item => (
            <div className="inventory-row" key={item.id}>
              <div className="item-cell">
                <span
                  className={`inventory-icon ${item.category.toLowerCase()}`}
                >
                  <PackageCheck size={15} />
                </span>
                <strong>{item.item}</strong>
              </div>
              <span>{item.organization}</span>
              <strong className="quantity-cell">
                {item.quantity} <small>{item.unit}</small>
              </strong>
              <span>
                {item.threshold} <small>{item.unit}</small>
              </span>
              <span className={`status-pill ${statusClass(item.status)}`}>
                {item.status}
              </span>
              <span>
                {timeAgo(item.updatedAt)}{" "}
                <span
                  className={`signal-dot ${item.status === "Available" ? "teal" : "amber"}`}
                />
              </span>
            </div>
          ))}
        </div>
      </section>
      <div className="inventory-foot">
        <span>
          <ShieldCheck size={15} /> Server-side rules prevent negative stock in
          the exchange workflow.
        </span>
        <span>Quantities are browser-local and not live.</span>
      </div>
    </div>
  );
}

function AlertRow({
  alert,
  compact = false,
  onAcknowledge,
}: {
  alert: Alert;
  compact?: boolean;
  onAcknowledge?: () => void;
}) {
  return (
    <div className={`alert-row ${compact ? "compact" : ""}`}>
      <div className={`alert-severity ${alert.severity.toLowerCase()}`}>
        <AlertTriangle size={15} />
      </div>
      <div className="alert-copy">
        <div>
          <strong>{alert.title}</strong>
          <span className={`status-pill ${alert.severity.toLowerCase()}`}>
            {alert.severity}
          </span>
        </div>
        <p>{alert.reason}</p>
        <small>
          {alert.source} · {timeAgo(alert.createdAt)}
        </small>
      </div>
      {onAcknowledge && !alert.acknowledged && (
        <button
          className="icon-button"
          onClick={onAcknowledge}
          aria-label="Acknowledge alert"
        >
          <Check size={15} />
        </button>
      )}
      {alert.acknowledged && (
        <span className="acknowledged">
          <Check size={13} /> Acknowledged
        </span>
      )}
    </div>
  );
}

function AlertsPage({
  snapshot,
  refresh,
}: {
  snapshot: DemoSnapshot;
  refresh: () => void;
}) {
  const ackMutation = trpc.demo.acknowledgeAlert.useMutation({
    onSuccess: () => {
      refresh();
      toast.success("Alert acknowledged");
    },
    onError: error => toast.error(error.message),
  });
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Signals · Action required</div>
          <h1>Alerts</h1>
          <p>
            Each alert explains why it exists and what action is recommended
            next.
          </p>
        </div>
        <span className="alert-count">
          <span>{snapshot.metrics.openAlerts}</span> open
        </span>
      </div>
      <section className="panel alerts-panel">
        <div className="panel-heading">
          <div>
            <div className="eyebrow">Alert queue</div>
            <h2>{snapshot.alerts.length} operational signals</h2>
          </div>
          <button className="filter-button">
            <Filter size={15} /> Filter <ChevronRight size={14} />
          </button>
        </div>
        <div className="alert-list">
          {snapshot.alerts.map(alert => (
            <div className="alert-detail" key={alert.id}>
              <AlertRow
                alert={alert}
                onAcknowledge={() => ackMutation.mutate({ id: alert.id })}
              />
              <div className="alert-recommendation">
                <span>Recommended action</span>
                <strong>{alert.recommendation}</strong>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function AuditItem({
  event,
}: {
  event: {
    id: string;
    action: string;
    actor: string;
    detail: string;
    at: string;
    tone: string;
  };
}) {
  return (
    <div className="audit-item">
      <span className={`audit-marker ${event.tone}`} />
      <div>
        <strong>{event.action}</strong>
        <p>{event.detail}</p>
        <small>
          {event.actor} · {timeAgo(event.at)}
        </small>
      </div>
    </div>
  );
}

function AuditPage({ snapshot }: { snapshot: DemoSnapshot }) {
  return (
    <div className="page-content">
      <div className="page-heading">
        <div>
          <div className="eyebrow">Accountability · Append-only</div>
          <h1>Audit trail</h1>
          <p>
            A readable record of the decisions that changed shared workspace
            state.
          </p>
        </div>
        <button
          className="button button-secondary small"
          onClick={() => toast.success("Audit export queued")}
        >
          <ClipboardList size={14} /> Export trail
        </button>
      </div>
      <section className="panel audit-panel">
        <div className="audit-hero">
          <div className="audit-hero-icon">
            <ClipboardList size={21} />
          </div>
          <div>
            <strong>Evidence that travels with the handoff.</strong>
            <p>
              Important medicine checks, inventory changes, and transfer
              transitions are recorded with an actor, timestamp, and source.
            </p>
          </div>
          <span className="source-label">
            <i /> Workspace ledger
          </span>
        </div>
        <div className="big-audit-list">
          {snapshot.audit.map(event => (
            <div className="big-audit-item" key={event.id}>
              <span className={`big-audit-marker ${event.tone}`} />{" "}
              <div>
                <div className="big-audit-title">
                  <strong>{event.action}</strong>
                  <time>{timeAgo(event.at)}</time>
                </div>
                <p>{event.detail}</p>
                <small>{event.actor}</small>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default function Operations() {
  const [location, setLocation] = useLocation();
  const [role, setRole] = useState<DemoRole>("coordinator");
  const [mobileNav, setMobileNav] = useState(false);
  const snapshotQuery = trpc.demo.snapshot.useQuery(undefined, {
    refetchInterval: 30000,
  });
  const resetMutation = trpc.demo.reset.useMutation({
    onSuccess: () => {
      snapshotQuery.refetch();
      toast.success("Demo data reset to the baseline scenario");
    },
    onError: error => toast.error(error.message),
  });
  const snapshot = snapshotQuery.data;
  const page = pageFromPath(location);
  const isPortal =
    location.startsWith("/app/patient") ||
    location.startsWith("/app/staff") ||
    location.startsWith("/portal");
  const isStaffPortal = location.startsWith("/app/staff");
  const setPage = (next: Page) => {
    setLocation(next === "overview" ? "/app" : `/app/${next}`);
    setMobileNav(false);
  };
  const currentRole =
    roleOptions.find(option => option.value === role) || roleOptions[0];
  const activeAlerts =
    snapshot?.alerts.filter(alert => !alert.acknowledged).length || 0;
  const body = useMemo(() => {
    if (isPortal)
      return (
        <div className="embedded-portal">
          <Portal />
        </div>
      );
    if (!snapshot)
      return (
        <div className="loading-state">
          <RefreshCcw className="spin" size={20} /> Loading network…
        </div>
      );
    if (page === "innovations") return <InnovationPage role={role} />;
    if (page === "resources") return <ResourcesPage snapshot={snapshot} />;
    if (page === "verify")
      return (
        <VerifyPage
          snapshot={snapshot}
          refresh={() => snapshotQuery.refetch()}
        />
      );
    if (page === "exchange")
      return (
        <ExchangePage
          snapshot={snapshot}
          role={role}
          refresh={() => snapshotQuery.refetch()}
        />
      );
    if (page === "inventory") return <InventoryPage snapshot={snapshot} />;
    if (page === "alerts")
      return (
        <AlertsPage
          snapshot={snapshot}
          refresh={() => snapshotQuery.refetch()}
        />
      );
    if (page === "audit") return <AuditPage snapshot={snapshot} />;
    return <OverviewPage snapshot={snapshot} setPage={setPage} />;
  }, [page, role, snapshot, snapshotQuery, isPortal]);
  return (
    <div className="app-shell">
      <aside className={`app-sidebar ${mobileNav ? "open" : ""}`}>
        <div className="sidebar-top">
          <Link
            href="/"
            className="brand-lockup"
            onClick={() => setMobileNav(false)}
          >
            <span className="brand-mark">
              <span />
            </span>
            <span>
              <strong>MEDNEXUS</strong> <em>AI</em>
            </span>
          </Link>
          <button className="mobile-close" onClick={() => setMobileNav(false)}>
            <X size={18} />
          </button>
        </div>
        <div className="workspace-switch">
          <div className="workspace-avatar">MC</div>
          <div>
            <strong>Metro Care Network</strong>
            <span>District workspace</span>
          </div>
          <ChevronRight size={15} />
        </div>
        <nav className="app-nav" aria-label="Application navigation">
          <span className="nav-section-label">Workspace</span>
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className={!isPortal && page === item.id ? "active" : ""}
                onClick={() => setPage(item.id)}
              >
                <Icon size={17} />
                <span>{item.label}</span>
                {item.id === "alerts" && activeAlerts > 0 && (
                  <b>{activeAlerts}</b>
                )}
              </button>
            );
          })}
          <Link
            href="/app/patient"
            className={`app-nav-patient ${isPortal && !isStaffPortal ? "active" : ""}`}
            onClick={() => setMobileNav(false)}
          >
            <UserRound size={17} />
            <span>Patient portal</span>
          </Link>
          <Link
            href="/app/staff"
            className={`app-nav-staff ${isStaffPortal ? "active" : ""}`}
            onClick={() => setMobileNav(false)}
          >
            <Hospital size={17} />
            <span>Doctor / staff access</span>
          </Link>
        </nav>
        <div className="sidebar-bottom">
          <div className="privacy-note">
            <ShieldCheck size={16} />
            <span>
              <strong>Demo-safe workspace</strong>
              <small>Browser-local records only</small>
            </span>
          </div>
          <button
            className="reset-button"
            onClick={() => resetMutation.mutate()}
            disabled={resetMutation.isPending}
          >
            <RotateCcw size={14} /> Reset preview data
          </button>
          <Link href="/" className="back-link">
            <ArrowRight size={14} /> Back to overview
          </Link>
        </div>
      </aside>
      <main className="app-main">
        <header className="app-header">
          <button className="mobile-menu" onClick={() => setMobileNav(true)}>
            <Menu size={20} />
          </button>
          <div className="header-context">
            <span className="header-kicker">Operations console</span>
            <span className="header-separator">/</span>
            <span>
              {isPortal
                ? isStaffPortal
                  ? "Doctor / staff access"
                  : "Patient portal"
                : navItems.find(item => item.id === page)?.label}
            </span>
          </div>
          <div className="header-actions">
            <span className="sync-status">
              <i /> Demo data synced
            </span>
            <button
              className="header-icon-button"
              aria-label="Notifications"
              onClick={() => setPage("alerts")}
            >
              <Bell size={17} />
              {activeAlerts > 0 && <i />}
            </button>
            <div className="role-picker">
              <UserRound size={15} />
              <select
                value={isPortal ? "public" : role}
                onChange={event => {
                  const next = event.target.value as DemoRole;
                  if (next === "public") {
                    setLocation("/app/patient");
                    setMobileNav(false);
                  } else {
                    setRole(next);
                    if (isPortal) setLocation("/app");
                  }
                }}
                aria-label="Demo role"
              >
                <option value="hospital">Hospital staff</option>
                <option value="pharmacist">Pharmacist</option>
                <option value="coordinator">Coordinator</option>
                <option value="admin">Administrator</option>
                <option value="public">
                  {isStaffPortal ? "Doctor / staff access" : "Patient portal"}
                </option>
              </select>
            </div>
          </div>
        </header>
        <div className="role-banner">
          <span>
            <span className="role-pulse" /> Preview workflow mode
          </span>
          <span>
            Signed in as <strong>{currentRole.label}</strong> ·{" "}
            {currentRole.description}
          </span>
          <span className="role-banner-note">
            No real patient data · No live availability
          </span>
        </div>
        {body}
      </main>
    </div>
  );
}
