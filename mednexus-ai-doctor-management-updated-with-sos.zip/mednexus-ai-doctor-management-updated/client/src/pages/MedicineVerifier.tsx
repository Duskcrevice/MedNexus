import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import React, { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  AlertCircle,
  ArrowUpRight,
  BadgeCheck,
  Bell,
  BookOpen,
  CalendarDays,
  Check,
  ChevronDown,
  ClipboardCheck,
  Clock3,
  FileText,
  FlaskConical,
  HeartPulse,
  Info,
  LayoutDashboard,
  LogIn,
  Menu,
  MoreHorizontal,
  PanelLeft,
  RefreshCw,
  ShieldCheck,
  Stethoscope,
  UserRound,
  UsersRound,
  X,
} from "lucide-react";

import "./medicine-verifier.css";

// Lightweight local buttons/badges so this module does not depend on global shadcn theme tokens.
function Button({
  variant,
  size,
  className = "",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "outline";
  size?: "sm";
}) {
  return (
    <button
      {...props}
      className={`mv-btn ${variant === "outline" ? "mv-btn-outline" : ""} ${size === "sm" ? "mv-btn-sm" : ""} ${className}`}
    />
  );
}
function Badge({ children }: { children: React.ReactNode; variant?: string }) {
  return <span className="mv-badge">{children}</span>;
}

type Severity = "green" | "yellow" | "red" | "grey";
type ViewMode = "patient" | "doctor";

function SeverityPill({
  severity,
  compact = false,
}: {
  severity: Severity;
  compact?: boolean;
}) {
  const labels = {
    green: "Checked",
    yellow: "Review",
    red: "Prompt review",
    grey: "Incomplete",
  };
  return (
    <span
      className={`status-pill status-${severity} ${compact ? "status-compact" : ""}`}
    >
      <span className="status-dot" />
      {labels[severity]}
    </span>
  );
}

function Metric({
  value,
  label,
  note,
  tone = "blue",
}: {
  value: string;
  label: string;
  note: string;
  tone?: string;
}) {
  return (
    <div className="metric-card">
      <div className={`metric-value metric-${tone}`}>{value}</div>
      <div className="metric-label">{label}</div>
      <div className="metric-note">{note}</div>
    </div>
  );
}

function SectionTitle({
  eyebrow,
  title,
  detail,
  action,
}: {
  eyebrow: string;
  title: string;
  detail?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="section-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h2>{title}</h2>
        {detail ? <p>{detail}</p> : null}
      </div>
      {action}
    </div>
  );
}

function ProfilePanel({
  live,
  profile,
  onLogin,
  onSave,
  saving,
}: {
  live: boolean;
  profile: any | null;
  onLogin: () => void;
  onSave: (value: {
    displayName: string;
    conditions: string;
    medicationAllergies: string;
    currentMedications: string;
    notes: string;
  }) => void;
  saving: boolean;
}) {
  const [editing, setEditing] = useState(!live || !profile);
  const [form, setForm] = useState({
    displayName: profile?.displayName ?? "",
    conditions: profile?.conditions ?? "",
    medicationAllergies: profile?.medicationAllergies ?? "",
    currentMedications: profile?.currentMedications ?? "",
    notes: "",
  });

  useEffect(() => {
    if (profile)
      setForm({
        displayName: profile.displayName,
        conditions: profile.conditions ?? "",
        medicationAllergies: profile.medicationAllergies ?? "",
        currentMedications: profile.currentMedications ?? "",
        notes: "",
      });
  }, [profile]);

  if (!live) {
    return (
      <section className="side-card profile-card profile-empty">
        <div className="side-card-top">
          <div className="eyebrow">MY HEALTH PROFILE</div>
          <span className="profile-avatar">
            <UserRound size={18} />
          </span>
        </div>
        <h3>Sign in to view your profile</h3>
        <p className="muted">
          Your allergies, conditions, medicines, and history are loaded only
          from your authenticated account.
        </p>
        <Button variant="outline" className="full-button" onClick={onLogin}>
          <LogIn size={15} /> Sign in to my profile
        </Button>
      </section>
    );
  }
  if (!profile) {
    return (
      <section className="side-card profile-card profile-empty">
        <div className="side-card-top">
          <div className="eyebrow">MY HEALTH PROFILE</div>
          <span className="profile-avatar">
            <UserRound size={18} />
          </span>
        </div>
        <h3>Profile not set up</h3>
        <p className="muted">
          Complete your health profile to receive personalized medicine
          information. Missing information stays visible; it will not be treated
          as normal.
        </p>
        {editing ? (
          <form
            className="profile-form"
            onSubmit={event => {
              event.preventDefault();
              onSave(form);
              setEditing(false);
            }}
          >
            <label>
              Display name
              <input
                value={form.displayName}
                onChange={event =>
                  setForm({ ...form, displayName: event.target.value })
                }
                required
              />
            </label>
            <label>
              Conditions
              <textarea
                value={form.conditions}
                onChange={event =>
                  setForm({ ...form, conditions: event.target.value })
                }
                placeholder="e.g. asthma, diabetes, none recorded"
              />
            </label>
            <label>
              Medication allergies
              <textarea
                value={form.medicationAllergies}
                onChange={event =>
                  setForm({ ...form, medicationAllergies: event.target.value })
                }
                placeholder="List known allergies or write not confirmed"
              />
            </label>
            <label>
              Current medicines
              <textarea
                value={form.currentMedications}
                onChange={event =>
                  setForm({ ...form, currentMedications: event.target.value })
                }
                placeholder="Include prescriptions, OTC medicines, supplements"
              />
            </label>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : "Save profile"}
            </Button>
          </form>
        ) : (
          <Button className="full-button" onClick={() => setEditing(true)}>
            <UserRound size={15} /> Complete health profile
          </Button>
        )}
      </section>
    );
  }

  return (
    <section className="side-card profile-card">
      <div className="side-card-top">
        <div className="eyebrow">MY HEALTH PROFILE</div>
        <span className="profile-avatar">
          {profile.displayName.slice(0, 2).toUpperCase()}
        </span>
      </div>
      <div className="profile-name-row">
        <h3>{profile.displayName}</h3>
        <button className="text-button" onClick={() => setEditing(!editing)}>
          {editing ? "Close" : "Edit"}
        </button>
      </div>
      <div className="profile-status-line">
        <span
          className={`profile-status-dot ${profile.completeness === "complete" ? "complete" : "needs"}`}
        />
        {profile.completeness === "complete"
          ? "Profile complete"
          : "Needs review"}
        <span className="mono-text">Updated recently</span>
      </div>
      {editing ? (
        <form
          className="profile-form"
          onSubmit={event => {
            event.preventDefault();
            onSave(form);
            setEditing(false);
          }}
        >
          <label>
            Display name
            <input
              value={form.displayName}
              onChange={event =>
                setForm({ ...form, displayName: event.target.value })
              }
            />
          </label>
          <label>
            Conditions
            <textarea
              value={form.conditions}
              onChange={event =>
                setForm({ ...form, conditions: event.target.value })
              }
              placeholder="e.g. asthma, diabetes, none recorded"
            />
          </label>
          <label>
            Medication allergies
            <textarea
              value={form.medicationAllergies}
              onChange={event =>
                setForm({ ...form, medicationAllergies: event.target.value })
              }
              placeholder="List known allergies or write not confirmed"
            />
          </label>
          <label>
            Current medicines
            <textarea
              value={form.currentMedications}
              onChange={event =>
                setForm({ ...form, currentMedications: event.target.value })
              }
              placeholder="Include prescriptions, OTC medicines, supplements"
            />
          </label>
          <Button type="submit" disabled={saving}>
            {saving ? "Saving…" : "Save profile & mark reports outdated"}
          </Button>
        </form>
      ) : (
        <div className="profile-facts">
          <div>
            <span>Conditions</span>
            <strong>{profile.conditions || "Not recorded"}</strong>
          </div>
          <div>
            <span>Medication allergies</span>
            <strong>{profile.medicationAllergies || "Not confirmed"}</strong>
          </div>
          <div>
            <span>Current medicines</span>
            <strong>{profile.currentMedications || "Not recorded"}</strong>
          </div>
        </div>
      )}
    </section>
  );
}

function VerificationCard({
  live,
  report,
  medicine,
  status,
  completion,
  findings,
  activeFinding,
  selectedFinding,
  setSelectedFinding,
  onReverify,
  reverifyPending,
  onAcknowledge,
  mode,
}: any) {
  return (
    <section className="report-card">
      <div className="report-card-head">
        <div>
          <div className="eyebrow">
            LATEST VERIFICATION ·{" "}
            {report
              ? `VERSION ${report.reportVersion ?? report.version}`
              : "NO REPORT"}
          </div>
          <h2>
            {report
              ? `${medicine?.name ?? "Prescription medicine"}${medicine?.strength ? ` · ${medicine.strength}` : ""}`
              : "No prescription report yet"}
          </h2>
          <p>
            {report
              ? `${live ? "Saved prescription" : report.prescription} · generated ${report.generatedAt}`
              : "A report appears here after an authorized doctor saves a prescription."}
          </p>
        </div>
        <div className="report-head-actions">
          {report ? <SeverityPill severity={status} /> : null}
          <button className="more-button">
            <MoreHorizontal size={18} />
          </button>
        </div>
      </div>
      {report ? (
        <>
          <div className={`report-status-band band-${status}`}>
            <div className="status-stamp">
              <span className="stamp-number">
                {status === "yellow" ? "02" : status === "red" ? "01" : "—"}
              </span>
              <span className="stamp-label">
                {status === "green"
                  ? "No known issue in completed checks"
                  : status === "yellow"
                    ? "Potential precaution requires review"
                    : status === "red"
                      ? "Prompt clinical review"
                      : "Verification incomplete"}
              </span>
            </div>
            <div className="completion-meter">
              <div className="meter-label">
                <span>Report coverage</span>
                <strong>{completion}%</strong>
              </div>
              <div className="meter-track">
                <span style={{ width: `${completion}%` }} />
              </div>
              <small>
                {report.checksCompleted} of {report.checksTotal} checks returned
                a result
              </small>
            </div>
          </div>
          <div className="report-disclaimer">
            <Info size={14} />
            <span>
              Green means no known issue was identified in checks successfully
              completed. It never means 100% safe.
            </span>
            {report.isOutdated ? (
              <Badge variant="outline">Profile changed · reverify</Badge>
            ) : null}
          </div>
          <div className="findings-list">
            <div className="findings-list-head">
              <span>Finding</span>
              <span>Status</span>
            </div>
            {findings.slice(0, 5).map((finding: any) => (
              <button
                key={finding.id}
                className={`finding-row ${selectedFinding === finding.id ? "finding-selected" : ""}`}
                onClick={() => setSelectedFinding(finding.id)}
              >
                <span className={`finding-icon finding-${finding.severity}`}>
                  {finding.severity === "red" ? (
                    <AlertCircle size={15} />
                  ) : finding.severity === "green" ? (
                    <Check size={15} />
                  ) : finding.severity === "grey" ? (
                    <Clock3 size={15} />
                  ) : (
                    <Info size={15} />
                  )}
                </span>
                <span className="finding-copy">
                  <strong>{finding.title}</strong>
                  <small>
                    {finding.type} · {finding.detail.slice(0, 100)}
                    {finding.detail.length > 100 ? "…" : ""}
                  </small>
                </span>
                <SeverityPill severity={finding.severity} compact />
              </button>
            ))}
          </div>
          <div className="finding-detail">
            <div className="detail-kicker">
              <span className="mono-text">SELECTED FINDING</span>
              <button className="text-button">
                Open evidence <ArrowUpRight size={13} />
              </button>
            </div>
            <h3>{activeFinding?.title}</h3>
            <p>{activeFinding?.detail}</p>
            <div className="detail-meta">
              <div>
                <span>Source</span>
                <strong>{activeFinding?.source}</strong>
              </div>
              <div>
                <span>Recommended next step</span>
                <strong>{activeFinding?.next}</strong>
              </div>
            </div>
            {mode === "doctor" &&
            activeFinding &&
            activeFinding.severity !== "green" &&
            live ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onAcknowledge(activeFinding.id)}
              >
                Acknowledge alert
              </Button>
            ) : null}
          </div>
          <div className="report-actions">
            <Button
              variant="outline"
              size="sm"
              onClick={onReverify}
              disabled={!live || reverifyPending}
            >
              {reverifyPending ? (
                <RefreshCw size={14} className="spin" />
              ) : (
                <RefreshCw size={14} />
              )}{" "}
              {reverifyPending
                ? "Checking reference…"
                : "Run verification again"}
            </Button>
            <button className="text-button">
              View report history <ArrowUpRight size={13} />
            </button>
          </div>
        </>
      ) : (
        <div className="no-report-state">
          <div className="empty-icon">
            <FileText size={22} />
          </div>
          <h3>Verification begins with an authorized prescription</h3>
          <p>
            The report will save the medicine reference, patient-specific
            checks, missing information, and evidence for clinician review.
          </p>
        </div>
      )}
    </section>
  );
}

function MedicineDetails({
  report,
  medicine: providedMedicine,
}: {
  report: any;
  medicine?: any;
}) {
  const [language, setLanguage] = useState<"English" | "हिन्दी" | "Hinglish">(
    "English"
  );
  if (!report) return null;
  const medicine = providedMedicine ?? report.medicine;
  const explanations = {
    English:
      report.aiExplanation ||
      "This medicine is commonly used for the purpose shown above. The available checks found a warning or incomplete information in the report. Please discuss the finding with your prescribing doctor or pharmacist.",
    हिन्दी:
      "यह दवा ऊपर बताए गए उपयोग के लिए दी जाती है। उपलब्ध जाँच में एक चेतावनी या अधूरी जानकारी मिली है। कृपया इस जानकारी पर अपने डॉक्टर या फार्मासिस्ट से बात करें।",
    Hinglish:
      "Yeh medicine upar diye gaye purpose ke liye use hoti hai. Available checks mein ek warning ya incomplete information mili hai. Is finding ko apne doctor ya pharmacist ke saath discuss karein.",
  };
  return (
    <section className="medicine-card">
      <SectionTitle
        eyebrow="MEDICINE REFERENCE"
        title={medicine.name}
        detail="Reference information is separate from the personalized safety checks."
        action={
          <span className="source-tag">
            <BookOpen size={13} /> NIH RxNorm / configured source
          </span>
        }
      />
      <div className="medicine-identification">
        <div>
          <span>Generic name</span>
          <strong>{medicine.generic ?? "Not available"}</strong>
        </div>
        <div>
          <span>Active ingredients</span>
          <strong>
            {medicine.ingredient ??
              "Not available — ingredient check incomplete"}
          </strong>
        </div>
        <div>
          <span>Category</span>
          <strong>{medicine.category ?? "Not available"}</strong>
        </div>
        <div>
          <span>Strength / form</span>
          <strong>{medicine.strength ?? "Use the prescription"}</strong>
        </div>
      </div>
      <div className="medicine-copy-grid">
        <div>
          <span className="copy-label">What it is commonly used for</span>
          <p>{medicine.purpose}</p>
        </div>
        <div>
          <span className="copy-label">Possible side effects</span>
          <p>{medicine.sideEffects}</p>
        </div>
        <div>
          <span className="copy-label">Long-term precautions</span>
          <p>{medicine.longTerm}</p>
        </div>
        <div>
          <span className="copy-label">When and how to take it</span>
          <p>
            <strong>{medicine.instructions}</strong>
            <br />
            {medicine.schedule}
          </p>
        </div>
      </div>
      <div className="ai-explanation">
        <div className="ai-explanation-head">
          <div>
            <div className="eyebrow">PATIENT-FRIENDLY EXPLANATION</div>
            <h3>What the available evidence means</h3>
          </div>
          <div className="language-tabs">
            {(["English", "हिन्दी", "Hinglish"] as const).map(item => (
              <button
                key={item}
                className={language === item ? "language-active" : ""}
                onClick={() => setLanguage(item)}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
        <p>{explanations[language]}</p>
        <small>
          {report.aiExplanation
            ? "Generated from retrieved evidence and saved with this report."
            : "Explanation is shown only when generated from retrieved medicine evidence."}
        </small>
      </div>
      <div className="reference-footer">
        <span>Source retrieval is stored with the report.</span>
        <span className="mono-text">
          Last checked · {report.generatedAt ?? "Not yet"}
        </span>
      </div>
    </section>
  );
}

function PrescriptionComposer({
  patientProfileId,
  saving,
  onSubmit,
}: {
  patientProfileId: number;
  saving: boolean;
  onSubmit: (input: {
    patientProfileId: number;
    medicines: Array<{
      medicineName: string;
      prescribedStrength: string;
      dose: string;
      frequency: string;
      duration: string;
      timing: string;
    }>;
  }) => void;
}) {
  const [form, setForm] = useState({
    medicineName: "",
    prescribedStrength: "",
    dose: "",
    frequency: "",
    duration: "",
    timing: "",
  });
  return (
    <section className="side-card composer-card">
      <div className="eyebrow">AUTHORIZED PRESCRIPTION FLOW</div>
      <h3>Save a prescription</h3>
      <p>
        Use the doctor-prescribed instructions exactly as written. Blank fields
        stay blank and will be shown as incomplete.
      </p>
      <form
        className="profile-form"
        onSubmit={event => {
          event.preventDefault();
          onSubmit({ patientProfileId, medicines: [form] });
        }}
      >
        <label>
          Medicine name
          <input
            value={form.medicineName}
            onChange={event =>
              setForm({ ...form, medicineName: event.target.value })
            }
            placeholder="e.g. amoxicillin"
            required
          />
        </label>
        <label>
          Strength / form
          <input
            value={form.prescribedStrength}
            onChange={event =>
              setForm({ ...form, prescribedStrength: event.target.value })
            }
            placeholder="e.g. 500 mg capsule"
          />
        </label>
        <label>
          Dose & frequency
          <input
            value={form.dose}
            onChange={event => setForm({ ...form, dose: event.target.value })}
            placeholder="e.g. 1 capsule"
          />
          <input
            value={form.frequency}
            onChange={event =>
              setForm({ ...form, frequency: event.target.value })
            }
            placeholder="e.g. three times daily"
          />
        </label>
        <label>
          Duration & timing
          <input
            value={form.duration}
            onChange={event =>
              setForm({ ...form, duration: event.target.value })
            }
            placeholder="e.g. 7 days"
          />
          <input
            value={form.timing}
            onChange={event => setForm({ ...form, timing: event.target.value })}
            placeholder="e.g. with food, if specified"
          />
        </label>
        <Button type="submit" disabled={saving}>
          {saving ? "Saving & verifying…" : "Save prescription"}
        </Button>
      </form>
    </section>
  );
}

function QuestionsCard({ status }: { status: Severity }) {
  return (
    <section className="side-card questions-card">
      <div className="eyebrow">NEXT CONVERSATION</div>
      <h3>Questions for the prescribing doctor</h3>
      <p>Turn a warning into a useful appointment.</p>
      <ol>
        <li>What should I do given the allergy history?</li>
        <li>Which symptoms would mean I need prompt help?</li>
        <li>What information is still missing from my profile?</li>
      </ol>
      <div className="question-footer">
        <span className={`question-line question-${status}`} />
        <span>Generated from the available report context</span>
      </div>
    </section>
  );
}

function ProfileChecklist({ profile }: { profile: any }) {
  const fields = [
    { label: "Conditions", value: profile?.conditions },
    { label: "Medication allergies", value: profile?.medicationAllergies },
    { label: "Current medications", value: profile?.currentMedications },
    {
      label: "History & surgeries",
      value: profile?.medicalHistory || profile?.surgeries,
    },
  ];
  return (
    <section className="side-card checklist-card">
      <div className="eyebrow">PROFILE COVERAGE</div>
      <h3>What can be checked</h3>
      <p>
        Important fields stay visible so missing context does not look like a
        green result.
      </p>
      {fields.map(field => (
        <div className="checklist-row" key={field.label}>
          <span
            className={
              field.value ? "checklist-mark checked" : "checklist-mark"
            }
          >
            {field.value ? <Check size={12} /> : ""}
          </span>
          <span>{field.label}</span>
          <small>{field.value ? "Saved" : "Missing"}</small>
        </div>
      ))}
      <div className="checklist-note">
        <AlertCircle size={14} />A profile update marks affected reports
        outdated and offers re-verification.
      </div>
    </section>
  );
}

function EmptyWorkspace({
  onLogin,
  onCreateProfile,
}: {
  onLogin: () => void;
  onCreateProfile: () => void;
}) {
  return (
    <div className="empty-workspace">
      <div className="empty-workspace-icon">
        <HeartPulse size={26} />
      </div>
      <div>
        <div className="eyebrow">READY WHEN YOU ARE</div>
        <h2>Start with a health profile.</h2>
        <p>
          MEDNEXUS will only check what you choose to save. It will not infer
          diagnoses, invent dose instructions, or call an incomplete report
          safe.
        </p>
        <div className="empty-actions">
          <Button onClick={onCreateProfile}>
            <UserRound size={15} /> Add health profile
          </Button>
          <Button variant="outline" onClick={onLogin}>
            <LogIn size={15} /> Sign in again
          </Button>
        </div>
      </div>
    </div>
  );
}

function DoctorView({
  live,
  reports,
  loading,
  onLogin,
  onAcknowledge,
}: {
  live: boolean;
  reports: any[];
  loading: boolean;
  onLogin: () => void;
  onAcknowledge: (id: number) => void;
}) {
  if (loading)
    return (
      <div className="loading-state">
        <RefreshCw className="spin" size={18} /> Loading authorized
        prescriptions…
      </div>
    );
  if (!reports.length)
    return (
      <div className="doctor-locked">
        <div className="doctor-locked-icon">
          <ClipboardCheck size={24} />
        </div>
        <div>
          <div className="eyebrow">NO PRESCRIPTIONS YET</div>
          <h2>Your review queue is clear.</h2>
          <p>
            When you save an authorized prescription, the verification report
            and acknowledgement controls will appear here.
          </p>
        </div>
      </div>
    );
  return (
    <div className="doctor-layout">
      {!live ? (
        <div className="doctor-locked">
          <div className="doctor-locked-icon">
            <Stethoscope size={24} />
          </div>
          <div>
            <div className="eyebrow">
              FICTIONAL REVIEW QUEUE · NOT MEDICAL ADVICE
            </div>
            <h2>Review the context behind this prescription.</h2>
            <p>
              This demo shows the Doctor dashboard. Sign in with an authorized
              doctor account to replace it with prescriptions you created or
              patients shared with your care team.
            </p>
            <Button variant="outline" onClick={onLogin}>
              <LogIn size={15} /> Sign in as clinician
            </Button>
          </div>
        </div>
      ) : null}
      <SectionTitle
        eyebrow="DOCTOR PORTAL"
        title="Review queue"
        detail="Warnings remain attached to the report version that generated them."
        action={<BadgeCheck className="doctor-verified-icon" size={22} />}
      />
      <div className="doctor-table">
        <div className="doctor-table-head">
          <span>Patient</span>
          <span>Prescription</span>
          <span>Status</span>
          <span>Review</span>
        </div>
        {reports.map((item: any) => (
          <div className="doctor-row" key={item.prescription.id}>
            <div className="doctor-patient">
              <span className="patient-initials">
                {item.profile?.displayName?.slice(0, 2).toUpperCase() ?? "PT"}
              </span>
              <span>
                <strong>{item.profile?.displayName ?? "Patient"}</strong>
                <small>
                  Profile updated{" "}
                  {item.profile?.updatedAt
                    ? new Date(item.profile.updatedAt).toLocaleDateString()
                    : "recently"}
                </small>
              </span>
            </div>
            <div>
              <strong>Prescription #{item.prescription.id}</strong>
              <small>
                {item.prescription.status} ·{" "}
                {new Date(item.prescription.updatedAt).toLocaleDateString()}
              </small>
            </div>
            <div>
              {item.report ? (
                <SeverityPill severity={item.report.status} />
              ) : (
                <span className="status-pill status-grey">
                  <span className="status-dot" />
                  No report
                </span>
              )}
            </div>
            <div>
              {item.report?.findings
                ?.filter(
                  (finding: any) =>
                    finding.severity === "red" || finding.severity === "yellow"
                )
                .map((finding: any) => (
                  <button
                    key={finding.id}
                    className="ack-button"
                    disabled={!live}
                    onClick={() => onAcknowledge(finding.id)}
                  >
                    <Bell size={13} />{" "}
                    {live
                      ? finding.acknowledgedAt
                        ? "Acknowledged"
                        : "Acknowledge"
                      : "Review warning"}
                  </button>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function MedicineVerifier({ mode }: { mode: ViewMode }) {
  const auth = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "report" | "profile">(
    "overview"
  );
  const [selectedFinding, setSelectedFinding] = useState<string>("allergy");
  const dashboard = trpc.mednexus.dashboard.useQuery(undefined, {
    enabled: auth.isAuthenticated,
    retry: false,
  });
  const doctorReports = trpc.mednexus.doctor.reports.useQuery(undefined, {
    enabled: auth.isAuthenticated && mode === "doctor",
    retry: false,
  });
  const updateProfile = trpc.mednexus.profile.upsert.useMutation({
    onSuccess: () => {
      toast.success("Profile saved. Existing reports are now marked outdated.");
      dashboard.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const reverify = trpc.mednexus.verification.reverify.useMutation({
    onSuccess: result => {
      toast.success(
        `Verification v${result.version} saved as ${result.status}.`
      );
      dashboard.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const createPrescription = trpc.mednexus.prescriptions.create.useMutation({
    onSuccess: result => {
      toast.success(
        "Prescription saved. Running the first evidence check now."
      );
      dashboard.refetch();
      reverify.mutate({ prescriptionId: result.prescriptionId });
    },
    onError: error => toast.error(error.message),
  });
  const acknowledge = trpc.mednexus.verification.acknowledge.useMutation({
    onSuccess: () => {
      toast.success("Alert acknowledgement saved.");
      dashboard.refetch();
    },
    onError: error => toast.error(error.message),
  });

  const live = auth.isAuthenticated;
  const liveProfile = dashboard.data?.profile ?? null;
  const livePrescription = dashboard.data?.prescriptions?.[0] ?? null;
  const report = live ? livePrescription?.report : null;
  const liveMedicine = livePrescription?.medicines?.[0]
    ? {
        name: livePrescription.medicines[0].medicineName,
        generic: "Not available until the reference service returns it",
        ingredient: "Not available — ingredient check incomplete",
        category: "Not available",
        strength:
          livePrescription.medicines[0].prescribedStrength || "Not specified",
        purpose:
          "Purpose is shown only when retrieved from the configured medicine reference source. Do not infer a diagnosis from the medicine name.",
        instructions:
          [
            livePrescription.medicines[0].dose,
            livePrescription.medicines[0].frequency,
            livePrescription.medicines[0].duration,
          ]
            .filter(Boolean)
            .join(" · ") ||
          "Administration instructions are not available. Please confirm with your prescribing doctor or pharmacist.",
        schedule:
          livePrescription.medicines[0].timing ||
          "Timing instructions are not specified in the prescription.",
        sideEffects:
          "Side-effect information is shown only after the medicine reference service returns a usable record.",
        longTerm:
          "Long-term precaution information is shown only after the medicine reference service returns a usable record.",
      }
    : null;
  const displayName = liveProfile?.displayName || auth.user?.name || "there";
  const reportFindings = report?.findings ?? [];
  const findings = live
    ? reportFindings.map((finding: any) => ({
        id: String(finding.id),
        type: finding.findingType,
        severity: finding.severity,
        title: finding.title,
        detail: finding.detail,
        source: finding.evidenceSource ?? "Configured reference",
        next:
          finding.recommendedNextStep ??
          "Discuss this finding with the prescribing doctor or pharmacist.",
      }))
    : [];
  const activeFinding =
    findings.find((finding: any) => finding.id === selectedFinding) ??
    findings[0];
  const currentStatus = (report?.status ?? "grey") as Severity;
  const completion = report
    ? Math.round(
        (report.checksCompleted / Math.max(report.checksTotal, 1)) * 100
      )
    : 0;
  const patientName = liveProfile?.displayName ?? "My profile";
  const realEmpty = !live || !liveProfile;

  const handleLogin = () => {
    try {
      startLogin();
    } catch {
      toast.error("Manus login is not configured in this Preview.");
    }
  };

  const saveProfile = (value: {
    displayName: string;
    conditions: string;
    medicationAllergies: string;
    currentMedications: string;
    notes: string;
  }) => {
    updateProfile.mutate({
      displayName: value.displayName,
      conditions: value.conditions,
      medicationAllergies: value.medicationAllergies,
      currentMedications: value.currentMedications,
      notes: value.notes,
    });
  };

  const tabs: Array<{ id: "overview" | "report" | "profile"; label: string }> =
    [
      { id: "overview", label: "Overview" },
      { id: "report", label: "Verification report" },
      { id: "profile", label: "Health profile" },
    ];

  return (
    <div
      className={`mv-root ${mode === "patient" ? "patient-view" : "doctor-view"}`}
    >
      <div className="page-wrap">
        <div className="page-intro">
          <div>
            <div className="eyebrow">
              {mode === "doctor" ? "CLINICIAN WORKSPACE" : "PATIENT PORTAL"}{" "}
              <span className="eyebrow-rule" />
            </div>
            <h1>
              {mode === "doctor" ? (
                "Review the context behind every prescription."
              ) : (
                <>
                  Good morning, <em>{displayName}.</em>
                </>
              )}
            </h1>
            <p className="intro-copy">
              {mode === "doctor"
                ? "See which checks completed, which findings need your acknowledgement, and where the patient profile is still incomplete."
                : "Medication information, interpreted against the health information you have chosen to share."}
            </p>
          </div>
          {live ? (
            <div className="user-chip">
              <span>{(auth.user?.name || "ME").slice(0, 2).toUpperCase()}</span>
              <strong>{auth.user?.name || "My account"}</strong>
            </div>
          ) : (
            <Button size="sm" onClick={handleLogin}>
              <LogIn size={14} /> Sign in
            </Button>
          )}
        </div>
        {mode === "patient" ? (
          <div className="mv-tabs" role="tablist">
            {tabs.map(tab => (
              <button
                key={tab.id}
                role="tab"
                aria-selected={activeTab === tab.id}
                className={activeTab === tab.id ? "mv-tab-active" : ""}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        ) : null}
        {!live ? (
          <div className="demo-banner">
            <div className="demo-banner-icon">
              <ShieldCheck size={17} />
            </div>
            <div>
              <strong>Sign in for personalized medicine information</strong>
              <span>
                Your name, health profile, prescriptions, and medicine checks
                are available only after authentication.
              </span>
            </div>
            <button onClick={handleLogin}>Sign in</button>
          </div>
        ) : null}

        {mode === "doctor" ? (
          <DoctorView
            live={live}
            reports={live ? (doctorReports.data ?? []) : []}
            loading={doctorReports.isLoading}
            onLogin={handleLogin}
            onAcknowledge={id => acknowledge.mutate({ findingId: id })}
          />
        ) : activeTab === "profile" ? (
          <div className="profile-layout">
            <div>
              <SectionTitle
                eyebrow="PATIENT-CONTEXT LAYER"
                title="Your health profile"
                detail="Verification can only use information that is saved here. An empty field is shown as incomplete, never assumed normal."
              />
              <div className="profile-page-card">
                <ProfilePanel
                  live={live}
                  profile={liveProfile}
                  onLogin={handleLogin}
                  onSave={saveProfile}
                  saving={updateProfile.isPending}
                />
              </div>
            </div>
            <ProfileChecklist profile={liveProfile} />
          </div>
        ) : realEmpty ? (
          <div className="profile-layout">
            <div>
              <SectionTitle
                eyebrow="FIRST-TIME SETUP"
                title="Let’s Set Up Your Health Profile"
                detail="Answer a few questions so your doctors can better understand your health."
              />
              <div className="profile-page-card">
                <ProfilePanel
                  live={live}
                  profile={liveProfile}
                  onLogin={handleLogin}
                  onSave={saveProfile}
                  saving={updateProfile.isPending}
                />
              </div>
            </div>
            <ProfileChecklist profile={liveProfile} />
          </div>
        ) : (
          <>
            <div className="metric-row">
              <Metric
                value={
                  report
                    ? `${report.checksCompleted}/${report.checksTotal}`
                    : "—"
                }
                label="Checks completed"
                note={
                  report
                    ? "Report-level coverage"
                    : "Create a prescription to begin"
                }
                tone="blue"
              />
              <Metric
                value={
                  currentStatus === "red"
                    ? "1"
                    : currentStatus === "yellow"
                      ? "2"
                      : "0"
                }
                label="Needs attention"
                note="Never a diagnosis or treatment change"
                tone={currentStatus === "red" ? "red" : "amber"}
              />
              <Metric
                value={
                  report
                    ? `v${(report as any).reportVersion ?? (report as any).version}`
                    : "—"
                }
                label="Report version"
                note={
                  report
                    ? "Previous versions remain traceable"
                    : "No saved report yet"
                }
                tone="ink"
              />
              <Metric
                value={
                  liveProfile?.completeness === "complete" ? "Ready" : "Review"
                }
                label="Profile status"
                note={
                  liveProfile?.completeness === "complete"
                    ? "Latest information available"
                    : "Important fields are missing"
                }
                tone={
                  liveProfile?.completeness === "complete" ? "mint" : "amber"
                }
              />
            </div>
            <div className="dashboard-grid">
              <div className="main-column">
                <VerificationCard
                  live={live}
                  report={report}
                  medicine={liveMedicine}
                  status={currentStatus}
                  completion={completion}
                  findings={findings}
                  activeFinding={activeFinding}
                  selectedFinding={selectedFinding}
                  setSelectedFinding={setSelectedFinding}
                  onReverify={() =>
                    livePrescription &&
                    reverify.mutate({
                      prescriptionId: livePrescription.prescription.id,
                    })
                  }
                  reverifyPending={reverify.isPending}
                  onAcknowledge={(id: string | number) =>
                    acknowledge.mutate({ findingId: Number(id) })
                  }
                  mode={mode}
                />
                <MedicineDetails report={report} medicine={liveMedicine} />
              </div>
              <div className="side-column">
                <ProfilePanel
                  live={live}
                  profile={liveProfile}
                  onLogin={handleLogin}
                  onSave={saveProfile}
                  saving={updateProfile.isPending}
                />
                {live && liveProfile && !livePrescription ? (
                  <PrescriptionComposer
                    patientProfileId={liveProfile.id}
                    saving={createPrescription.isPending}
                    onSubmit={input => createPrescription.mutate(input)}
                  />
                ) : null}
                <QuestionsCard status={currentStatus} />
              </div>
            </div>
          </>
        )}
      </div>
      <div className="page-footer">
        <span>
          <ShieldCheck size={13} /> Clinical safety support, not a substitute
          for a doctor or pharmacist.
        </span>
        <span className="mono-text">
          Evidence-first · patient-specific · no autonomous prescribing
        </span>
      </div>
    </div>
  );
}
