import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import {
  ArrowLeft,
  CalendarDays,
  Check,
  Clock3,
  FileText,
  Hospital,
  LogIn,
  LogOut,
  MessageSquare,
  ShieldCheck,
  Star,
  Stethoscope,
  UserRound,
  Users,
  XCircle,
} from "lucide-react";
import { isManusLoginConfigured, startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

// The protected directory is intentionally empty until an administrator-managed
// doctor catalogue exists. Clinician profiles are managed by authorized administrators.
type PortalDoctor = {
  id: string;
  name: string;
  specialty: string;
  experience: string;
  rating: string;
  reviews: string;
  hospital: string;
  availability: string;
  languages: string;
  image: string;
};
const doctors: PortalDoctor[] = [];

function dateLabel(value?: string | Date | null) {
  if (!value) return "Not scheduled";
  return new Date(value).toLocaleString([], {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function PortalHeader({
  title,
  subtitle,
  logout,
  name,
}: {
  title: string;
  subtitle: string;
  logout: () => void;
  name?: string;
}) {
  return (
    <header className="portal-header">
      <Link href="/" className="brand-lockup">
        <span className="brand-mark">
          <span />
        </span>
        <span>
          <strong>MEDNEXUS</strong> <em>AI</em>
        </span>
      </Link>
      <div className="portal-header-copy">
        <span className="eyebrow">Protected workspace</span>
        <strong>{title}</strong>
        <small>{subtitle}</small>
      </div>
      <div className="portal-header-actions">
        {name && <span className="portal-header-name">{name}</span>}
        <span className="portal-secure">
          <ShieldCheck size={14} /> Server-authorized
        </span>
        <button className="button button-secondary small" onClick={logout}>
          <LogOut size={14} /> Sign out
        </button>
      </div>
    </header>
  );
}

function LoginGate({ mode }: { mode: "patient" | "staff" }) {
  const isStaff = mode === "staff";
  const canSignIn = isManusLoginConfigured();
  return (
    <main className="portal-shell">
      <div className="portal-login">
        <div className="portal-login-mark">
          {isStaff ? <Hospital size={28} /> : <ShieldCheck size={28} />}
        </div>
        <div className="eyebrow">
          MEDNEXUS AI {isStaff ? "clinical team access" : "patient portal"}
        </div>
        <h1>
          {isStaff
            ? "Doctor and staff access."
            : "Your care, in one secure place."}
        </h1>
        <p>
          {isStaff
            ? "Sign in or register your hospital staff application. Approved doctors and staff receive organization-scoped dashboards; new applications stay pending until administrator review."
            : "Sign in to manage your profile, choose a doctor, request appointments, follow service requests, and view your care updates."}
        </p>
        <button
          className="button button-primary"
          disabled={!canSignIn}
          onClick={canSignIn ? startLogin : undefined}
          title={
            canSignIn
              ? undefined
              : "Sign-in provider is not configured in this preview."
          }
        >
          <LogIn size={16} />{" "}
          {canSignIn
            ? "Sign in or register"
            : "Sign-in unavailable in this preview"}
        </button>
        {!canSignIn && (
          <p className="portal-disclaimer">
            No identity provider is connected in this preview. Use the preview
            workspace from the welcome page.
          </p>
        )}
        <div className="portal-entry-links">
          <Link
            href="/app/patient"
            className={isStaff ? "text-link" : "text-link active-entry"}
          >
            <UserRound size={14} /> Patient login
          </Link>
          <Link
            href="/app/staff"
            className={isStaff ? "text-link active-entry" : "text-link"}
          >
            <Hospital size={14} /> Doctor / staff login
          </Link>
        </div>
        <Link href="/" className="text-link">
          <ArrowLeft size={14} /> Back to MEDNEXUS site
        </Link>
      </div>
    </main>
  );
}

function ProfileForm({
  profile,
  onSaved,
}: {
  profile: any;
  onSaved: () => void;
}) {
  const [displayName, setDisplayName] = useState(profile?.displayName || "");
  const [phone, setPhone] = useState(profile?.phone || "");
  const [preferredHospital, setPreferredHospital] = useState(
    profile?.preferredHospital || ""
  );
  const mutation = trpc.portal.registerPatient.useMutation({
    onSuccess: () => {
      toast.success("Patient profile saved");
      onSaved();
    },
    onError: error => toast.error(error.message),
  });
  return (
    <section className="portal-panel">
      <div className="portal-panel-heading">
        <div>
          <div className="eyebrow">Patient identity</div>
          <h2>Your profile</h2>
          <p>
            Keep your profile details current. This profile is visible only to
            you and authorized hospital staff.
          </p>
        </div>
        <UserRound size={20} />
      </div>
      <form
        className="portal-form"
        onSubmit={event => {
          event.preventDefault();
          mutation.mutate({
            displayName,
            phone: phone || undefined,
            preferredHospital: preferredHospital || undefined,
          });
        }}
      >
        <label>
          Display name
          <input
            value={displayName}
            onChange={event => setDisplayName(event.target.value)}
            required
            maxLength={180}
          />
        </label>
        <label>
          Phone (optional)
          <input
            value={phone}
            onChange={event => setPhone(event.target.value)}
            maxLength={40}
          />
        </label>
        <label>
          Preferred hospital
          <select
            value={preferredHospital}
            onChange={event => setPreferredHospital(event.target.value)}
          >
            <option value="">Choose a hospital</option>
            <option>Northbridge General Hospital</option>
            <option>Saint Elara Medical Centre</option>
            <option>Meridian South Hospital</option>
          </select>
        </label>
        <button className="button button-primary" disabled={mutation.isPending}>
          {mutation.isPending ? "Saving…" : "Save profile"}
        </button>
      </form>
    </section>
  );
}

function PatientClinicalHistory({ snapshot }: { snapshot: any }) {
  return (
    <div className="portal-grid clinical-history-grid">
      <section className="portal-panel">
        <div className="portal-panel-heading">
          <div>
            <div className="eyebrow">Clinical history</div>
            <h2>Medical records</h2>
            <p>Records shared with your authenticated account.</p>
          </div>
          <FileText size={20} />
        </div>
        {snapshot.medicalRecords?.length ? (
          <div className="portal-list">
            {snapshot.medicalRecords.map((item: any) => (
              <div className="portal-list-item" key={item.id}>
                <div className="portal-list-icon">
                  <FileText size={16} />
                </div>
                <div>
                  <strong>{item.title}</strong>
                  <span>
                    {item.recordType} · {dateLabel(item.recordDate)}
                  </span>
                  <small>
                    {item.summary} · {item.clinician}
                  </small>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="portal-empty">
            <FileText size={18} />
            <span>No medical records are available yet.</span>
          </div>
        )}
      </section>
      <section className="portal-panel">
        <div className="portal-panel-heading">
          <div>
            <div className="eyebrow">Medication plan</div>
            <h2>Prescriptions</h2>
            <p>Prescriptions uploaded by an authorized clinician.</p>
          </div>
          <Stethoscope size={20} />
        </div>
        {snapshot.prescriptions?.length ? (
          <div className="portal-list">
            {snapshot.prescriptions.map((item: any) => (
              <div className="portal-list-item" key={item.id}>
                <div className="portal-list-icon">
                  <Stethoscope size={16} />
                </div>
                <div>
                  <strong>{item.medication}</strong>
                  <span>
                    {item.dosage} · {item.status}
                  </span>
                  <small>
                    {item.instructions} · {item.clinician}
                  </small>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="portal-empty">
            <Stethoscope size={18} />
            <span>No prescriptions are available yet.</span>
          </div>
        )}
      </section>
    </div>
  );
}

const healthSteps = [
  "Basic details and blood group",
  "Existing health conditions",
  "Medication allergies",
  "Current medicines",
  "Previous surgeries",
  "Current health concerns",
  "Additional information",
];
const conditionOptions = [
  "Diabetes",
  "Asthma",
  "High blood pressure",
  "Heart condition",
  "Thyroid condition",
  "Kidney condition",
  "Liver condition",
  "None known",
  "Prefer not to say",
];
function HealthSurvey({
  profile,
  displayName,
  onSaved,
  onCancel,
}: {
  profile: any;
  displayName: string;
  onSaved: () => void;
  onCancel?: () => void;
}) {
  const [step, setStep] = useState(0);
  const [basicDetails, setBasicDetails] = useState(profile?.basicDetails || "");
  const [bloodGroup, setBloodGroup] = useState(profile?.bloodGroup || "");
  const [conditions, setConditions] = useState<string[]>(
    profile?.conditions ? profile.conditions.split(", ").filter(Boolean) : []
  );
  const [otherCondition, setOtherCondition] = useState("");
  const [allergyChoice, setAllergyChoice] = useState(
    profile?.medicationAllergies ? "yes" : ""
  );
  const [allergies, setAllergies] = useState(
    profile?.medicationAllergies || ""
  );
  const [allergyReaction, setAllergyReaction] = useState("");
  const [medicines, setMedicines] = useState(profile?.currentMedications || "");
  const [surgeryChoice, setSurgeryChoice] = useState(
    profile?.surgeries ? "yes" : ""
  );
  const [surgeries, setSurgeries] = useState(profile?.surgeries || "");
  const [concernChoice, setConcernChoice] = useState(
    profile?.medicalHistory ? "yes" : ""
  );
  const [concerns, setConcerns] = useState(profile?.medicalHistory || "");
  const [additional, setAdditional] = useState(profile?.notes || "");
  const mutation = trpc.mednexus.profile.upsert.useMutation({
    onSuccess: () => {
      toast.success("Your health profile has been saved successfully.");
      onSaved();
    },
    onError: error => toast.error(error.message),
  });
  const toggleCondition = (value: string) =>
    setConditions(current =>
      current.includes(value)
        ? current.filter(item => item !== value)
        : [
            ...current.filter(
              item => item !== "None known" && item !== "Prefer not to say"
            ),
            value,
          ]
    );
  const save = () => {
    const conditionText = [
      ...conditions,
      otherCondition.trim() ? `Other: ${otherCondition.trim()}` : "",
    ]
      .filter(Boolean)
      .join(", ");
    const allergyText =
      allergyChoice === "yes"
        ? [
            allergies.trim(),
            allergyReaction.trim() ? `Reaction: ${allergyReaction.trim()}` : "",
          ]
            .filter(Boolean)
            .join(" — ")
        : allergyChoice === "no"
          ? "No known medication allergies"
          : "";
    mutation.mutate({
      displayName: displayName || profile?.displayName || "Patient",
      basicDetails: basicDetails.trim(),
      bloodGroup,
      conditions: conditionText,
      medicationAllergies: allergyText,
      currentMedications: medicines.trim(),
      medicalHistory: concernChoice === "yes" ? concerns.trim() : "",
      surgeries: surgeryChoice === "yes" ? surgeries.trim() : "",
      notes: additional.trim(),
    });
  };
  const next = () =>
    step < healthSteps.length - 1 ? setStep(step + 1) : save();
  return (
    <section className="portal-panel health-survey-panel">
      <div className="portal-panel-heading">
        <div>
          <div className="eyebrow">FIRST-TIME SETUP</div>
          <h2>Let’s Set Up Your Health Profile</h2>
          <p>
            Answer a few simple questions to help your doctors understand your
            health and provide more personalized care.
          </p>
        </div>
        <UserRound size={20} />
      </div>
      <div className="health-survey-progress">
        <span>
          Step {step + 1} of {healthSteps.length}
        </span>
        <div>
          <i style={{ width: `${((step + 1) / healthSteps.length) * 100}%` }} />
        </div>
      </div>
      <div className="health-survey-step">
        {step === 0 && (
          <>
            <h3>Tell us a few basic health details</h3>
            <p className="muted">These details are stored securely under your patient account.</p>
            <label className="health-field">
              Basic details (optional)
              <input value={basicDetails} onChange={event => setBasicDetails(event.target.value)} placeholder="Age, height, weight or other useful details" />
            </label>
            <label className="health-field">
              Blood group (optional)
              <select value={bloodGroup} onChange={event => setBloodGroup(event.target.value)}>
                <option value="">Prefer not to say</option>
                <option>A+</option><option>A-</option><option>B+</option><option>B-</option>
                <option>AB+</option><option>AB-</option><option>O+</option><option>O-</option>
              </select>
            </label>
          </>
        )}
        {step === 1 && (
          <>
            <h3>Do you have any existing health conditions?</h3>
            <p className="muted">
              Select all that apply. Leaving this blank means it is unknown, not
              “No.”
            </p>
            <div className="health-option-grid">
              {conditionOptions.map(item => (
                <label className="health-option" key={item}>
                  <input
                    type="checkbox"
                    checked={conditions.includes(item)}
                    onChange={() => toggleCondition(item)}
                  />
                  <span>{item}</span>
                </label>
              ))}
            </div>
            <label className="health-field">
              Other (optional)
              <input
                value={otherCondition}
                onChange={e => setOtherCondition(e.target.value)}
                placeholder="Add another condition"
              />
            </label>
          </>
        )}
        {step === 2 && (
          <>
            <h3>Are you allergic to any medicines?</h3>
            <div className="health-choice-row">
              {[
                ["yes", "Yes"],
                ["no", "No known medication allergies"],
                ["unsure", "Not sure"],
              ].map(([value, label]) => (
                <button
                  type="button"
                  className={
                    allergyChoice === value
                      ? "health-choice active"
                      : "health-choice"
                  }
                  key={value}
                  onClick={() => setAllergyChoice(value)}
                >
                  {label}
                </button>
              ))}
            </div>
            {allergyChoice === "yes" && (
              <>
                <label className="health-field">
                  Which medicine or ingredient?
                  <input
                    value={allergies}
                    onChange={e => setAllergies(e.target.value)}
                    placeholder="Enter a medicine or ingredient"
                  />
                </label>
                <label className="health-field">
                  What reaction did you experience? (optional)
                  <textarea
                    value={allergyReaction}
                    onChange={e => setAllergyReaction(e.target.value)}
                    placeholder="Describe the reaction if you know it"
                  />
                </label>
              </>
            )}
          </>
        )}
        {step === 3 && (
          <>
            <h3>Are you currently taking any medicines?</h3>
            <p className="muted">
              Add one medicine per line. Include dosage and frequency if known.
            </p>
            <div className="health-choice-row">
              {[
                ["yes", "Yes"],
                ["no", "No"],
                ["unsure", "Not sure"],
              ].map(([value, label]) => (
                <button
                  type="button"
                  className={
                    medicines && value === "yes"
                      ? "health-choice active"
                      : "health-choice"
                  }
                  key={value}
                  onClick={() => (value === "yes" ? null : setMedicines(""))}
                >
                  {label}
                </button>
              ))}
            </div>
            <label className="health-field">
              <span>Medicines (optional)</span>
              <textarea
                value={medicines}
                onChange={e => setMedicines(e.target.value)}
                placeholder="Example: metformin 500 mg, twice daily"
              />
            </label>
          </>
        )}
        {step === 4 && (
          <>
            <h3>Have you undergone any major surgery?</h3>
            <div className="health-choice-row">
              {[
                ["yes", "Yes"],
                ["no", "No"],
                ["unsure", "Prefer not to say"],
              ].map(([value, label]) => (
                <button
                  type="button"
                  className={
                    surgeryChoice === value
                      ? "health-choice active"
                      : "health-choice"
                  }
                  key={value}
                  onClick={() => setSurgeryChoice(value)}
                >
                  {label}
                </button>
              ))}
            </div>
            {surgeryChoice === "yes" && (
              <label className="health-field">
                Brief details (optional)
                <textarea
                  value={surgeries}
                  onChange={e => setSurgeries(e.target.value)}
                  placeholder="Add a short description"
                />
              </label>
            )}
          </>
        )}
        {step === 5 && (
          <>
            <h3>Are you experiencing any ongoing health problems?</h3>
            <div className="health-choice-row">
              {[
                ["yes", "Yes"],
                ["no", "No"],
                ["unsure", "Prefer not to say"],
              ].map(([value, label]) => (
                <button
                  type="button"
                  className={
                    concernChoice === value
                      ? "health-choice active"
                      : "health-choice"
                  }
                  key={value}
                  onClick={() => setConcernChoice(value)}
                >
                  {label}
                </button>
              ))}
            </div>
            {concernChoice === "yes" && (
              <label className="health-field">
                Tell us in your own words (optional)
                <textarea
                  value={concerns}
                  onChange={e => setConcerns(e.target.value)}
                  placeholder="Describe your concern"
                />
              </label>
            )}
          </>
        )}
        {step === 6 && (
          <>
            <h3>Is there anything else you would like your doctor to know?</h3>
            <label className="health-field">
              <span>Optional</span>
              <textarea
                value={additional}
                onChange={e => setAdditional(e.target.value)}
                placeholder="Share only what you are comfortable sharing"
              />
            </label>
          </>
        )}
      </div>
      <div className="health-survey-actions">
        {step > 0 ? (
          <button
            type="button"
            className="button button-secondary"
            onClick={() => setStep(step - 1)}
          >
            Back
          </button>
        ) : onCancel ? (
          <button
            type="button"
            className="button button-secondary"
            onClick={onCancel}
          >
            Cancel
          </button>
        ) : (
          <span />
        )}
        {step < healthSteps.length - 1 ? (
          <>
            <button
              type="button"
              className="text-link"
              onClick={() => setStep(step + 1)}
            >
              Skip
            </button>
            <button
              type="button"
              className="button button-primary"
              onClick={next}
            >
              Next
            </button>
          </>
        ) : (
          <>
            <button type="button" className="text-link" onClick={save}>
              Skip and finish
            </button>
            <button
              type="button"
              className="button button-primary"
              disabled={mutation.isPending}
              onClick={save}
            >
              {mutation.isPending ? "Saving…" : "Save My Health Profile"}
            </button>
          </>
        )}
      </div>
    </section>
  );
}
function MyHealthProfile({
  displayName,
  onSaved,
}: {
  displayName: string;
  onSaved: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const profileQuery = trpc.mednexus.dashboard.useQuery(undefined, {
    retry: false,
  });
  const profile = profileQuery.data?.profile;
  if (profileQuery.isLoading)
    return (
      <section className="portal-panel">
        <p>Loading your health profile…</p>
      </section>
    );
  if (editing || !profile)
    return (
      <HealthSurvey
        profile={profile}
        displayName={displayName}
        onSaved={() => {
          setEditing(false);
          onSaved();
        }}
        onCancel={profile ? () => setEditing(false) : undefined}
      />
    );
  return (
    <section className="portal-panel health-profile-card">
      <div className="portal-panel-heading">
        <div>
          <div className="eyebrow">PERSONAL HEALTH</div>
          <h2>My Health Profile</h2>
          <p>
            Saved information used to support your care and medicine checks.
          </p>
        </div>
        <button
          className="button button-secondary small"
          onClick={() => setEditing(true)}
        >
          Edit Health Profile
        </button>
      </div>
      <div className="health-profile-grid">
        <div>
          <strong>Basic details</strong>
          <span>{profile.basicDetails || "Not recorded"}</span>
        </div>
        <div>
          <strong>Blood group</strong>
          <span>{profile.bloodGroup || "Not recorded"}</span>
        </div>
        <div>
          <strong>Conditions</strong>
          <span>{profile.conditions || "Not recorded"}</span>
        </div>
        <div>
          <strong>Medication allergies</strong>
          <span>{profile.medicationAllergies || "Not confirmed"}</span>
        </div>
        <div>
          <strong>Current medicines</strong>
          <span>{profile.currentMedications || "Not recorded"}</span>
        </div>
        <div>
          <strong>Medical history</strong>
          <span>{profile.medicalHistory || "Not recorded"}</span>
        </div>
        <div>
          <strong>Surgery history</strong>
          <span>{profile.surgeries || "Not recorded"}</span>
        </div>
        <div>
          <strong>Additional information</strong>
          <span>{profile.notes || "Not recorded"}</span>
        </div>
      </div>
    </section>
  );
}
function PatientPortal({
  snapshot,
  refresh,
  logout,
}: {
  snapshot: any;
  refresh: () => void;
  logout: () => void;
}) {
  const [hospitalName, setHospitalName] = useState(
    snapshot.profile?.preferredHospital || "Northbridge General Hospital"
  );
  const [selectedDoctorId, setSelectedDoctorId] = useState("");
  const [clinician, setClinician] = useState("");
  const [appointmentAt, setAppointmentAt] = useState("");
  const [reason, setReason] = useState("");
  const [category, setCategory] = useState("General support");
  const [description, setDescription] = useState("");
  const [doctorSearch, setDoctorSearch] = useState("");
  const [specialtyFilter, setSpecialtyFilter] = useState("All specialties");
  const [languageFilter, setLanguageFilter] = useState("All languages");
  const [availabilityFilter, setAvailabilityFilter] =
    useState("All availability");
  const activeDoctorsQuery = trpc.portal.activeDoctors.useQuery();
  const doctors: PortalDoctor[] = (activeDoctorsQuery.data as PortalDoctor[] | undefined) ?? [];
  const appointmentMutation = trpc.portal.bookAppointment.useMutation({
    onSuccess: () => {
      toast.success("Appointment request submitted");
      setReason("");
      setAppointmentAt("");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  const requestMutation = trpc.portal.createServiceRequest.useMutation({
    onSuccess: () => {
      toast.success("Service request submitted");
      setDescription("");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  const cancelMutation = trpc.portal.cancelAppointment.useMutation({
    onSuccess: () => {
      toast.success("Appointment cancelled");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  const specialties = Array.from(
    new Set(doctors.map(doctor => doctor.specialty).filter(Boolean))
  );
  const languages = Array.from(
    new Set(
      doctors.flatMap(doctor =>
        doctor.languages
          .split(/[,/]/)
          .map(value => value.trim())
          .filter(Boolean)
      )
    )
  );
  const availabilityOptions = Array.from(
    new Set(doctors.map(doctor => doctor.availability).filter(Boolean))
  );
  const filteredDoctors = doctors.filter(doctor => {
    const query = doctorSearch.trim().toLowerCase();
    return (
      (!query ||
        `${doctor.name} ${doctor.specialty} ${doctor.experience} ${doctor.hospital}`
          .toLowerCase()
          .includes(query)) &&
      (specialtyFilter === "All specialties" ||
        doctor.specialty === specialtyFilter) &&
      (languageFilter === "All languages" ||
        doctor.languages
          .toLowerCase()
          .includes(languageFilter.toLowerCase())) &&
      (availabilityFilter === "All availability" ||
        doctor.availability === availabilityFilter)
    );
  });
  const selectedDoctor = doctors.find(doctor => doctor.id === selectedDoctorId);
  const chooseDoctor = (doctor: (typeof doctors)[number]) => {
    setSelectedDoctorId(doctor.id);
    setClinician(doctor.name);
    setHospitalName(doctor.hospital);
    toast.success(`${doctor.name} selected for your appointment`);
  };
  const scrollTo = (id: string) =>
    document
      .getElementById(id)
      ?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <main className="portal-shell patient-reference-portal">
      <PortalHeader
        title="Patient Portal"
        subtitle="Your appointments, records, and support"
        name={snapshot.profile?.displayName || "Patient"}
        logout={logout}
      />
      <div className="portal-body">
        <section className="patient-welcome-card">
          <div>
            <div className="eyebrow">
              MEDNEXUS GENERAL HOSPITAL · PATIENT PORTAL
            </div>
            <h1>Hello, {snapshot.profile?.displayName || "Patient"}</h1>
            <p>
              Your appointments, records, and healthcare support in one secure
              place.
            </p>
          </div>
          <div className="patient-welcome-actions">
            <button
              className="button button-primary"
              onClick={() => scrollTo("patient-booking")}
            >
              <CalendarDays size={15} /> Book Appointment
            </button>
            <button
              className="button button-secondary"
              onClick={() => scrollTo("patient-records")}
            >
              <FileText size={15} /> My Records
            </button>
          </div>
        </section>
        <div className="portal-role-banner patient">
          <UserRound size={18} />
          <div>
            <strong>Private Patient Workspace</strong>
            <span>
              Only your records, appointments and requests are shown to this
              authenticated account.
            </span>
          </div>
          <span className="portal-badge">Patient</span>
        </div>
        <section className="portal-panel doctor-directory">
          <div className="portal-panel-heading">
            <div>
              <div className="eyebrow">Care team directory</div>
              <h2>Find your doctor</h2>
              <p>
                Search current clinician profiles and review their listed
                specialty, experience, languages, hospital and availability. No
                example profiles are substituted for administrator-managed
                records.
              </p>
            </div>
            <Stethoscope size={20} />
          </div>
          <div className="patient-directory-filters">
            <label className="patient-doctor-search">
              <span>Search doctor</span>
              <input
                value={doctorSearch}
                onChange={event => setDoctorSearch(event.target.value)}
                placeholder="Name, specialty or experience"
                aria-label="Search doctors"
              />
            </label>
            <label>
              <span>Specialty</span>
              <select
                value={specialtyFilter}
                onChange={event => setSpecialtyFilter(event.target.value)}
              >
                <option>All specialties</option>
                {specialties.map(value => (
                  <option key={value}>{value}</option>
                ))}
              </select>
            </label>
            <label>
              <span>Language</span>
              <select
                value={languageFilter}
                onChange={event => setLanguageFilter(event.target.value)}
              >
                <option>All languages</option>
                {languages.map(value => (
                  <option key={value}>{value}</option>
                ))}
              </select>
            </label>
            <label>
              <span>Availability</span>
              <select
                value={availabilityFilter}
                onChange={event => setAvailabilityFilter(event.target.value)}
              >
                <option>All availability</option>
                {availabilityOptions.map(value => (
                  <option key={value}>{value}</option>
                ))}
              </select>
            </label>
          </div>
          <div className="doctor-grid">
            {filteredDoctors.map(doctor => (
              <article
                className={`doctor-card ${selectedDoctorId === doctor.id ? "selected" : ""}`}
                key={doctor.id}
              >
                <img
                  src={doctor.image}
                  alt={`${doctor.name}, ${doctor.specialty}`}
                />
                <div className="doctor-card-content">
                  <div className="doctor-card-topline">
                    <span className="doctor-specialty">{doctor.specialty}</span>
                    <span className="doctor-rating">
                      <Star size={13} fill="currentColor" /> {doctor.rating}{" "}
                      <small>({doctor.reviews})</small>
                    </span>
                  </div>
                  <h3>{doctor.name}</h3>
                  <p className="doctor-experience">
                    {doctor.experience} experience · {doctor.languages}
                  </p>
                  <p className="doctor-hospital">{doctor.hospital}</p>
                  <div className="doctor-card-footer">
                    <span className="doctor-availability">
                      <span className="availability-dot" />{" "}
                      {doctor.availability}
                    </span>
                    <button
                      className={`button ${selectedDoctorId === doctor.id ? "button-primary" : "button-secondary"} tiny`}
                      onClick={() => setSelectedDoctorId(doctor.id)}
                    >
                      {selectedDoctorId === doctor.id
                        ? "Profile selected"
                        : "View Profile"}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
          {!filteredDoctors.length && (
            <div className="portal-empty">
              <Stethoscope size={18} />
              <span>
                {doctors.length
                  ? "No current doctor profiles match these filters."
                  : "No active doctor profiles are configured yet. An authorized administrator must add clinicians before appointments can be requested."}
              </span>
            </div>
          )}
          {selectedDoctor && (
            <section className="patient-selected-profile">
              <div className="eyebrow">Selected Doctor Profile</div>
              <div className="patient-selected-profile-row">
                <img
                  src={selectedDoctor.image}
                  alt={`${selectedDoctor.name}, ${selectedDoctor.specialty}`}
                />
                <div>
                  <span className="doctor-specialty">
                    {selectedDoctor.specialty}
                  </span>
                  <h3>{selectedDoctor.name}</h3>
                  <p>
                    {selectedDoctor.experience} experience ·{" "}
                    {selectedDoctor.languages}
                  </p>
                  <p>
                    {selectedDoctor.hospital} · {selectedDoctor.availability}
                  </p>
                  <small>
                    Profile and availability are provided by the current
                    clinician directory.
                  </small>
                </div>
                <button
                  className="button button-primary"
                  onClick={() => {
                    chooseDoctor(selectedDoctor);
                    scrollTo("patient-booking");
                  }}
                >
                  <CalendarDays size={15} /> Book Appointment
                </button>
              </div>
            </section>
          )}
        </section>
        <div id="patient-records">
          <MyHealthProfile
            displayName={snapshot.profile?.displayName || "Patient"}
            onSaved={refresh}
          />
          <PatientClinicalHistory snapshot={snapshot} />
        </div>
        <div className="portal-grid">
          <div className="portal-column">
            <ProfileForm profile={snapshot.profile} onSaved={refresh} />
            <section className="portal-panel" id="patient-booking">
              <div className="portal-panel-heading">
                <div>
                  <div className="eyebrow">Care access</div>
                  <h2>Book an appointment</h2>
                  <p>
                    Your selected doctor will receive the request for
                    confirmation.
                  </p>
                </div>
                <CalendarDays size={20} />
              </div>
              <form
                className="portal-form"
                onSubmit={event => {
                  event.preventDefault();
                  appointmentMutation.mutate({
                    hospitalName,
                    clinician,
                    appointmentAt: new Date(appointmentAt).toISOString(),
                    reason,
                  });
                }}
              >
                <label>
                  Hospital
                  <select
                    value={hospitalName}
                    onChange={event => setHospitalName(event.target.value)}
                  >
                    <option>Northbridge General Hospital</option>
                    <option>Saint Elara Medical Centre</option>
                    <option>Meridian South Hospital</option>
                  </select>
                </label>
                <label>
                  Selected doctor
                  <input
                    value={clinician}
                    readOnly
                    required
                    placeholder={
                      doctors.length
                        ? "Choose a doctor above"
                        : "No clinician profiles configured"
                    }
                  />
                </label>
                <label>
                  Date and time
                  <input
                    type="datetime-local"
                    value={appointmentAt}
                    onChange={event => setAppointmentAt(event.target.value)}
                    required
                  />
                </label>
                <label>
                  Reason for visit
                  <textarea
                    value={reason}
                    onChange={event => setReason(event.target.value)}
                    minLength={5}
                    required
                  />
                </label>
                <button
                  className="button button-primary"
                  disabled={appointmentMutation.isPending || !doctors.length}
                >
                  {appointmentMutation.isPending
                    ? "Submitting…"
                    : doctors.length
                      ? "Request appointment"
                      : "No doctors available yet"}
                </button>
              </form>
            </section>
            <section className="portal-panel">
              <div className="portal-panel-heading">
                <div>
                  <div className="eyebrow">Patient support</div>
                  <h2>Submit a service request</h2>
                  <p>
                    Ask for non-emergency hospital support. Do not include
                    highly sensitive information.
                  </p>
                </div>
                <MessageSquare size={20} />
              </div>
              <form
                className="portal-form"
                onSubmit={event => {
                  event.preventDefault();
                  requestMutation.mutate({
                    hospitalName,
                    category,
                    description,
                  });
                }}
              >
                <label>
                  Request type
                  <select
                    value={category}
                    onChange={event => setCategory(event.target.value)}
                  >
                    <option>General support</option>
                    <option>Records request</option>
                    <option>Accessibility support</option>
                    <option>Billing question</option>
                  </select>
                </label>
                <label>
                  Describe what you need
                  <textarea
                    value={description}
                    onChange={event => setDescription(event.target.value)}
                    minLength={5}
                    required
                  />
                </label>
                <button
                  className="button button-secondary"
                  disabled={requestMutation.isPending}
                >
                  {requestMutation.isPending
                    ? "Submitting…"
                    : "Send service request"}
                </button>
              </form>
            </section>
          </div>
          <div className="portal-column">
            <section className="portal-panel">
              <div className="portal-panel-heading">
                <div>
                  <div className="eyebrow">Your care timeline</div>
                  <h2>Appointments</h2>
                </div>
                <CalendarDays size={20} />
              </div>
              {snapshot.appointments?.length ? (
                <div className="portal-list">
                  {snapshot.appointments.map((item: any) => (
                    <div className="portal-list-item" key={item.id}>
                      <div className="portal-list-icon">
                        <CalendarDays size={16} />
                      </div>
                      <div>
                        <strong>{item.hospitalName}</strong>
                        <span>
                          {item.clinician} · {dateLabel(item.appointmentAt)}
                        </span>
                        <small>{item.reason}</small>
                      </div>
                      <div className="portal-list-actions">
                        <span className={`portal-status ${item.status}`}>
                          {item.status}
                        </span>
                        {["requested", "confirmed"].includes(item.status) && (
                          <button
                            className="icon-button"
                            aria-label="Cancel appointment"
                            onClick={() =>
                              cancelMutation.mutate({
                                appointmentId: String(item.id),
                              })
                            }
                          >
                            <XCircle size={15} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="portal-empty">
                  <CalendarDays size={18} />
                  <span>No appointments yet.</span>
                </div>
              )}
            </section>
            <section className="portal-panel">
              <div className="portal-panel-heading">
                <div>
                  <div className="eyebrow">Support tracking</div>
                  <h2>Service requests</h2>
                </div>
                <FileText size={20} />
              </div>
              {snapshot.serviceRequests?.length ? (
                <div className="portal-list">
                  {snapshot.serviceRequests.map((item: any) => (
                    <div className="portal-list-item" key={item.id}>
                      <div className="portal-list-icon">
                        <FileText size={16} />
                      </div>
                      <div>
                        <strong>{item.category}</strong>
                        <span>
                          {item.hospitalName} · {dateLabel(item.createdAt)}
                        </span>
                        <small>{item.staffReply || item.description}</small>
                      </div>
                      <span className={`portal-status ${item.status}`}>
                        {item.status.replace("_", " ")}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="portal-empty">
                  <FileText size={18} />
                  <span>No service requests yet.</span>
                </div>
              )}
            </section>
            <section className="portal-panel">
              <div className="portal-panel-heading">
                <div>
                  <div className="eyebrow">Updates</div>
                  <h2>Notifications</h2>
                </div>
                <MessageSquare size={20} />
              </div>
              {snapshot.notifications?.length ? (
                <div className="portal-list">
                  {snapshot.notifications.map((item: any) => (
                    <div className="portal-list-item" key={item.id}>
                      <div className="portal-list-icon">
                        <MessageSquare size={16} />
                      </div>
                      <div>
                        <strong>{item.title}</strong>
                        <span>{dateLabel(item.createdAt)}</span>
                        <small>{item.body}</small>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="portal-empty">
                  <MessageSquare size={18} />
                  <span>No notifications.</span>
                </div>
              )}
            </section>
          </div>
        </div>
        <p className="portal-disclaimer">
          This portal is not an emergency service. Follow your organization’s
          approved clinical, privacy, and security procedures.
        </p>
      </div>
    </main>
  );
}

function StaffApplication({
  snapshot,
  refresh,
  logout,
}: {
  snapshot: any;
  refresh: () => void;
  logout: () => void;
}) {
  const [hospitalName, setHospitalName] = useState(
    "Northbridge General Hospital"
  );
  const [employeeId, setEmployeeId] = useState("");
  const [requestedRole, setRequestedRole] = useState<
    "hospital_staff" | "pharmacist" | "coordinator"
  >("hospital_staff");
  const mutation = trpc.portal.applyForStaff.useMutation({
    onSuccess: () => {
      toast.success("Application submitted for administrator review");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  const application = snapshot.staffApplication;
  return (
    <main className="portal-shell">
      <PortalHeader
        title="Hospital staff access"
        subtitle="Verification required before staff access"
        logout={logout}
      />
      <div className="portal-body narrow-portal">
        <div className="portal-role-banner pending">
          <Clock3 size={18} />
          <div>
            <strong>
              {application?.status === "pending"
                ? "Application pending"
                : "Staff access request"}
            </strong>
            <span>
              {application?.status === "pending"
                ? "An authorized administrator must approve this account."
                : "Submit employment details for review."}
            </span>
          </div>
          <span className="portal-badge">
            {application?.status || "Not submitted"}
          </span>
        </div>
        {application?.status === "pending" ? (
          <section className="portal-panel approval-wait">
            <ShieldCheck size={30} />
            <h2>Approval is intentionally not automatic.</h2>
            <p>
              Your hospital affiliation and employee ID are waiting for an
              authorized administrator. Until approval, staff APIs and
              dashboards remain blocked.
            </p>
            <Link href="/" className="text-link">
              <ArrowLeft size={14} /> Return to MEDNEXUS site
            </Link>
          </section>
        ) : (
          <section className="portal-panel">
            <div className="portal-panel-heading">
              <div>
                <div className="eyebrow">Staff verification</div>
                <h2>Request hospital access</h2>
                <p>
                  Selecting a role never grants privileges. Your application
                  remains pending until approved.
                </p>
              </div>
              <Hospital size={20} />
            </div>
            <form
              className="portal-form"
              onSubmit={event => {
                event.preventDefault();
                mutation.mutate({ hospitalName, employeeId, requestedRole });
              }}
            >
              <label>
                Hospital or organization
                <select
                  value={hospitalName}
                  onChange={event => setHospitalName(event.target.value)}
                >
                  <option>Northbridge General Hospital</option>
                  <option>Saint Elara Medical Centre</option>
                  <option>Meridian South Hospital</option>
                </select>
              </label>
              <label>
                Employee ID
                <input
                  value={employeeId}
                  onChange={event => setEmployeeId(event.target.value)}
                  minLength={3}
                  required
                  placeholder="e.g. EMP-2048"
                />
              </label>
              <label>
                Requested staff function
                <select
                  value={requestedRole}
                  onChange={event =>
                    setRequestedRole(event.target.value as typeof requestedRole)
                  }
                >
                  <option value="hospital_staff">Hospital staff</option>
                  <option value="pharmacist">Pharmacist</option>
                  <option value="coordinator">Emergency coordinator</option>
                </select>
              </label>
              <button
                className="button button-primary"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? "Submitting…" : "Submit for approval"}
              </button>
            </form>
          </section>
        )}
        <p className="portal-disclaimer">
          Production access requires verified employment checks, organization
          membership, monitoring, and a security/privacy review.
        </p>
      </div>
    </main>
  );
}

function StaffPortal({
  snapshot,
  refresh,
  logout,
}: {
  snapshot: any;
  refresh: () => void;
  logout: () => void;
}) {
  const mutation = trpc.portal.updateStaffWorkflow.useMutation({
    onSuccess: () => {
      toast.success("Workflow updated");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  const uploadMutation = trpc.portal.uploadPrescription.useMutation({
    onSuccess: () => {
      toast.success("Prescription uploaded to the patient record");
      setMedication("");
      setDosage("");
      setInstructions("");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  const eligibleAppointments =
    snapshot.staffAppointments?.filter((item: any) =>
      ["confirmed", "completed"].includes(item.status)
    ) || [];
  const [appointmentId, setAppointmentId] = useState(
    eligibleAppointments[0] ? String(eligibleAppointments[0].id) : ""
  );
  const [medication, setMedication] = useState("");
  const [dosage, setDosage] = useState("");
  const [instructions, setInstructions] = useState("");
  return (
    <main className="portal-shell">
      <PortalHeader
        title="Hospital staff portal"
        subtitle="Approved organization workspace"
        logout={logout}
      />
      <div className="portal-body">
        <div className="portal-role-banner staff">
          <Hospital size={18} />
          <div>
            <strong>Approved staff access</strong>
            <span>
              Records are restricted to your approved organization and
              permission set.
            </span>
          </div>
          <span className="portal-badge">Staff</span>
        </div>
        <section className="portal-panel prescription-upload">
          <div className="portal-panel-heading">
            <div>
              <div className="eyebrow">Clinical documentation</div>
              <h2>Upload prescription</h2>
              <p>
                Only confirmed or completed appointments in your approved
                organization can receive a prescription.
              </p>
            </div>
            <Stethoscope size={20} />
          </div>
          <form
            className="portal-form"
            onSubmit={event => {
              event.preventDefault();
              uploadMutation.mutate({
                appointmentId,
                medication,
                dosage,
                instructions,
              });
            }}
          >
            <label>
              Authorized patient appointment
              <select
                value={appointmentId}
                onChange={event => setAppointmentId(event.target.value)}
                required
              >
                <option value="">Choose an appointment</option>
                {eligibleAppointments.map((item: any) => (
                  <option value={String(item.id)} key={item.id}>
                    {item.patient?.displayName || "Authorized patient"} ·{" "}
                    {item.clinician} · {dateLabel(item.appointmentAt)}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Medication
              <input
                value={medication}
                onChange={event => setMedication(event.target.value)}
                minLength={2}
                maxLength={180}
                required
                placeholder="e.g. Amoxicillin"
              />
            </label>
            <label>
              Dosage
              <input
                value={dosage}
                onChange={event => setDosage(event.target.value)}
                minLength={2}
                maxLength={180}
                required
                placeholder="e.g. 500 mg twice daily"
              />
            </label>
            <label>
              Instructions
              <textarea
                value={instructions}
                onChange={event => setInstructions(event.target.value)}
                minLength={5}
                maxLength={2000}
                required
                placeholder="How and when should the patient take it?"
              />
            </label>
            <button
              className="button button-primary"
              disabled={uploadMutation.isPending || !appointmentId}
            >
              {uploadMutation.isPending ? "Uploading…" : "Upload prescription"}
            </button>
          </form>
        </section>
        <div className="portal-grid">
          <section className="portal-panel">
            <div className="portal-panel-heading">
              <div>
                <div className="eyebrow">Assigned care workflow</div>
                <h2>Appointments</h2>
                <p>Only appointments at your approved hospital are visible.</p>
              </div>
              <CalendarDays size={20} />
            </div>
            <div className="portal-list">
              {snapshot.staffAppointments?.map((item: any) => (
                <div className="portal-list-item" key={item.id}>
                  <div className="portal-list-icon">
                    <CalendarDays size={16} />
                  </div>
                  <div>
                    <strong>
                      {item.hospitalName} · {item.clinician}
                    </strong>
                    <span>
                      {dateLabel(item.appointmentAt)} ·{" "}
                      {item.patient?.displayName || "Authorized patient"}
                      {item.patient?.phone ? ` · ${item.patient.phone}` : ""}
                    </span>
                    <small>{item.reason}</small>
                  </div>
                  <div className="portal-list-actions">
                    <span className={`portal-status ${item.status}`}>
                      {item.status}
                    </span>
                    {item.status === "requested" && (
                      <button
                        className="button button-secondary tiny"
                        onClick={() =>
                          mutation.mutate({
                            type: "appointment",
                            id: String(item.id),
                            status: "confirmed",
                            note: "Confirmed by approved hospital staff.",
                          })
                        }
                      >
                        Confirm
                      </button>
                    )}
                    {item.status === "confirmed" && (
                      <button
                        className="button button-secondary tiny"
                        onClick={() =>
                          mutation.mutate({
                            type: "appointment",
                            id: String(item.id),
                            status: "completed",
                            note: "Visit completed.",
                          })
                        }
                      >
                        Complete
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {!snapshot.staffAppointments?.length && (
                <div className="portal-empty">
                  <CalendarDays size={18} />
                  <span>No appointments in your organization.</span>
                </div>
              )}
            </div>
          </section>
          <section className="portal-panel">
            <div className="portal-panel-heading">
              <div>
                <div className="eyebrow">Patient support queue</div>
                <h2>Service requests</h2>
                <p>
                  Patient identity is minimized; access is limited to workflow
                  handling.
                </p>
              </div>
              <MessageSquare size={20} />
            </div>
            <div className="portal-list">
              {snapshot.staffRequests?.map((item: any) => (
                <div className="portal-list-item" key={item.id}>
                  <div className="portal-list-icon">
                    <FileText size={16} />
                  </div>
                  <div>
                    <strong>{item.category}</strong>
                    <span>
                      {item.hospitalName} ·{" "}
                      {item.patient?.displayName || "Authorized patient"}
                    </span>
                    <small>{item.description}</small>
                  </div>
                  <div className="portal-list-actions">
                    <span className={`portal-status ${item.status}`}>
                      {item.status.replace("_", " ")}
                    </span>
                    {item.status === "submitted" && (
                      <button
                        className="button button-secondary tiny"
                        onClick={() =>
                          mutation.mutate({
                            type: "service_request",
                            id: String(item.id),
                            status: "in_review",
                            note: "Request is in review by hospital staff.",
                          })
                        }
                      >
                        Review
                      </button>
                    )}
                    {item.status === "in_review" && (
                      <button
                        className="button button-secondary tiny"
                        onClick={() =>
                          mutation.mutate({
                            type: "service_request",
                            id: String(item.id),
                            status: "resolved",
                            note: "Hospital support response recorded.",
                          })
                        }
                      >
                        Resolve
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {!snapshot.staffRequests?.length && (
                <div className="portal-empty">
                  <MessageSquare size={18} />
                  <span>No service requests in your organization.</span>
                </div>
              )}
            </div>
          </section>
        </div>
        <p className="portal-disclaimer">
          Approved staff cannot approve themselves, change roles, or access
          other organizations. This workspace uses server-authorized records.
        </p>
      </div>
    </main>
  );
}

function AdminPortal({
  snapshot,
  refresh,
  logout,
}: {
  snapshot: any;
  refresh: () => void;
  logout: () => void;
}) {
  const review = trpc.portal.reviewStaffApplication.useMutation({
    onSuccess: () => {
      toast.success("Application status updated");
      refresh();
    },
    onError: error => toast.error(error.message),
  });
  return (
    <main className="portal-shell">
      <PortalHeader
        title="Administrator portal"
        subtitle="Restricted approval and oversight"
        logout={logout}
      />
      <div className="portal-body">
        <div className="portal-role-banner admin">
          <Users size={18} />
          <div>
            <strong>Administrator controls</strong>
            <span>
              Approval actions are server-authorized and audit logged.
            </span>
          </div>
          <span className="portal-badge">Admin</span>
        </div>
        <section className="portal-panel">
          <div className="portal-panel-heading">
            <div>
              <div className="eyebrow">Access governance</div>
              <h2>Staff applications</h2>
              <p>
                Review employment details before staff privileges become
                available.
              </p>
            </div>
            <ShieldCheck size={20} />
          </div>
          <div className="admin-table">
            {snapshot.pendingApplications?.length ? (
              snapshot.pendingApplications.map((item: any) => (
                <div className="admin-row" key={item.id}>
                  <div>
                    <strong>{item.applicantName}</strong>
                    <span>
                      {item.email || "No email"} · {item.employeeId}
                    </span>
                  </div>
                  <div>
                    <strong>{item.hospitalName}</strong>
                    <span>
                      {item.requestedRole.replace("_", " ")} · {item.status}
                    </span>
                  </div>
                  <div className="admin-actions">
                    {item.status === "pending" ? (
                      <>
                        <button
                          className="button button-primary tiny"
                          onClick={() =>
                            review.mutate({
                              openId: item.openId,
                              status: "approved",
                              reviewNote:
                                "Employment details reviewed by an authorized administrator.",
                            })
                          }
                        >
                          <Check size={13} /> Approve
                        </button>
                        <button
                          className="button button-secondary tiny"
                          onClick={() =>
                            review.mutate({
                              openId: item.openId,
                              status: "rejected",
                              reviewNote:
                                "Unable to verify employment details at this time.",
                            })
                          }
                        >
                          <XCircle size={13} /> Reject
                        </button>
                      </>
                    ) : (
                      <button
                        className="button button-secondary tiny"
                        onClick={() =>
                          review.mutate({
                            openId: item.openId,
                            status:
                              item.status === "suspended"
                                ? "approved"
                                : "suspended",
                            reviewNote:
                              item.status === "suspended"
                                ? "Access reinstated by administrator."
                                : "Access suspended by administrator.",
                          })
                        }
                      >
                        {item.status === "suspended" ? "Reinstate" : "Suspend"}
                      </button>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="portal-empty">
                <Check size={18} />
                <span>No staff applications to review.</span>
              </div>
            )}
          </div>
        </section>
        <section className="portal-panel admin-boundary">
          <ShieldCheck size={18} />
          <div>
            <strong>Admin boundary</strong>
            <p>
              Administrator privileges come from the server-managed user role
              and cannot be created through this portal. Every approval
              transition is written to the security audit log.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}

export default function Portal() {
  const [location] = useLocation();
  const auth = useAuth();
  const snapshotQuery = trpc.portal.snapshot.useQuery(undefined, {
    enabled: auth.isAuthenticated,
    retry: false,
  });
  if (auth.loading || (auth.isAuthenticated && snapshotQuery.isLoading))
    return (
      <main className="portal-shell">
        <div className="portal-loading">
          <Clock3 className="spin" size={20} /> Checking your protected
          workspace…
        </div>
      </main>
    );
  if (!auth.isAuthenticated)
    return (
      <LoginGate
        mode={location.startsWith("/app/staff") ? "staff" : "patient"}
      />
    );
  const snapshot = snapshotQuery.data;
  if (!snapshot)
    return (
      <main className="portal-shell">
        <div className="portal-login">
          <XCircle size={28} />
          <h1>Portal access unavailable.</h1>
          <p>
            {snapshotQuery.error?.message ||
              "The server could not load your access record."}
          </p>
          <button
            className="button button-secondary"
            onClick={() => snapshotQuery.refetch()}
          >
            Try again
          </button>
        </div>
      </main>
    );
  if (snapshot.role === "patient")
    return (
      <PatientPortal
        snapshot={snapshot}
        refresh={() => snapshotQuery.refetch()}
        logout={auth.logout}
      />
    );
  if (snapshot.role === "staff" || snapshot.role === "admin")
    return snapshot.role === "admin" ? (
      <AdminPortal
        snapshot={snapshot}
        refresh={() => snapshotQuery.refetch()}
        logout={auth.logout}
      />
    ) : (
      <StaffPortal
        snapshot={snapshot}
        refresh={() => snapshotQuery.refetch()}
        logout={auth.logout}
      />
    );
  return (
    <StaffApplication
      snapshot={snapshot}
      refresh={() => snapshotQuery.refetch()}
      logout={auth.logout}
    />
  );
}
