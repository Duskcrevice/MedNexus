import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  BookOpen,
  Bot,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Download,
  FileCheck2,
  FileText,
  FileUp,
  HeartPulse,
  HelpCircle,
  Info,
  LockKeyhole,
  MoreHorizontal,
  RefreshCw,
  Save,
  Search,
  Send,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Stethoscope,
  Trash2,
  UploadCloud,
  UserRound,
  Volume2,
  X,
} from "lucide-react";
import {
  defaultProfile,
  evaluateProfile,
  metricDefinitions,
  type BiologicalSex,
  type ClinicalProfile,
  type MetricKey,
  type Status,
} from "@/lib/clinicalEngine";
import { extractDocumentContent } from "@/lib/pdfExtractor";
import type { ParsedLabReport, Biomarker } from "@/lib/reportTypes";
import { VisualRangeBar } from "@/components/VisualRangeBar";
import { OriginalVsSimplifiedCard } from "@/components/OriginalVsSimplifiedCard";
import { MednexusChatBot } from "@/components/MednexusChatBot";
import { trpc } from "@/lib/trpc";

// Sample demonstration reports for 1-click testing without local files
const SAMPLE_REPORTS: Record<
  string,
  { title: string; fileName: string; text: string }
> = {
  cbc: {
    title: "Complete Blood Count (CBC) - Iron Deficiency Anemia",
    fileName: "Patient_CBC_Lab_Report_2026.pdf",
    text: `COMPLETED LABORATORY INVESTIGATION
Patient Name: Demo Patient | Age: 35 | Sex: Female
Date: October 2026 | Ordering Physician: Dr. Ananya Roy, MD

HAEMATOLOGY - COMPLETE BLOOD COUNT (CBC)
Test Name                      Result      Unit        Reference Interval    Flag
Hemoglobin                     10.2        g/dL        12.0 - 16.0           LOW
RBC Count                      3.8         M/µL        4.0 - 5.2             LOW
Hematocrit (PCV)               31.5        %           36.0 - 46.0           LOW
MCV                            76.0        fL          80.0 - 99.0           LOW
MCH                            25.2        pg          27.0 - 33.0           LOW
MCHC                           31.2        g/dL        32.0 - 36.0           LOW
RDW                            16.1        %           11.5 - 14.5           HIGH
Total Leukocyte Count (WBC)    8,500       /µL         4,000 - 10,000        NORMAL
Platelet Count                 250,000     /µL         150,000 - 400,000     NORMAL
Ferritin                       11.4        ng/mL       15.0 - 150.0          LOW
Serum Iron                     45          µg/dL       60 - 170              LOW

MICROSCOPIC EXAMINATION:
Peripheral blood smear reveals moderate microcytosis and hypochromia with anisopoikilocytosis. Platelets are morphologically adequate with no clumping. White cell morphology is normal. Impression consistent with microcytic hypochromic anemia, suspicious for iron deficiency.`,
  },
  cmp: {
    title: "Comprehensive Metabolic & Kidney Panel (CMP)",
    fileName: "Metabolic_Renal_Panel_Oct2026.pdf",
    text: `CLINICAL BIOCHEMISTRY PANEL
Patient Name: Demo Patient | Age: 35 | Sex: Female

Test Name                      Result      Unit        Reference Interval    Flag
Fasting Blood Glucose          108         mg/dL       70 - 99               HIGH
HbA1c                          5.9         %           4.0 - 5.6             HIGH
Serum Creatinine               1.35        mg/dL       0.60 - 1.10           HIGH
eGFR (CKD-EPI)                 52          mL/min      > 60                  LOW
Blood Urea Nitrogen (BUN)      24          mg/dL       7 - 20                HIGH
Sodium                         139         mEq/L       135 - 145             NORMAL
Potassium                      4.4         mEq/L       3.5 - 5.0             NORMAL
Total Calcium                  9.4         mg/dL       8.5 - 10.2            NORMAL
Total Bilirubin                0.8         mg/dL       0.2 - 1.2             NORMAL
ALT (SGPT)                     28          U/L         7 - 35                NORMAL

CLINICAL IMPRESSION:
Mildly impaired fasting glucose with early pre-diabetic glycemic range. Serum creatinine elevation with eGFR of 52 mL/min indicates Stage 3a chronic kidney filtration reduction. Clinical correlation with blood pressure and hydration status advised.`,
  },
  echo: {
    title: "Cardiology Echocardiogram & Imaging Report",
    fileName: "Transthoracic_Echocardiogram_Echo.pdf",
    text: `NON-INVASIVE CARDIOLOGY REPORT - TRANSTHORACIC ECHOCARDIOGRAM
Patient Name: Demo Patient | Age: 35 | Sex: Female

FINDINGS & PARAMETERS:
Left Ventricular Ejection Fraction (LVEF): 58% (Normal >= 55%)
Left Ventricular Internal Dimension Diastole (LVIDd): 4.6 cm (Normal: 3.8 - 5.2 cm)
Interventricular Septal Thickness (IVSd): 1.1 cm (Normal: 0.6 - 1.0 cm) - MILD CONCENTRIC REMODELING
Aortic Root: 3.1 cm (Normal <= 3.7 cm)
Left Atrial Volume Index: 36 mL/m2 (Normal <= 34 mL/m2) - MILD LA ENLARGEMENT

DIAGNOSTIC SECTIONS & IMPRESSIONS:
1. Left Ventricular Systolic Function: Normal global left ventricular systolic function with preserved EF of 58%. No resting regional wall motion abnormalities detected.
2. Diastolic Dynamics: Mitral inflow E/A ratio 0.72 with septal e' 6.8 cm/s consistent with Grade 1 diastolic dysfunction (impaired myocardial relaxation pattern).
3. Valvular Assessment: Trace to mild physiological mitral regurgitation. Aortic valve is trileaflet with normal excursion and no stenosis.
4. Summary: Concentric remodeling with Grade 1 diastolic dysfunction. Preserved systolic ejection fraction.`,
  },
};

import "./lab-report-analyzer.css";

export default function LabReportAnalyzer() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInitialQuery, setChatInitialQuery] = useState<string>("");

  // Decoupled Uploaded Lab Report State (Clean: Starts with null!)
  const [uploadedReport, setUploadedReport] = useState<ParsedLabReport | null>(
    null
  );
  const [ownershipWarning, setOwnershipWarning] = useState<string | null>(null);
  const [pendingReportSave, setPendingReportSave] =
    useState<ParsedLabReport | null>(null);
  const authQuery = trpc.auth.me.useQuery();
  const portalQuery = trpc.portal.snapshot.useQuery(undefined, {
    enabled: !!authQuery.data,
    retry: false,
  });
  const saveReportMutation = trpc.portal.saveMedicalRecord.useMutation();
  const [isParsingReport, setIsParsingReport] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // Decoupled Demo Vitals / Simulated Wearable State
  const [profile, setProfile] = useState<ClinicalProfile>(() => {
    try {
      const saved = localStorage.getItem("mednexus-patient-vitals");
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...defaultProfile,
          ...parsed,
          vitals: { ...defaultProfile.vitals, ...(parsed.vitals || {}) },
        };
      }
    } catch {}
    return defaultProfile;
  });
  const [profileSaved, setProfileSaved] = useState(false);
  const authenticatedName =
    (portalQuery.data?.profile as { displayName?: string } | null)
      ?.displayName ||
    authQuery.data?.name ||
    "";
  const authenticatedPatient =
    portalQuery.data?.role === "patient" && !!portalQuery.data?.profile;
  useEffect(() => {
    if (authenticatedName)
      setProfile(current => ({ ...current, name: authenticatedName }));
  }, [authenticatedName]);
  const [activeMetric, setActiveMetric] = useState<MetricKey>("hemoglobin");
  const [showAllMetrics, setShowAllMetrics] = useState(false);
  const [doctorRequested, setDoctorRequested] = useState(false);

  // Clinical evaluation of Demo Vitals
  const clinicalResults = useMemo(() => evaluateProfile(profile), [profile]);
  const activeResult =
    clinicalResults.find(item => item.key === activeMetric) ||
    clinicalResults[0];
  const visibleMetrics = showAllMetrics
    ? metricDefinitions
    : metricDefinitions.slice(0, 6);

  // Triage grouping of Uploaded Biomarkers:
  // "Needs Doctor Follow-Up" vs "Normal / Within Range"
  const attentionBiomarkers = useMemo(() => {
    if (!uploadedReport || !uploadedReport.biomarkers) return [];
    return uploadedReport.biomarkers.filter(b => b.status === "attention");
  }, [uploadedReport]);

  const normalBiomarkers = useMemo(() => {
    if (!uploadedReport || !uploadedReport.biomarkers) return [];
    return uploadedReport.biomarkers.filter(b => b.status === "normal");
  }, [uploadedReport]);

  const saveReportForAuthenticatedPatient = async (data: ParsedLabReport) => {
    if (!authenticatedPatient) return;
    const accountName = authenticatedName.trim();
    const documentName = (data.patientName || "").trim();
    if (
      documentName &&
      !["patient", "demo patient"].includes(documentName.toLowerCase()) &&
      accountName &&
      documentName.toLowerCase() !== accountName.toLowerCase()
    ) {
      setOwnershipWarning(
        `The uploaded report names “${documentName}”, but you are signed in as “${accountName}”. Confirm ownership before saving it to your account.`
      );
      setPendingReportSave(data);
      return;
    }
    await saveReportMutation.mutateAsync({
      title: data.reportTitle || data.fileName,
      summary: `${data.summary} Extracted findings: ${data.biomarkers?.map(item => `${item.name}: ${item.valueDisplay || item.value} ${item.unit} (${item.statusLabel})`).join("; ") || "None"}`,
      clinician: "MEDNEXUS AI report analyzer",
    });
  };
  const confirmReportOwnership = async () => {
    if (!pendingReportSave) return;
    const data = pendingReportSave;
    setPendingReportSave(null);
    setOwnershipWarning(null);
    await saveReportForAuthenticatedPatient({
      ...data,
      patientName: authenticatedName,
    });
  };
  // Handle Dynamic File Upload (PDF, TXT, Image)
  const handleFileUpload = async (file?: File) => {
    if (!file) return;
    setIsParsingReport(true);
    setParseError(null);

    try {
      // Extract text or base64 using pdfjs-dist
      const extracted = await extractDocumentContent(file);

      // Call backend ingestion pipeline
      const res = await fetch("/api/parse-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: extracted.fileName,
          mimeType: extracted.mimeType,
          fileText: extracted.text,
          fileBase64: extracted.base64,
          patientDetails: {
            name: profile.name,
            age: profile.age,
            sex: profile.sex,
          },
        }),
      });

      if (!res.ok) {
        throw new Error(`Server ingestion error (Status ${res.status})`);
      }

      const parsedData: ParsedLabReport = await res.json();
      setUploadedReport(parsedData);
      await saveReportForAuthenticatedPatient(parsedData);
    } catch (err: any) {
      console.error("File parsing error:", err);
      setParseError(err.message || "Failed to parse uploaded document.");
    } finally {
      setIsParsingReport(false);
    }
  };

  // Load a sample preset document for instant review
  const loadSampleReport = async (key: string) => {
    const sample = SAMPLE_REPORTS[key];
    if (!sample) return;
    setIsParsingReport(true);
    setParseError(null);

    try {
      const res = await fetch("/api/parse-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: sample.fileName,
          mimeType: "text/plain",
          fileText: sample.text,
          patientDetails: {
            name: profile.name,
            age: profile.age,
            sex: profile.sex,
          },
        }),
      });

      if (!res.ok) throw new Error("Failed to ingest sample document");
      const data: ParsedLabReport = await res.json();
      setUploadedReport(data);
      await saveReportForAuthenticatedPatient(data);
    } catch (err: any) {
      console.error(err);
      setParseError("Failed to load sample document.");
    } finally {
      setIsParsingReport(false);
    }
  };

  const handleClearReport = () => {
    setUploadedReport(null);
    setParseError(null);
  };

  const openChatWithQuery = (query: string) => {
    setChatInitialQuery(query);
    setIsChatOpen(true);
  };

  const updateProfile = <K extends keyof ClinicalProfile>(
    key: K,
    value: ClinicalProfile[K]
  ) => {
    setProfile(current => ({ ...current, [key]: value }));
    setProfileSaved(false);
  };

  const updateVital = (key: MetricKey, value: number) => {
    setProfile(current => ({
      ...current,
      vitals: { ...current.vitals, [key]: value },
    }));
    setProfileSaved(false);
  };

  const saveProfile = () => {
    try {
      localStorage.setItem("mednexus-patient-vitals", JSON.stringify(profile));
    } catch {}
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2500);
  };

  const statusClass = (status: Status) =>
    `engine-status engine-status-${status}`;
  const formatValue = (value: number, step: number) =>
    step < 1 ? value.toFixed(1) : value.toLocaleString();
  return (
    <div className="lra-root">
      <div className="lra-toolbar">
        <button
          onClick={() => setIsChatOpen(true)}
          className="topbar-chat-btn"
          title="Open MEDNEXUS AI Clinical Assistant"
        >
          <Sparkles size={14} />
          <span>Ask MEDNEXUS AI</span>
        </button>
      </div>
      <div className="content-wrap">
        {/* Welcome Banner */}
        <div className="welcome-row">
          <div>
            <div className="eyebrow">
              <span className="eyebrow-line" />
              <span>DYNAMIC CLINICAL INGESTION &amp; TRIAGE</span>
            </div>
            <h1>
              AI Medical Report Analyzer<span className="heading-dot">.</span>
            </h1>
            <p className="welcome-copy">
              Upload a medical report for PDF text extraction, lab-value
              analysis, out-of-range detection, plain-English explanations, and
              doctor-ready questions.
            </p>
          </div>

          <div className="trust-badge">
            <ShieldCheck size={16} />
            <span>Document Grounded · Zero Synthetic Overlap</span>
          </div>
        </div>

        {/* CARD 1: DYNAMIC REPORT UPLOAD & EXTRACTION PIPELINE */}
        <section className="bg-white border border-[#e5e1d8] rounded-xl shadow-xs p-6 mb-7">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-4 border-b border-[#ece7de]">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-[#0f766e] uppercase tracking-wider bg-[#e2ede8] px-2 py-0.5 rounded">
                  Document Ingestion Pipeline
                </span>
                {uploadedReport && (
                  <span className="text-xs text-[#52605b] font-medium flex items-center gap-1">
                    <CheckCircle2 size={13} className="text-emerald-600" />
                    Parsed: <strong>{uploadedReport.fileName}</strong>
                  </span>
                )}
              </div>
              <h2 className="font-serif text-2xl font-normal text-[#22302f] mt-1">
                {uploadedReport
                  ? uploadedReport.reportTitle
                  : "Upload Medical Lab or Diagnostic Report"}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.txt,.csv"
                className="hidden"
                onChange={e => handleFileUpload(e.target.files?.[0])}
              />

              {uploadedReport && (
                <button
                  onClick={handleClearReport}
                  className="px-3 py-1.5 text-xs text-[#a84432] hover:bg-[#fae5dc] rounded-lg transition-colors flex items-center gap-1 border border-[#f0c2b6]"
                >
                  <Trash2 size={13} />
                  <span>Clear Report</span>
                </button>
              )}

              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isParsingReport}
                className="px-4 py-2 bg-[#0f766e] hover:bg-[#0c625c] text-white text-xs font-semibold rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <FileUp size={15} />
                <span>
                  {uploadedReport
                    ? "Upload Different Report"
                    : "Upload Document (PDF / Image)"}
                </span>
              </button>
            </div>
          </div>

          {/* Dynamic Drag-and-Drop Dropzone */}
          {!uploadedReport && (
            <div
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
                dragActive
                  ? "border-[#0f766e] bg-[#f2faf7]"
                  : "border-[#d8d2c4] bg-[#faf8f4] hover:border-[#0f766e]"
              }`}
              onDragOver={e => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={e => {
                e.preventDefault();
                setDragActive(false);
                handleFileUpload(e.dataTransfer.files?.[0]);
              }}
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-12 h-12 rounded-full bg-[#e2ede8] text-[#0f766e] mx-auto flex items-center justify-center mb-3">
                {isParsingReport ? (
                  <RefreshCw
                    size={22}
                    className="animate-spin text-[#0f766e]"
                  />
                ) : (
                  <UploadCloud size={24} />
                )}
              </div>

              <strong className="text-sm font-semibold text-[#22302f] block">
                {isParsingReport
                  ? "Analyzing report with MEDNEXUS AI..."
                  : "Drag and drop your lab report here, or browse files"}
              </strong>
              <p className="text-xs text-[#738079] mt-1 max-w-md mx-auto">
                Accepts PDF files, lab photos (PNG, JPG), or text exports. Zero
                hardcoded mock data is applied.
              </p>

              {/* 1-Click Sample Previews for convenient testing */}
              <div className="mt-6 pt-5 border-t border-[#e8e2d5] text-left">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#79857e] block mb-2 text-center">
                  — Or click to load a sample clinical document —
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 max-w-2xl mx-auto">
                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      loadSampleReport("cbc");
                    }}
                    className="p-2.5 text-left bg-white border border-[#ded8cb] hover:border-[#0f766e] hover:bg-[#f3faf7] rounded-lg transition-all cursor-pointer"
                  >
                    <div className="text-[10px] font-bold text-[#0f766e] uppercase">
                      Sample 1
                    </div>
                    <strong className="text-xs text-[#22302f] block truncate">
                      Complete Blood Count (CBC)
                    </strong>
                    <span className="text-[10px] text-[#79857f]">
                      Mild anemia &amp; low iron
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      loadSampleReport("cmp");
                    }}
                    className="p-2.5 text-left bg-white border border-[#ded8cb] hover:border-[#0f766e] hover:bg-[#f3faf7] rounded-lg transition-all cursor-pointer"
                  >
                    <div className="text-[10px] font-bold text-[#0f766e] uppercase">
                      Sample 2
                    </div>
                    <strong className="text-xs text-[#22302f] block truncate">
                      Metabolic &amp; Renal Panel
                    </strong>
                    <span className="text-[10px] text-[#79857f]">
                      Fasting glucose &amp; eGFR
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={e => {
                      e.stopPropagation();
                      loadSampleReport("echo");
                    }}
                    className="p-2.5 text-left bg-white border border-[#ded8cb] hover:border-[#0f766e] hover:bg-[#f3faf7] rounded-lg transition-all cursor-pointer"
                  >
                    <div className="text-[10px] font-bold text-[#0f766e] uppercase">
                      Sample 3
                    </div>
                    <strong className="text-xs text-[#22302f] block truncate">
                      Cardiology Echo Impression
                    </strong>
                    <span className="text-[10px] text-[#79857f]">
                      LVEF &amp; diastolic text
                    </span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {parseError && (
            <div className="mt-3 p-3 bg-[#fff1ea] border border-[#f0cfc1] rounded-lg text-xs text-[#a84432] flex items-center gap-2">
              <AlertTriangle size={15} />
              <span>{parseError}</span>
            </div>
          )}
          {ownershipWarning && (
            <div className="mt-3 p-3 bg-[#fff8e6] border border-[#ead39a] rounded-lg text-xs text-[#765b12]">
              <div className="flex items-center gap-2">
                <AlertTriangle size={15} />
                <span>{ownershipWarning}</span>
              </div>
              <div className="mt-3 flex gap-2">
                <button
                  className="px-3 py-1.5 bg-[#0f766e] text-white rounded-lg"
                  onClick={confirmReportOwnership}
                >
                  Confirm ownership and save
                </button>
                <button
                  className="px-3 py-1.5 border border-[#cbbd96] rounded-lg"
                  onClick={() => {
                    setOwnershipWarning(null);
                    setPendingReportSave(null);
                  }}
                >
                  Do not save
                </button>
              </div>
            </div>
          )}
          {authenticatedPatient && (
            <div className="mt-3 text-xs text-[#52605b]">
              Patient account: <strong>{authenticatedName}</strong>. Reports
              save to this authenticated account only.
            </div>
          )}
          {!authenticatedPatient && authQuery.data && (
            <div className="mt-3 text-xs text-[#a84432]">
              No registered patient profile was found for this authenticated
              account, so this report remains unsaved.
            </div>
          )}

          {/* UPLOADED REPORT OVERVIEW & DOCTOR QUESTION GENERATOR CHIPS */}
          {uploadedReport && (
            <div className="mt-4 space-y-6">
              {/* Summary Banner */}
              <div className="p-4 bg-[#f4f8f6] border border-[#cbe3da] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#0f766e]">
                    <Sparkles size={14} />
                    <span>MEDNEXUS AI Clinical Synthesis</span>
                  </div>
                  <p className="text-[13px] text-[#2c3f39] mt-1 leading-relaxed font-serif">
                    {uploadedReport.summary}
                  </p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-white border border-[#cde2da] text-xs font-semibold text-[#0f766e] rounded-lg">
                    {uploadedReport.biomarkers?.length || 0} Biomarkers
                    Extracted
                  </span>
                </div>
              </div>

              {/* ONE-CLICK "DOCTOR QUESTION GENERATOR" CHIPS */}
              <div className="bg-[#fcfbf7] border border-[#e5dfd2] rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-[#707c75] uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles size={13} className="text-[#0f766e]" />
                    One-Click Doctor Question Generator
                  </span>
                  <span className="text-[10px] text-[#8e9892]">
                    Click any prompt to launch conversational MEDNEXUS AI
                    analysis
                  </span>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() =>
                      openChatWithQuery(
                        "Why are my highlighted numbers out of range?"
                      )
                    }
                    className="px-3 py-1.5 bg-white hover:bg-[#e4f1ed] text-[#1c4d44] border border-[#d2cbba] hover:border-[#0f766e] rounded-full text-xs font-medium transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <span>Why are my highlighted numbers out of range?</span>
                    <ArrowUpRight size={13} className="text-[#0f766e]" />
                  </button>

                  <button
                    onClick={() =>
                      openChatWithQuery(
                        "What diet or lifestyle changes can help improve these results?"
                      )
                    }
                    className="px-3 py-1.5 bg-white hover:bg-[#e4f1ed] text-[#1c4d44] border border-[#d2cbba] hover:border-[#0f766e] rounded-full text-xs font-medium transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <span>
                      What diet or lifestyle changes can help improve these
                      results?
                    </span>
                    <ArrowUpRight size={13} className="text-[#0f766e]" />
                  </button>

                  <button
                    onClick={() =>
                      openChatWithQuery(
                        "Generate 3 specific questions for my next doctor visit"
                      )
                    }
                    className="px-3 py-1.5 bg-white hover:bg-[#e4f1ed] text-[#1c4d44] border border-[#d2cbba] hover:border-[#0f766e] rounded-full text-xs font-medium transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  >
                    <span>
                      Generate 3 specific questions for my next doctor visit
                    </span>
                    <ArrowUpRight size={13} className="text-[#0f766e]" />
                  </button>
                </div>
              </div>

              {/* TRIAGE GROUP 1: NEEDS DOCTOR FOLLOW-UP */}
              {attentionBiomarkers.length > 0 && (
                <div className="border border-[#f1d0c4] rounded-xl overflow-hidden bg-[#fffdfb]">
                  <div className="bg-[#fae5dc] px-5 py-3 border-b border-[#f1d0c4] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <AlertTriangle size={17} className="text-[#a84432]" />
                      <h3 className="font-serif text-lg font-medium text-[#7c2817]">
                        Needs Doctor Follow-Up ({attentionBiomarkers.length})
                      </h3>
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-[#fff] text-[#a84432] px-2.5 py-0.5 rounded-full border border-[#f1d0c4]">
                      Priority Attention
                    </span>
                  </div>

                  <div className="divide-y divide-[#f7e6e0]">
                    {attentionBiomarkers.map(b => (
                      <div key={b.name} className="p-4 sm:p-5">
                        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-1">
                          <div>
                            <span className="text-base font-bold text-[#22302f]">
                              {b.name}
                            </span>
                            <span className="text-xs text-[#707c75] ml-2 font-normal">
                              ({b.plainName})
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-[#a84432]">
                              {b.valueDisplay || b.value} {b.unit}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-[#fae5dc] text-[#a84432]">
                              {b.statusLabel}
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-[#52605b] mt-1 mb-2">
                          {b.meaning}
                        </p>

                        {/* VISUAL RANGE BAR GAUGE */}
                        <VisualRangeBar biomarker={b} />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TRIAGE GROUP 2: NORMAL / WITHIN REFERENCE RANGE */}
              {normalBiomarkers.length > 0 && (
                <div className="border border-[#cbe4da] rounded-xl overflow-hidden bg-[#fafdfb]">
                  <div className="bg-[#e4f3ed] px-5 py-3 border-b border-[#cbe4da] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={17} className="text-[#135f57]" />
                      <h3 className="font-serif text-lg font-medium text-[#135f57]">
                        Normal / Within Reference Range (
                        {normalBiomarkers.length})
                      </h3>
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-[#fff] text-[#135f57] px-2.5 py-0.5 rounded-full border border-[#cbe4da]">
                      In Range
                    </span>
                  </div>

                  <div className="divide-y divide-[#e3f0ea]">
                    {normalBiomarkers.map(b => (
                      <div key={b.name} className="p-4 sm:p-5">
                        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-1">
                          <div>
                            <span className="text-base font-bold text-[#22302f]">
                              {b.name}
                            </span>
                            <span className="text-xs text-[#707c75] ml-2 font-normal">
                              ({b.plainName})
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-[#135f57]">
                              {b.valueDisplay || b.value} {b.unit}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-[#dff0e5] text-[#2d6e4d]">
                              Normal
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-[#52605b] mt-1 mb-2">
                          {b.meaning}
                        </p>

                        {/* VISUAL RANGE BAR GAUGE */}
                        <VisualRangeBar biomarker={b} />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TWO-COLUMN "ORIGINAL VS. SIMPLIFIED" VIEW FOR DIAGNOSTIC TEXT */}
              {uploadedReport.diagnosticSections &&
                uploadedReport.diagnosticSections.length > 0 && (
                  <OriginalVsSimplifiedCard
                    sections={uploadedReport.diagnosticSections}
                  />
                )}
            </div>
          )}
        </section>

        {/* CARD 2: DECOUPLED CONNECTED VITALS / WEARABLE DATA (SIMULATED) */}
        <section id="wearable-vitals" className="clinical-engine-card">
          <div className="clinical-engine-heading">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider bg-[#e9ddc5] text-[#705e36] px-2 py-0.5 rounded">
                  Demo Vitals (Simulated Wearable)
                </span>
                <span className="text-xs text-[#7d8881]">
                  Decoupled from uploaded laboratory document
                </span>
              </div>
              <h2>Wearable vitals &amp; What-if simulator</h2>
              <p>
                Simulate real-time physiological metrics (blood pressure,
                fasting glucose, SpO2) independent of your uploaded document.
              </p>
            </div>
            <span className="engine-badge">
              <SlidersHorizontal size={14} />
              Simulated Vitals
            </span>
          </div>

          {/* Patient Demographic Details */}
          <div className="profile-editor">
            <div className="profile-editor-title">
              <UserRound size={15} />
              <strong>Patient Profile Parameters</strong>
              <span>Customizes baseline clinical evaluations</span>
            </div>

            <div className="profile-fields">
              <label>
                Full Name
                <input
                  value={profile.name}
                  onChange={e => updateProfile("name", e.target.value)}
                  placeholder="Patient name"
                />
              </label>
              <label>
                Age
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={profile.age}
                  onChange={e =>
                    updateProfile(
                      "age",
                      Math.max(1, Math.min(120, Number(e.target.value) || 1))
                    )
                  }
                />
              </label>
              <label>
                Biological Sex
                <select
                  value={profile.sex}
                  onChange={e =>
                    updateProfile("sex", e.target.value as BiologicalSex)
                  }
                >
                  <option value="Female">Female (Hb ref: 12.0–16.0)</option>
                  <option value="Male">Male (Hb ref: 13.5–17.5)</option>
                </select>
              </label>
              <label>
                Pertinent Medical Notes
                <input
                  value={profile.history}
                  onChange={e => updateProfile("history", e.target.value)}
                  placeholder="e.g., fatigue, plant-based diet, mild hypertension"
                />
              </label>
            </div>

            <div className="flex items-center justify-between mt-3">
              <button className="save-profile-button" onClick={saveProfile}>
                <Save size={13} />
                <span>
                  {profileSaved ? "Saved Locally" : "Save Patient Profile"}
                </span>
              </button>

              <span className="text-[11px] text-[#7c8881] italic">
                All calculations are educational screening simulations.
              </span>
            </div>
          </div>

          {/* Interactive Sliders & Consequence Breakdown */}
          <div className="engine-layout">
            <div className="metric-controls">
              <div className="metric-controls-heading">
                <strong>Simulated Vitals &amp; Lab Sliders</strong>
                <span>Adjust sliders to see screening consequence</span>
              </div>

              {visibleMetrics.map(metric => {
                const val = profile.vitals[metric.key];
                const evaluated = clinicalResults.find(
                  item => item.key === metric.key
                )!;
                return (
                  <div
                    key={metric.key}
                    onClick={() => setActiveMetric(metric.key)}
                    className={`metric-control ${
                      activeMetric === metric.key ? "metric-control-active" : ""
                    }`}
                  >
                    <div className="metric-control-top">
                      <span>
                        <strong>{metric.simpleLabel}</strong>
                        <small>{metric.label}</small>
                      </span>
                      <b className={statusClass(evaluated.status)}>
                        {formatValue(val, metric.step)} {metric.unit}
                      </b>
                    </div>

                    <input
                      aria-label={`Adjust ${metric.label}`}
                      type="range"
                      min={metric.min}
                      max={metric.max}
                      step={metric.step}
                      value={val}
                      onChange={e => {
                        setActiveMetric(metric.key);
                        updateVital(metric.key, Number(e.target.value));
                      }}
                      onClick={e => e.stopPropagation()}
                    />

                    <div className="metric-control-bottom">
                      <span>
                        Range: {metric.min}–{metric.max} {metric.unit}
                      </span>
                      <em className={statusClass(evaluated.status)}>
                        {evaluated.statusLabel}
                      </em>
                    </div>
                  </div>
                );
              })}

              <button
                className="show-more-metrics"
                onClick={() => setShowAllMetrics(!showAllMetrics)}
              >
                <span>
                  {showAllMetrics
                    ? "Show fewer core metrics"
                    : `Show all ${metricDefinitions.length} metrics`}
                </span>
                <ChevronRight
                  size={14}
                  className={`transition-transform ${showAllMetrics ? "rotate-90" : ""}`}
                />
              </button>
            </div>

            {/* Active Consequence & Action Panel */}
            <div
              className={`consequence-panel consequence-${activeResult.status}`}
            >
              <div className="consequence-top">
                <div>
                  <span className="consequence-kicker">
                    <AlertTriangle size={13} />
                    {activeResult.system} System
                  </span>
                  <h3>{activeResult.condition}</h3>
                </div>
                <span className={statusClass(activeResult.status)}>
                  {activeResult.statusLabel}
                </span>
              </div>

              <div className="consequence-value">
                <strong>
                  {formatValue(
                    activeResult.value,
                    metricDefinitions.find(m => m.key === activeResult.key)
                      ?.step || 1
                  )}
                </strong>
                <span>
                  {activeResult.unit} · {activeResult.label}
                </span>
              </div>

              <div className="consequence-grid">
                <div>
                  <strong>Short-term physiological effect:</strong>
                  <p>{activeResult.shortTerm}</p>
                </div>
                <div>
                  <strong>If sustained without clinical intervention:</strong>
                  <p>{activeResult.longTerm}</p>
                </div>
                <div>
                  <strong>Recommended safe next step:</strong>
                  <p>{activeResult.nextStep}</p>
                </div>
              </div>

              <div className="consequence-note">
                <ShieldCheck size={14} />
                <span>
                  Always reference laboratory report reference values and
                  physician context.
                </span>
              </div>
            </div>
          </div>
        </section>
      </div>

      <div className="lra-disclaimer">
        <ShieldAlert size={14} className="text-[#a84432] shrink-0" />
        <span>
          <strong>Clinical Disclaimer:</strong> MEDNEXUS AI is an educational
          simplification tool. It does not diagnose, treat, or prescribe. Always
          consult your qualified physician for medical decisions.
        </span>
      </div>

      <MednexusChatBot
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        uploadedReport={uploadedReport}
        patientName={profile.name}
        initialQuery={chatInitialQuery}
      />
    </div>
  );
}
