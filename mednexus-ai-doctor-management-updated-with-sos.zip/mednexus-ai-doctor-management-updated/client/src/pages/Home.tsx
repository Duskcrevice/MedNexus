import { FormEvent, useState } from "react";
import {
  Activity,
  ArrowRight,
  Check,
  HeartPulse,
  Hospital,
  KeyRound,
  ShieldCheck,
  Stethoscope,
  UserRound,
  Users,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { DEMO_DOCTOR_LOGIN, DEMO_LOGIN_HINTS, loginDemo } from "@/lib/demoStore";
type Role = "Administrator" | "Doctor" | "Hospital Staff" | "Patient";
const roles: {
  label: Role;
  description: string;
  icon: typeof UserRound;
  tone: string;
}[] = [
  {
    label: "Administrator",
    description: "Hospital administration and oversight",
    icon: ShieldCheck,
    tone: "purple",
  },
  {
    label: "Doctor",
    description: "Appointments and clinical documentation",
    icon: Stethoscope,
    tone: "blue",
  },
  {
    label: "Hospital Staff",
    description: "Operations, requests, and resources",
    icon: Users,
    tone: "violet",
  },
  {
    label: "Patient",
    description: "Appointments, records, and prescriptions",
    icon: UserRound,
    tone: "mint",
  },
];

function defaultCredentials(_role: Role) {
  return { email: "", password: "" };
}

export default function Home() {
  const queryRole = new URLSearchParams(window.location.search).get(
    "role"
  ) as Role;
  const startRole = roles.some(item => item.label === queryRole)
    ? queryRole
    : "Patient";
  const [selectedRole, setSelectedRole] = useState<Role>(startRole);
  const [credentials, setCredentials] = useState(defaultCredentials(startRole));
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [createAccount, setCreateAccount] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [demoLoading, setDemoLoading] = useState<Role | "">("");
  const loginMutation = trpc.auth.login.useMutation();
  const registerMutation = trpc.auth.register.useMutation();
  const registerAdministratorMutation = trpc.auth.registerAdministrator.useMutation();

  const chooseRole = (role: Role) => {
    setSelectedRole(role);
    if (role !== "Patient") setCreateAccount(false);
    setCredentials(defaultCredentials(role));
    setError("");
  };

  const accessDemoPortal = async (portal: Role) => {
    setError("");
    setDemoLoading(portal);
    const credentials = portal === "Doctor" ? DEMO_DOCTOR_LOGIN : DEMO_LOGIN_HINTS[portal];
    try {
      const account = await loginDemo(credentials.email, credentials.password, portal);
      if (!account) throw new Error("This demo portal account is not available yet.");
      window.location.href = "/app";
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not open the demo portal.");
    } finally {
      setDemoLoading("");
    }
  };

  const signIn = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (createAccount) {
        if (credentials.password !== confirmPassword)
          throw new Error("Passwords do not match.");
        if (selectedRole === "Administrator") {
          await registerAdministratorMutation.mutateAsync({
            name: fullName,
            email: credentials.email,
            password: credentials.password,
            confirmPassword,
          });
          window.location.href = "/app";
        } else {
          await registerMutation.mutateAsync({
            name: fullName,
            email: credentials.email,
            password: credentials.password,
            confirmPassword,
          });
          window.location.href = "/app/patient";
        }
      } else {
        const role =
          selectedRole === "Patient"
            ? "patient"
            : selectedRole === "Administrator"
              ? "admin"
              : selectedRole === "Doctor"
                ? "doctor"
                : "staff";
        try {
          // Use the existing SQLite-backed server session first. The browser-local
          // demo remains only as a fallback when the API is unavailable.
          await loginMutation.mutateAsync({
            email: credentials.email,
            password: credentials.password,
            role,
          });
          window.location.href = selectedRole === "Patient" ? "/app/patient" : selectedRole === "Hospital Staff" ? "/app/staff" : "/app";
          return;
        } catch (cause) {
          const localAccount = await loginDemo(credentials.email, credentials.password, selectedRole);
          if (localAccount) {
            window.location.href = "/app";
            return;
          }
          if (cause instanceof SyntaxError || /Unexpected end of JSON|JSON input/i.test(cause instanceof Error ? cause.message : String(cause))) {
            throw new Error("Demo login failed. Check the email, password, and account role. Active doctor/staff accounts must use the credentials imported by the administrator.");
          }
          throw cause;
        }
      }
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Authentication failed."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-landing mx-login-reference">
      <section className="mx-landing-left">
        <header className="mx-brand">
          <span className="mx-brand-mark">
            <HeartPulse size={22} />
          </span>
          <span>
            <strong>
              MEDNEXUS <b>AI</b>
            </strong>
            <small>MEDNEXUS General Hospital</small>
          </span>
        </header>
        <span className="mx-plus mx-plus-a" aria-hidden="true">
          +
        </span>
        <span className="mx-plus mx-plus-b" aria-hidden="true">
          +
        </span>
        <div className="mx-hero-copy">
          <div className="mx-kicker">
            <Activity size={14} /> SECURE HEALTHCARE NETWORK
          </div>
          <h1>
            One Network.
            <br />
            <em>Smarter Healthcare.</em>
          </h1>
          <p>
            Connecting patients, doctors and hospitals through one intelligent
            platform.
          </p>
          <div className="mx-login-trust">
            <span>
              <Check size={14} /> Access controls depend on your account
            </span>
            <span>
              <ShieldCheck size={14} /> Privacy-aware workspace
            </span>
          </div>
          <div className="mx-login-network">
            <Hospital size={14} /> One connected care network
          </div>
        </div>
        <div className="mx-landing-foot">
          <span>MEDNEXUS AI</span>
          <span>Preview workspace · No live patient information</span>
        </div>
      </section>
      <section className="mx-landing-right">
        <form className="mx-auth-card" onSubmit={signIn}>
          <div className="mx-auth-heading">
            <div className="mx-auth-icon">
              <HeartPulse size={20} />
            </div>
            <span className="mx-secure-dot">
              <i /> SECURE ACCESS
            </span>
          </div>
          <h2>Continue to MEDNEXUS AI</h2>
          <p className="mx-auth-copy">
            Use one secure email-and-password account across MEDNEXUS AI.
          </p>
          {(selectedRole === "Patient" || selectedRole === "Administrator") && <div className="mx-auth-mode-tabs" role="tablist" aria-label="Account access mode">
            <button
              type="button"
              role="tab"
              aria-selected={!createAccount}
              className={!createAccount ? "active" : ""}
              onClick={() => { setCreateAccount(false); setError(""); }}
            >
              SIGN IN
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={createAccount}
              className={createAccount ? "active" : ""}
              onClick={() => { setCreateAccount(true); setError(""); }}
            >
              CREATE ACCOUNT
            </button>
          </div>}
          <div className="mx-login-identity-grid">
            <label>
              Full Name
              <input
                value={fullName}
                onChange={event => setFullName(event.target.value)}
                placeholder="Your full name"
                autoComplete="name"
                required={createAccount}
              />
            </label>
            <label>
              Phone Number
              <input
                value={phone}
                onChange={event => setPhone(event.target.value)}
                placeholder="9876543210 or +919876543210"
                autoComplete="tel"
              />
            </label>
          </div>
          <div className="mx-role-caption">Select your role</div>
          <div
            className="mx-role-list"
            role="group"
            aria-label="Choose a demo account role"
          >
            {roles.map(({ label, description, icon: Icon, tone }) => (
              <button
                key={label}
                type="button"
                className={`mx-role-option ${selectedRole === label ? "selected" : ""}`}
                aria-pressed={selectedRole === label}
                onClick={() => chooseRole(label)}
              >
                <span className={`mx-role-icon ${tone}`}>
                  <Icon size={18} />
                </span>
                <span>
                  <strong>{label}</strong>
                  <small>{description}</small>
                </span>
                {selectedRole === label && <Check size={15} />}
              </button>
            ))}
          </div>
          <div className="mx-demo-portal-access">
            <div>
              <strong>Demo Portal Access</strong>
              <small>Open any portal with ready-to-use fictional data</small>
            </div>
            <div className="mx-demo-portal-grid">
              {roles.map(({ label: portal }) => (
                <button
                  key={portal}
                  type="button"
                  onClick={() => accessDemoPortal(portal)}
                  disabled={!!demoLoading || loading}
                >
                  {demoLoading === portal ? "Opening…" : `Open ${portal === "Hospital Staff" ? "Staff" : portal}`}
                </button>
              ))}
            </div>
          </div>
          <div className="mx-demo-login-fields">
            <label>
              Email Address
              <input
                type="email"
                autoComplete="username"
                value={credentials.email}
                onChange={event =>
                  setCredentials({ ...credentials, email: event.target.value })
                }
                placeholder={
                  selectedRole === "Doctor"
                    ? "doctor@medicarehospital.com"
                    : "demo@mednexus.demo"
                }
                required
              />
            </label>
            <label>
              Workspace password
              <input
                type="password"
                autoComplete="current-password"
                value={credentials.password}
                onChange={event =>
                  setCredentials({
                    ...credentials,
                    password: event.target.value,
                  })
                }
                placeholder="Enter workspace password"
                required
              />
            </label>
            {createAccount && (
              <label>
                Confirm Password
                <input
                  type="password"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={event => setConfirmPassword(event.target.value)}
                  placeholder="Confirm your password"
                  required
                />
              </label>
            )}
          </div>
          <p className="mx-login-identity-note">
            Your account is stored securely on the MEDNEXUS server. Passwords
            are never stored in plain text.
          </p>
          <button
            className="mx-preview-button"
            type="submit"
            disabled={loading}
          >
            {loading ? (
              createAccount ? (
                "Creating account…"
              ) : (
                "Signing in…"
              )
            ) : (
              <>
                {createAccount
                  ? selectedRole === "Administrator"
                    ? "Create Administrator Account"
                    : "Create Patient Account"
                  : "Sign In"}{" "}
                <ArrowRight size={16} />
              </>
            )}
          </button>
          <p className="mx-provider-note">
            <KeyRound size={13} /> Role selection does not grant permissions;
            the server checks the account and assigned role.
          </p>
          {error && (
            <div className="mx-auth-error" role="alert">
              <p>{error}</p>
              {!createAccount && error === "Account not found. Please create an account." && (
                <button type="button" className="text-link" onClick={() => { setCreateAccount(true); setError(""); }}>
                  Create Patient Account
                </button>
              )}
            </div>
          )}
          <p className="mx-provider-caption">
            <KeyRound size={13} /> No Google, OTP, or email verification is
            required for patient accounts. Administrator permissions remain
            server-authorized.
          </p>
          <div className="mx-demo-note">
            <span>
              Server-authenticated workspace · Protected patient records
            </span>
          </div>
        </form>
      </section>
    </main>
  );
}
