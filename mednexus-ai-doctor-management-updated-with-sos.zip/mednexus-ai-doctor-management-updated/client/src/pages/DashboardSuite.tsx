import {
  ChangeEvent,
  FormEvent,
  ReactNode,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useLocation } from "wouter";
import * as XLSX from "xlsx";
import {
  Activity,
  Ambulance,
  Bell,
  BedDouble,
  CalendarDays,
  Check,
  ChevronDown,
  CircleHelp,
  ClipboardList,
  FileText,
  HeartPulse,
  Home,
  Hospital,
  LogOut,
  Menu,
  MessageCircle,
  Pill,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Stethoscope,
  UserRound,
  Users,
  Wallet,
  X,
  Phone,
  Copy,
} from "lucide-react";
import {
  addDemoDoctor,
  addDemoStaff,
  defaultDoctorEmail,
  DemoAccount,
  DemoAppointment,
  DemoDoctor,
  DemoPrescription,
  DemoRole,
  DemoStore,
  ensureDemoStore,
  getSessionAccount,
  isDemoSlotBusy,
  logoutDemo,
  makeDemoPassword,
  persistDemoStore,
  demoPersistenceMode,
} from "@/lib/demoStore";
import LabReportAnalyzer from "./LabReportAnalyzer";
import MedicineVerifier from "./MedicineVerifier";
import EmergencySOS from "@/components/sos/EmergencySOS";
import { trpc } from "@/lib/trpc";
import "./dashboard-suite.css";

type Role = DemoRole;
type Appointment = DemoAppointment;
type Doctor = DemoDoctor;
type Prescription = DemoPrescription;
const LAB_PAGE = "AI Medical Report Analyzer";
const LAB_ROUTE = "/app/lab-report-analyzer";
const MV_PAGE = "Medicine Verifier";
const MV_ROUTE = "/app/medicine-verifier";
type Modal = "book" | "prescription" | "doctor" | "credentials" | "zapia" | "";

const roles: Role[] = ["Patient", "Doctor", "Hospital Staff", "Administrator"];
const users: Record<Role, { title: string }> = {
  Patient: { title: "Patient" },
  Doctor: { title: "Doctor" },
  "Hospital Staff": { title: "Hospital Staff" },
  Administrator: { title: "MEDNEXUS General Hospital" },
};
const nav: Record<Role, { label: string; icon: typeof Home }[]> = {
  Patient: [
    { label: "Dashboard", icon: Home },
    { label: "Find Doctors", icon: Search },
    { label: "My Appointments", icon: CalendarDays },
    { label: "Medical Records", icon: FileText },
    { label: "Prescriptions", icon: Pill },
    { label: "Medicine Verifier", icon: ShieldCheck },
    { label: "AI Medical Report Analyzer", icon: FileText },
    { label: "Beds & Ambulance", icon: BedDouble },
    { label: "Bills & Receipts", icon: Wallet },
    { label: "My Reviews", icon: Activity },
    { label: "Profile", icon: UserRound },
  ],
  Doctor: [
    { label: "Dashboard", icon: Home },
    { label: "My Appointments", icon: CalendarDays },
    { label: "My Patients", icon: Users },
    { label: "Consultations", icon: Stethoscope },
    { label: "Prescriptions", icon: Pill },
    { label: "Medicine Verifier", icon: ShieldCheck },
    { label: "Schedule & Leave", icon: CalendarDays },
    { label: "Medical Records", icon: FileText },
    { label: "Notifications", icon: Bell },
  ],
  "Hospital Staff": [
    { label: "Dashboard", icon: Home },
    { label: "Assigned Tasks", icon: ClipboardList },
    { label: "Patient Check-in", icon: UserRound },
    { label: "Appointments", icon: CalendarDays },
    { label: "Bed Management", icon: BedDouble },
    { label: "Inventory", icon: Pill },
    { label: "Ambulance Requests", icon: Ambulance },
    { label: "Notifications", icon: Bell },
  ],
  Administrator: [
    { label: "Dashboard", icon: Home },
    { label: "Doctors", icon: Stethoscope },
    { label: "Staff", icon: Users },
    { label: "Patients", icon: UserRound },
    { label: "Appointments", icon: CalendarDays },
    { label: "Hospital Resources", icon: BedDouble },
    { label: "Inventory", icon: Pill },
    { label: "Ambulance", icon: Ambulance },
    { label: "Billing", icon: Wallet },
    { label: "Settings", icon: Settings },
  ],
};
const heroCards: Record<
  Role,
  {
    title: string;
    sub: string;
    icon: typeof Home;
    color: string;
    page: string;
  }[]
> = {
  Patient: [
    {
      title: "Find Doctors",
      sub: "Search & explore",
      icon: Search,
      color: "teal",
      page: "Find Doctors",
    },
    {
      title: "Book Appointment",
      sub: "Online or in-person",
      icon: CalendarDays,
      color: "blue",
      page: "Find Doctors",
    },
    {
      title: "Verify Medicine",
      sub: "Scan or search",
      icon: Pill,
      color: "teal",
      page: "Medicine Verifier",
    },
    {
      title: "Medical Records",
      sub: "View your reports",
      icon: FileText,
      color: "blue",
      page: "Medical Records",
    },
  ],
  Doctor: [
    {
      title: "Today's Appointments",
      sub: "View your schedule",
      icon: CalendarDays,
      color: "teal",
      page: "My Appointments",
    },
    {
      title: "My Patients",
      sub: "Assigned patients",
      icon: Users,
      color: "blue",
      page: "My Patients",
    },
    {
      title: "Write Prescription",
      sub: "For an appointment",
      icon: Pill,
      color: "teal",
      page: "Prescriptions",
    },
    {
      title: "Manage Schedule",
      sub: "Hours & leave",
      icon: Activity,
      color: "blue",
      page: "Schedule & Leave",
    },
  ],
  "Hospital Staff": [
    {
      title: "Today's Tasks",
      sub: "Assigned to you",
      icon: ClipboardList,
      color: "teal",
      page: "Assigned Tasks",
    },
    {
      title: "Patient Admissions",
      sub: "Check-in queue",
      icon: UserRound,
      color: "amber",
      page: "Patient Check-in",
    },
    {
      title: "Bed Management",
      sub: "Update availability",
      icon: BedDouble,
      color: "blue",
      page: "Bed Management",
    },
    {
      title: "Inventory",
      sub: "Stock overview",
      icon: Pill,
      color: "teal",
      page: "Inventory",
    },
  ],
  Administrator: [
    {
      title: "Manage Doctors",
      sub: "Profiles & schedule",
      icon: Stethoscope,
      color: "blue",
      page: "Doctors",
    },
    {
      title: "Manage Staff",
      sub: "Workspace account access",
      icon: Users,
      color: "rose",
      page: "Staff",
    },
    {
      title: "Appointments",
      sub: "Hospital schedule",
      icon: CalendarDays,
      color: "amber",
      page: "Appointments",
    },
    {
      title: "Hospital Resources",
      sub: "Beds & equipment",
      icon: Hospital,
      color: "teal",
      page: "Hospital Resources",
    },
  ],
};
const slots = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00"];
const fallbackPortraits = [
  "/doctor-portraits/elena-fernandez.jpg",
  "/doctor-portraits/om-mishra.jpg",
  "/doctor-portraits/michael-darvis.jpg",
  "/doctor-portraits/srikant-sharma.jpg",
];
const defaultDoctorPhoto = (specialty: string, identity = specialty) => {
  const value = specialty.toLowerCase();
  const specialtyBias = value.includes("cardio") ? 0 : value.includes("pedi") ? 1 : value.includes("neuro") ? 2 : 3;
  const identityScore = Array.from(identity.toLowerCase()).reduce((sum, character) => sum + character.charCodeAt(0), 0);
  return fallbackPortraits[(identityScore + specialtyBias) % fallbackPortraits.length];
};

export default function DashboardSuite() {
  const [location, setLocation] = useLocation();
  const requestedRole = new URLSearchParams(window.location.search).get(
    "role"
  ) as Role;
  const [store, setStore] = useState<DemoStore | null>(null);
  const [account, setAccount] = useState<DemoAccount | null>(null);
  const [bootError, setBootError] = useState("");
  const [storageMode, setStorageMode] = useState<
    "localStorage" | "memory-only"
  >("localStorage");
  const [page, setPage] = useState(() =>
    window.location.pathname === LAB_ROUTE
      ? LAB_PAGE
      : window.location.pathname === MV_ROUTE
        ? MV_PAGE
        : "Dashboard"
  );
  const [toast, setToast] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [modal, setModal] = useState<Modal>("");
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [appointmentDate, setAppointmentDate] = useState("2026-10-26");
  const [appointmentTime, setAppointmentTime] = useState("12:00");
  const [consultType, setConsultType] = useState<"Online" | "In-Person">(
    "Online"
  );
  const [reason, setReason] = useState("");
  const [prescriptionAppointmentId, setPrescriptionAppointmentId] = useState(0);
  const [rxMedicine, setRxMedicine] = useState("");
  const [rxDose, setRxDose] = useState("");
  const [rxInstructions, setRxInstructions] = useState("");
  const [rxNotes, setRxNotes] = useState("");
  const [rxFollowUpDate, setRxFollowUpDate] = useState("");
  const [newDoctor, setNewDoctor] = useState({
    name: "",
    specialty: "Cardiology",
    qualifications: "",
    experience: "",
    fee: "800",
    email: "",
    password: "",
    hours: "09:00–13:00",
  });
  const [newDoctorPhoto, setNewDoctorPhoto] = useState("");
  const [credentialReport, setCredentialReport] = useState<
    { name: string; email: string; password: string }[]
  >([]);
  const [search, setSearch] = useState("");
  const [availabilityDate, setAvailabilityDate] = useState("2026-10-27");
  const [availabilityTime, setAvailabilityTime] = useState("09:00");
  const [medicineSearch, setMedicineSearch] = useState("");
  const [medicineResult, setMedicineResult] = useState("");
  const [reportText, setReportText] = useState("");
  const [reportResult, setReportResult] = useState("");

  useEffect(() => {
    let live = true;
    ensureDemoStore()
      .then(async data => {
        if (!live) return;
        const normalized = data.doctors.map((doctor, index) =>
          doctor.photo?.startsWith("/doctor-portraits/")
            ? { ...doctor, photo: fallbackPortraits[index % fallbackPortraits.length] }
            : doctor
        );
        const ready = normalized.some((doctor, index) => doctor.photo !== data.doctors[index]?.photo)
          ? { ...data, doctors: normalized }
          : data;
        if (ready !== data) persistDemoStore(ready);
        setStore(ready);
        setStorageMode(demoPersistenceMode());
        const loggedIn = await getSessionAccount();
        if (!live) return;
        if (!loggedIn) {
          const role = roles.includes(requestedRole)
            ? requestedRole
            : "Patient";
          setLocation(`/?role=${encodeURIComponent(role)}`);
          return;
        }
        setAccount(loggedIn);
      })
      .catch(error => {
        if (live)
          setBootError(
            error instanceof Error
              ? error.message
              : "Could not load the local demo store."
          );
      });
    return () => {
      live = false;
    };
  }, [requestedRole, setLocation]);

  useEffect(() => {
    const handler = (event: Event) => {
      setToast((event as CustomEvent<string>).detail);
      window.setTimeout(() => setToast(""), 3500);
    };
    window.addEventListener("mx-demo-notice", handler);
    return () => window.removeEventListener("mx-demo-notice", handler);
  }, []);

  const role: Role =
    account?.role ||
    (roles.includes(requestedRole) ? requestedRole : "Patient");
  const serverStaffQuery = trpc.admin.staff.useQuery(undefined, { enabled: role === "Administrator", retry: false });
  const importStaffMutation = trpc.admin.importStaff.useMutation({
    onSuccess: () => { serverStaffQuery.refetch(); notify("Staff import saved to SQLite."); },
    onError: error => notify(error.message),
  });
  const setStaffAccessMutation = trpc.admin.setStaffAccess.useMutation({
    onSuccess: () => { serverStaffQuery.refetch(); notify("Staff access updated in SQLite."); },
    onError: error => notify(error.message),
  });
  const doctors = store?.doctors || [];
  const accounts = store?.accounts || [];
  const appointments = store?.appointments || [];
  const prescriptions = store?.prescriptions || [];
  const activeDoctors = doctors.filter(doctor => doctor.active);
  const myDoctor = account?.doctorId
    ? doctors.find(doctor => doctor.id === account.doctorId)
    : undefined;
  const actor = account
    ? {
        name: account.displayName,
        title:
          role === "Doctor"
            ? myDoctor?.specialty || "Doctor account"
            : users[role].title,
        email: account.email,
        initials:
          account.displayName
            .split(" ")
            .filter(Boolean)
            .slice(-2)
            .map(part => part[0])
            .join("")
            .toUpperCase() || "D",
      }
    : { name: "Demo", title: users[role].title, email: "", initials: "D" };
  const patientAppointments = appointments.filter(
    appointment => appointment.patientEmail === account?.email
  );
  const doctorAppointments =
    role === "Doctor"
      ? appointments.filter(
          appointment => appointment.doctorId === account?.doctorId
        )
      : appointments;
  const visibleAppointments =
    role === "Patient" ? patientAppointments : doctorAppointments;
  const visiblePrescriptions =
    role === "Patient"
      ? prescriptions.filter(item => item.patientEmail === account?.email)
      : role === "Doctor"
        ? prescriptions.filter(item => item.doctorId === account?.doctorId)
        : prescriptions;
  const myBlockedSlots = myDoctor?.blockedSlots || [];
  const tasks = store?.tasks || [false, false, false, false];
  const bedStatus = store?.bedStatus || "36";

  const updateStore = (update: (current: DemoStore) => DemoStore) => {
    if (!store) return;
    const next = update(store);
    persistDemoStore(next);
    setStore(next);
    setStorageMode(demoPersistenceMode());
  };
  const notify = (text: string) => {
    setToast(text);
    window.setTimeout(() => setToast(""), 3500);
  };
  const setTasks = (update: (rows: boolean[]) => boolean[]) =>
    updateStore(current => ({ ...current, tasks: update(current.tasks) }));
  const setBedStatus = (value: string) =>
    updateStore(current => ({ ...current, bedStatus: value }));
  const logout = () => {
    logoutDemo();
    setAccount(null);
    setLocation(`/?role=${encodeURIComponent(role)}`);
  };
  const selectRole = (value: Role) => {
    logoutDemo();
    setAccount(null);
    setLocation(`/?role=${encodeURIComponent(value)}`);
  };
  const openPage = (value: string) => {
    setPage(value);
    setMenuOpen(false);
    if (value === "Book Appointment") setModal("book");
    const target = value === LAB_PAGE ? LAB_ROUTE : value === MV_PAGE ? MV_ROUTE : "";
    if (target) {
      if (location !== target) setLocation(target);
    } else if (location === LAB_ROUTE || location === MV_ROUTE) setLocation("/app");
  };
  // Keep the Lab Report Analyzer page in sync with the URL (refresh, back/forward, direct links).
  useEffect(() => {
    if (location === LAB_ROUTE)
      setPage(current => (current === LAB_PAGE ? current : LAB_PAGE));
    else if (location === MV_ROUTE)
      setPage(current => (current === MV_PAGE ? current : MV_PAGE));
    else if (location === "/app")
      setPage(current =>
        current === LAB_PAGE || current === MV_PAGE ? "Dashboard" : current
      );
  }, [location]);
  const openPrescription = (appointmentId?: number) => {
    const existing = appointmentId
      ? prescriptions.find(rx => rx.appointmentId === appointmentId)
      : undefined;
    if (existing) {
      notify(
        `Previous visit: ${existing.notes || "No consultation note saved."} Follow-up: ${existing.followUpDate || "not set"}.`
      );
      return;
    }
    const candidate =
      appointmentId ??
      doctorAppointments.find(
        item => !prescriptions.some(rx => rx.appointmentId === item.id)
      )?.id ??
      0;
    setPrescriptionAppointmentId(candidate);
    setModal("prescription");
  };
  const doctorForName = (name: string) =>
    activeDoctors.find(doctor => doctor.name === name);
  const isSlotBusy = (doctor: Doctor | undefined, date: string, time: string) =>
    !store || !doctor || isDemoSlotBusy(store, doctor.id, date, time);

  const book = (event: FormEvent) => {
    event.preventDefault();
    const doctor = doctorForName(selectedDoctor) || activeDoctors[0];
    if (!account || role !== "Patient" || !doctor) {
      notify("Sign in to the Patient account and choose an active doctor.");
      return;
    }
    if (isSlotBusy(doctor, appointmentDate, appointmentTime)) {
      notify(
        "That appointment slot is unavailable. Choose another doctor, date or time."
      );
      return;
    }
    const row: Appointment = {
      id: Date.now(),
      patient: actor.name,
      patientEmail: account.email,
      doctor: doctor.name,
      doctorId: doctor.id,
      specialty: doctor.specialty,
      date: appointmentDate,
      time: appointmentTime,
      type: consultType,
      reason: reason || "General consultation",
      status: "Pending",
    };
    updateStore(current => ({
      ...current,
      appointments: [...current.appointments, row],
    }));
    setSelectedDoctor(doctor.name);
    setModal("");
    setReason("");
    notify("Appointment saved. It is now visible in this doctor's dashboard.");
  };

  const issuePrescription = (event: FormEvent) => {
    event.preventDefault();
    const appointment = appointments.find(
      item =>
        item.id === Number(prescriptionAppointmentId) &&
        item.doctorId === account?.doctorId
    );
    if (
      !appointment ||
      !account?.doctorId ||
      prescriptions.some(item => item.appointmentId === appointment.id)
    ) {
      notify("Choose an unprescribed appointment assigned to this doctor.");
      return;
    }
    const doctor = doctors.find(item => item.id === account.doctorId);
    const followUpDate = rxFollowUpDate || undefined;
    const rx: Prescription = {
      id: Date.now(),
      appointmentId: appointment.id,
      patient: appointment.patient,
      patientEmail: appointment.patientEmail,
      doctor: doctor?.name || actor.name,
      doctorId: account.doctorId,
      date: new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
      notes: rxNotes,
      medicines: [`${rxMedicine} — ${rxDose}`, rxInstructions],
      status: "Local preview",
      followUpDate,
    };
    updateStore(current => ({
      ...current,
      prescriptions: [rx, ...current.prescriptions],
      appointments: current.appointments.map(item =>
        item.id === appointment.id
          ? {
              ...item,
              status: "Completed",
              consultationNotes: rxNotes,
              followUpDate,
            }
          : item
      ),
    }));
    setModal("");
    setRxMedicine("");
    setRxDose("");
    setRxInstructions("");
    setRxNotes("");
    setRxFollowUpDate("");
    notify(
      "Consultation and prescription saved to the shared browser-local record."
    );
  };

  const addDoctor = async (event: FormEvent) => {
    event.preventDefault();
    if (!store) return;
    const email = newDoctor.email.trim() || defaultDoctorEmail(newDoctor.name);
    try {
      const result = await addDemoDoctor(store, {
        name: newDoctor.name.trim(),
        specialty: newDoctor.specialty,
        qualifications: newDoctor.qualifications.trim(),
        experience: newDoctor.experience.trim(),
        fee: Number(newDoctor.fee) || 0,
        photo: newDoctorPhoto || fallbackPortraits[store.doctors.length % fallbackPortraits.length],
        email,
        password: newDoctor.password,
        hours: newDoctor.hours.trim() || "09:00–13:00",
      });
      persistDemoStore(result.store);
      setStore(result.store);
      setStorageMode(demoPersistenceMode());
      setCredentialReport([
        { name: result.doctor.name, email, password: newDoctor.password },
      ]);
      setSelectedDoctor(result.doctor.name);
      setModal("credentials");
      setNewDoctor({
        name: "",
        specialty: "Cardiology",
        qualifications: "",
        experience: "",
        fee: "800",
        email: "",
        password: "",
        hours: "09:00–13:00",
      });
      setNewDoctorPhoto("");
    } catch (error) {
      notify(
        error instanceof Error
          ? error.message
          : "Could not create the doctor account."
      );
    }
  };

  const uploadDoctors = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !store) return;
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
        defval: "",
      });
      const backendRecords = rows.map(row => {
        const fields = Object.fromEntries(
          Object.entries(row).map(([key, value]) => [
            key.toLowerCase().replace(/[^a-z0-9]/g, ""),
            String(value ?? "").trim(),
          ])
        );
        const pick = (...keys: string[]) => keys.map(key => fields[key]).find(value => !!value) || "";
        return {
          name: pick("name", "doctor", "doctorname", "clinician"),
          email: (pick("email", "accountemail", "loginemail") || defaultDoctorEmail(pick("name", "doctor", "doctorname", "clinician"))).toLowerCase(),
          password: pick("password", "loginpassword", "assignedpassword") || undefined,
          department: pick("department"),
          specialty: pick("specialty", "specialization", "department"),
          qualifications: pick("qualifications", "qualification", "degree"),
          experience: pick("experience", "years", "experienceyears"),
          consultationFee: Number(pick("fee", "consultationfee")) || 0,
          workingHours: pick("hours", "availability", "workinghours") || "09:00–13:00",
          profilePhoto: pick("photourl", "photo", "image", "imageurl"),
        };
      }).filter(record => record.name && record.email);
      // The browser-local preview must still import rows when the optional
      // server API is not configured. Never call response.json() blindly:
      // static preview hosts may return an empty body or HTML for this route.
      try {
        const backendResponse = await fetch("/api/trpc/admin.importDoctors", {
          method: "POST",
          credentials: "include",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ json: { records: backendRecords } }),
        });
        const backendText = await backendResponse.text();
        let backendPayload: any = null;
        try { backendPayload = backendText ? JSON.parse(backendText) : null; } catch { backendPayload = null; }
        if (backendPayload?.error && backendPayload.error.json?.message) {
          notify(`Server import skipped: ${backendPayload.error.json.message}. Importing into this browser preview.`);
        }
      } catch {
        // Continue with the browser-local import below.
      }
      let next = store;
      let skipped = 0;
      const credentials: { name: string; email: string; password: string }[] =
        [];
      for (const row of rows) {
        const fields = Object.fromEntries(
          Object.entries(row).map(([key, value]) => [
            key.toLowerCase().replace(/[^a-z0-9]/g, ""),
            String(value ?? "").trim(),
          ])
        );
        const pick = (...keys: string[]) =>
          keys.map(key => fields[key]).find(value => !!value) || "";
        const name = pick("name", "doctor", "doctorname", "clinician");
        const specialty = pick("specialty", "specialization", "department");
        if (!name || !specialty) {
          skipped++;
          continue;
        }
        const email = (
          pick("email", "accountemail", "loginemail") ||
          defaultDoctorEmail(name)
        ).toLowerCase();
        const password =
          pick("password", "demopassword", "loginpassword") ||
          makeDemoPassword();
        const result = await addDemoDoctor(next, {
          name,
          specialty,
          qualifications: pick("qualifications", "qualification", "degree"),
          experience: pick("experience", "years", "experienceyears"),
          fee: Number(pick("fee", "consultationfee")) || 0,
          photo: pick("photourl", "photo", "image", "imageurl") || fallbackPortraits[next.doctors.length % fallbackPortraits.length],
          email,
          password,
          hours: pick("hours", "availability", "workinghours") || "09:00–13:00",
        });
        next = result.store;
        credentials.push({ name, email, password });
      }
      if (!credentials.length) {
        notify(
          `No doctors imported. Each row needs a name and specialty; ${skipped} row(s) skipped.`
        );
        return;
      }
      persistDemoStore(next);
      setStore(next);
      setStorageMode(demoPersistenceMode());
      setCredentialReport(credentials);
      setModal("credentials");
      notify(
        `Imported ${credentials.length} doctor account(s); skipped ${skipped} incomplete row(s).`
      );
    } catch (error) {
      notify(
        error instanceof Error
          ? error.message
          : "Could not read that CSV/Excel file. Check the first sheet and try again."
      );
    } finally {
      event.target.value = "";
    }
  };

  const uploadStaff = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !store) return;
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: "", blankrows: false });
      if (!matrix.length) throw new Error("The selected staff file is empty.");
      const firstRow = matrix[0].map(value => String(value ?? "").trim());
      const firstRowIsData = firstRow.some(value => /@/.test(value));
      const headers = firstRowIsData ? [] : firstRow;
      const dataRows = firstRowIsData ? matrix : matrix.slice(1);
      const rows = dataRows.map(row => Object.fromEntries(row.map((value, index) => [headers[index] || `column${index + 1}`, value])));
      const records: { name: string; email: string; password?: string }[] = [];
      const seen = new Set<string>();
      let skipped = 0;
      for (const row of rows) {
        const fields = Object.fromEntries(Object.entries(row).map(([key, value]) => [key.replace(/^\uFEFF/, "").toLowerCase().replace(/[^a-z0-9]/g, ""), String(value ?? "").trim()]));
        const pick = (...keys: string[]) => keys.map(key => fields[key]).find(value => !!value) || "";
        const values = Object.values(fields).filter(Boolean);
        const positionalEmail = values.find(value => /@/.test(value)) || "";
        const name = pick("name", "staff", "staffname", "fullname", "employeename", "staffmember", "displayname") || values.find(value => value !== positionalEmail) || "";
        const email = (pick("email", "emailaddress", "emailid", "accountemail", "loginemail", "username", "loginid", "mail") || positionalEmail).toLowerCase();
        const password = pick("password", "passwords", "loginpassword", "assignedpassword", "workspacepassword", "passcode", "pass", "pwd") || values.find(value => value !== name && value !== positionalEmail) || "";
        if (!name || !email || seen.has(email)) { skipped++; continue; }
        seen.add(email);
        records.push({ name, email, ...(password ? { password } : {}) });
      }
      if (!records.length) {
        notify(`No staff imported. Each row needs name and email; ${skipped} row(s) skipped.`);
        return;
      }
      const result = await importStaffMutation.mutateAsync({ records });
      const imported = result.imported?.length || 0;
      const serverSkipped = result.skipped?.length || 0;
      notify(`Imported ${imported} staff member(s) into SQLite; ${skipped + serverSkipped} row(s) skipped. Blank passwords are Pending Activation.`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not read that staff CSV/Excel file.");
    } finally {
      event.target.value = "";
    }
  };

  const toggleDoctor = async (id: number) => {
    const doctor = doctors.find(item => item.id === id);
    if (!doctor) return;
    const nextActive = !doctor.active;
    try {
      const response = await fetch("/api/trpc/admin.setDoctorStatus", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ json: { email: doctor.email, status: nextActive ? "active" : "pending" } }),
      });
      const payload = await response.json();
      if (!response.ok || payload?.error) throw new Error(payload?.error?.json?.message || "Could not update doctor activation.");
      updateStore(current => ({
        ...current,
        doctors: current.doctors.map(item => item.id === id ? { ...item, active: nextActive } : item),
      }));
      notify(nextActive ? "Doctor account activated in SQLite." : "Doctor account moved to pending.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Could not update doctor activation.");
    }
  };
  const deleteDoctor = async (id: number) => {
    const doctor = doctors.find(item => item.id === id);
    if (!doctor || !window.confirm(`Delete ${doctor.name} and its login account?`)) return;
    try {
      const response = await fetch("/api/trpc/admin.deleteDoctor", {
        method: "POST", credentials: "include", headers: { "content-type": "application/json" },
        body: JSON.stringify({ json: { email: doctor.email } }),
      });
      const payload = await response.json();
      if (!response.ok || payload?.error) throw new Error(payload?.error?.json?.message || "Could not delete doctor.");
      updateStore(current => ({ ...current, doctors: current.doctors.filter(item => item.id !== id), accounts: current.accounts.filter(account => account.email !== doctor.email) }));
      notify("Doctor record and login account deleted from SQLite.");
    } catch (error) { notify(error instanceof Error ? error.message : "Could not delete doctor."); }
  };
  const toggleBlockedSlot = (key: string) => {
    if (!myDoctor) return;
    updateStore(current => ({
      ...current,
      doctors: current.doctors.map(doctor =>
        doctor.id !== myDoctor.id
          ? doctor
          : {
              ...doctor,
              blockedSlots: doctor.blockedSlots.includes(key)
                ? doctor.blockedSlots.filter(item => item !== key)
                : [...doctor.blockedSlots, key],
            }
      ),
    }));
  };
  const toggleDayOff = (date: string) => {
    if (!myDoctor || !date) return;
    updateStore(current => ({
      ...current,
      doctors: current.doctors.map(doctor =>
        doctor.id !== myDoctor.id
          ? doctor
          : {
              ...doctor,
              daysOff: doctor.daysOff.includes(date)
                ? doctor.daysOff.filter(item => item !== date)
                : [...doctor.daysOff, date],
            }
      ),
    }));
  };
  const setAppointmentStatus = (id: number, status: Appointment["status"]) =>
    updateStore(current => ({
      ...current,
      appointments: current.appointments.map(item =>
        item.id === id ? { ...item, status } : item
      ),
    }));
  const matchedDoctors = useMemo(
    () =>
      activeDoctors.filter(doctor =>
        `${doctor.name} ${doctor.specialty}`
          .toLowerCase()
          .includes(search.toLowerCase())
      ),
    [activeDoctors, search]
  );
  const dateText = (value: string) =>
    new Date(`${value}T12:00:00`).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

  if (bootError)
    return (
      <main className="mx-app">
        <section className="mx-content">
          <div className="mx-panel">
            {bootError}
            <button
              className="mx-outline-button"
              onClick={() => setLocation("/")}
            >
              Return to sign in
            </button>
          </div>
        </section>
      </main>
    );
  if (!store || !account)
    return (
      <main className="mx-app">
        <section className="mx-content">
          <div className="mx-panel">Loading workspace account…</div>
        </section>
      </main>
    );

  return (
    <main className={`mx-app ${role === "Patient" ? "mx-patient-portal" : ""}`}>
      <aside className={`mx-sidebar ${menuOpen ? "open" : ""}`}>
        <div className="mx-side-brand">
          <span className="mx-brand-mark">
            <HeartPulse size={20} />
          </span>
          <span>
            <b>
              MEDNEXUS <em>AI</em>
            </b>
            <small>
              {role === "Patient"
                ? "Patient Portal"
                : role === "Doctor"
                  ? "Doctor Portal"
                  : role === "Hospital Staff"
                    ? "Staff Portal"
                    : "Administrator Portal"}
            </small>
          </span>
          <button
            className="mx-close-nav"
            onClick={() => setMenuOpen(false)}
            aria-label="Close navigation"
          >
            <X size={18} />
          </button>
        </div>
        <div className="mx-side-demo">
          PREVIEW WORKSPACE <span>Local records only</span>
        </div>
        <nav className="mx-sidebar-nav" aria-label={`${role} navigation`}>
          {nav[role].map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                className={page === item.label ? "active" : ""}
                onClick={() => openPage(item.label)}
              >
                <Icon size={15} />
                <span>{item.label}</span>
                {item.label === "Notifications" && <b>1</b>}
              </button>
            );
          })}
        </nav>
        {role === "Patient" && (
          <button className="mx-zapia-button" onClick={() => setModal("zapia")}>
            <span>
              <MessageCircle size={17} />
            </span>
            <span>
              <b>ZAPIA AI Assistant</b>
              <small>Ask anything · Preview workspace</small>
            </span>
            <ChevronDown size={14} />
          </button>
        )}
        <div className="mx-side-foot">
          <span>
            <ShieldCheck size={14} /> Browser-local preview
          </span>
          <button onClick={logout}>
            <LogOut size={14} /> Log out
          </button>
        </div>
      </aside>
      {menuOpen && (
        <button
          className="mx-backdrop"
          onClick={() => setMenuOpen(false)}
          aria-label="Close menu"
        />
      )}
      <section className="mx-workspace">
        {role === "Patient" ? (
          <header className="mx-patient-header">
            <div className="mx-patient-headrow">
              <a className="mx-patient-brand" href="/">
                <span className="mx-brand-mark">
                  <HeartPulse size={19} />
                </span>
                <b>
                  MEDNEXUS <em>AI</em>
                </b>
              </a>
              <div className="mx-patient-heading">
                <span>PROTECTED WORKSPACE · FICTIONAL PREVIEW</span>
                <strong>Patient Portal</strong>
                <small>Your appointments, records, and support</small>
              </div>
              <div className="mx-patient-user">
                <span className="mx-avatar">{actor.initials}</span>
                <b>{actor.name}</b>
                <button onClick={logout}>
                  <LogOut size={14} /> Sign Out
                </button>
              </div>
            </div>
            <nav
              className="mx-patient-nav"
              aria-label="Patient portal navigation"
            >
              {nav.Patient.map(item => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.label}
                    className={page === item.label ? "active" : ""}
                    onClick={() => openPage(item.label)}
                  >
                    <Icon size={14} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
              <button
                className="mx-patient-zapia"
                onClick={() => setModal("zapia")}
              >
                <MessageCircle size={14} />
                <span>ZAPIA AI</span>
              </button>
            </nav>
          </header>
        ) : (
          <header className="mx-topbar">
            <button
              className="mx-mobile-menu"
              aria-label="Open navigation"
              onClick={() => setMenuOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div className="mx-search">
              <Search size={16} />
              <input
                aria-label="Search dashboard"
                placeholder="Search dashboard…"
                value={search}
                onChange={event => setSearch(event.target.value)}
              />
            </div>
            <button
              className="mx-icon-button"
              aria-label="Notifications"
              onClick={() => {
                openPage("Notifications");
                notify("You are viewing browser-local preview updates.");
              }}
            >
              <Bell size={18} />
              <i />
            </button>
            <div className="mx-account">
              <span className="mx-avatar">{actor.initials}</span>
              <span>
                <b>{actor.name}</b>
                <small>{actor.title}</small>
              </span>
              <select
                value={role}
                onChange={event => selectRole(event.target.value as Role)}
                aria-label="Log out and choose another role"
              >
                {roles.map(item => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </div>
          </header>
        )}
        <div
          className={`mx-preview-banner ${role === "Patient" ? "mx-patient-preview-banner" : ""}`}
        >
          <span>
            <Activity size={13} />{" "}
            {role === "Patient"
              ? "PRIVATE PATIENT WORKSPACE · PREVIEW"
              : "HACKATHON PREVIEW"}
          </span>
          <small>
            {storageMode === "localStorage"
              ? "Local records are saved only in this browser profile; they are not shared across devices."
              : "Browser storage unavailable: data is memory-only and clears on refresh."}{" "}
            Role access is not secure production authentication.
          </small>
        </div>
        <div className="mx-content">
          {page === "Dashboard" ? (
            <DashboardHome
              role={role}
              actor={actor}
              appointments={appointments}
              patientAppointments={patientAppointments}
              doctorAppointments={doctorAppointments}
              prescriptions={visiblePrescriptions}
              doctors={matchedDoctors}
              tasks={tasks}
              setTasks={setTasks}
              bedStatus={bedStatus}
              setBedStatus={setBedStatus}
              navigate={openPage}
              setModal={setModal}
              setSelectedDoctor={setSelectedDoctor}
              setReason={setReason}
              setAppointmentStatus={setAppointmentStatus}
              openPrescription={openPrescription}
              setAppointmentDate={setAppointmentDate}
              isSlotBusy={isSlotBusy}
              followUp={
                visiblePrescriptions.find(item => item.followUpDate)
                  ?.followUpDate
              }
            />
          ) : (
            <SectionView
              role={role}
              page={page}
              doctors={matchedDoctors}
              allDoctors={doctors}
              accounts={accounts}
              toggleDoctor={toggleDoctor}
              deleteDoctor={deleteDoctor}
              appointments={visibleAppointments}
              allAppointments={appointments}
              prescriptions={visiblePrescriptions}
              search={search}
              isSlotBusy={isSlotBusy}
              navigate={openPage}
              setModal={setModal}
              setSelectedDoctor={setSelectedDoctor}
              setAppointmentStatus={setAppointmentStatus}
              openPrescription={openPrescription}
              dateText={dateText}
              blockedSlots={myBlockedSlots}
              toggleBlockedSlot={toggleBlockedSlot}
              toggleDayOff={toggleDayOff}
              daysOff={myDoctor?.daysOff || []}
              availabilityDate={availabilityDate}
              setAvailabilityDate={setAvailabilityDate}
              availabilityTime={availabilityTime}
              setAvailabilityTime={setAvailabilityTime}
              uploadDoctors={uploadDoctors}
              uploadStaff={uploadStaff}
              serverStaff={serverStaffQuery.data || []}
              serverStaffLoading={serverStaffQuery.isLoading}
              setStaffAccess={(email: string, status: "pending_setup" | "active" | "suspended", password?: string) => setStaffAccessMutation.mutate({ email, status, password })}
              notify={notify}
              accountEmail={account.email}
              doctorId={account.doctorId}
              bedStatus={bedStatus}
              setMedicineSearch={setMedicineSearch}
              medicineSearch={medicineSearch}
              medicineResult={medicineResult}
              setMedicineResult={setMedicineResult}
              reportText={reportText}
              setReportText={setReportText}
              reportResult={reportResult}
              setReportResult={setReportResult}
            />
          )}
          <footer className="mx-footer">
            MEDNEXUS AI{" "}
            <span>
              Preview workspace · Not connected to live clinical systems systems
            </span>
          </footer>
        </div>
      </section>
      {toast && (
        <div className="mx-toast" role="status">
          <Check size={16} />
          {toast}
          <button onClick={() => setToast("")} aria-label="Dismiss">
            <X size={14} />
          </button>
        </div>
      )}
      {modal && (
        <div
          className="mx-modal-backdrop"
          role="presentation"
          onMouseDown={event => {
            if (event.target === event.currentTarget) setModal("");
          }}
        >
          <section
            className="mx-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="mx-modal-title"
          >
            <button
              className="mx-modal-x"
              onClick={() => setModal("")}
              aria-label="Close"
            >
              <X size={18} />
            </button>
            {modal === "book" && (
              <>
                <div className="mx-eyebrow">FICTIONAL BROWSER PREVIEW</div>
                <h2 id="mx-modal-title">Book an appointment</h2>
                <p>
                  This appointment is saved only in this browser and appears in
                  the assigned doctor's account.
                </p>
                {activeDoctors.length ? (
                  <form onSubmit={book}>
                    <label>
                      Doctor
                      <select
                        value={selectedDoctor || activeDoctors[0].name}
                        onChange={event =>
                          setSelectedDoctor(event.target.value)
                        }
                      >
                        {activeDoctors.map(doctor => (
                          <option key={doctor.id} value={doctor.name}>
                            {doctor.name} · {doctor.specialty}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Consultation type
                      <select
                        value={consultType}
                        onChange={event =>
                          setConsultType(
                            event.target.value as typeof consultType
                          )
                        }
                      >
                        <option>Online</option>
                        <option>In-Person</option>
                      </select>
                    </label>
                    <div className="mx-form-row">
                      <label>
                        Date
                        <input
                          type="date"
                          value={appointmentDate}
                          onChange={event =>
                            setAppointmentDate(event.target.value)
                          }
                          required
                        />
                      </label>
                      <label>
                        Time slot
                        <select
                          value={appointmentTime}
                          onChange={event =>
                            setAppointmentTime(event.target.value)
                          }
                        >
                          {slots.map(time => {
                            const doctor =
                              doctorForName(selectedDoctor) || activeDoctors[0];
                            const busy = isSlotBusy(
                              doctor,
                              appointmentDate,
                              time
                            );
                            return (
                              <option key={time} value={time} disabled={busy}>
                                {time}
                                {busy ? " · unavailable" : ""}
                              </option>
                            );
                          })}
                        </select>
                      </label>
                    </div>
                    <label>
                      Reason
                      <input
                        value={reason}
                        onChange={event => setReason(event.target.value)}
                        placeholder="Brief reason for visit"
                        required
                      />
                    </label>
                    <button className="mx-primary-button" type="submit">
                      Confirm appointment
                    </button>
                  </form>
                ) : (
                  <div className="mx-empty">
                    <CircleHelp size={18} />
                    <span>
                      No administrator-added doctors are available yet.
                    </span>
                  </div>
                )}
              </>
            )}
            {modal === "prescription" && (
              <>
                <div className="mx-eyebrow">DOCTOR WORKSPACE · PREVIEW</div>
                <h2 id="mx-modal-title">Open visit & write prescription</h2>
                <p>
                  Preview consultation only; not medical advice or a real
                  clinical prescription.
                </p>
                <form onSubmit={issuePrescription}>
                  <label>
                    Appointment
                    <select
                      value={
                        prescriptionAppointmentId ||
                        (doctorAppointments.find(
                          item =>
                            !prescriptions.some(
                              rx => rx.appointmentId === item.id
                            )
                        )?.id ??
                          0)
                      }
                      onChange={event =>
                        setPrescriptionAppointmentId(Number(event.target.value))
                      }
                      required
                    >
                      {doctorAppointments
                        .filter(
                          item =>
                            !prescriptions.some(
                              rx => rx.appointmentId === item.id
                            )
                        )
                        .map(item => (
                          <option key={item.id} value={item.id}>
                            {item.patient} · {dateText(item.date)} {item.time} ·{" "}
                            {item.reason}
                          </option>
                        ))}
                    </select>
                  </label>
                  <label>
                    Consultation notes
                    <textarea
                      value={rxNotes}
                      onChange={event => setRxNotes(event.target.value)}
                      required
                      placeholder="Notes for this appointment"
                    />
                  </label>
                  <label>
                    Medicine
                    <input
                      value={rxMedicine}
                      onChange={event => setRxMedicine(event.target.value)}
                      required
                      placeholder="Example: medicine name"
                    />
                  </label>
                  <label>
                    Dosage
                    <input
                      value={rxDose}
                      onChange={event => setRxDose(event.target.value)}
                      required
                      placeholder="Dosage instructions"
                    />
                  </label>
                  <label>
                    Instructions
                    <textarea
                      value={rxInstructions}
                      onChange={event => setRxInstructions(event.target.value)}
                      required
                      placeholder="Medication instructions"
                    />
                  </label>
                  <label>
                    Follow-up date (optional)
                    <input
                      type="date"
                      value={rxFollowUpDate}
                      onChange={event => setRxFollowUpDate(event.target.value)}
                    />
                  </label>
                  <button
                    className="mx-primary-button"
                    type="submit"
                    disabled={
                      !doctorAppointments.some(
                        item =>
                          !prescriptions.some(
                            rx => rx.appointmentId === item.id
                          )
                      )
                    }
                  >
                    Save consultation & prescription
                  </button>
                </form>
              </>
            )}
            {modal === "doctor" && (
              <>
                <div className="mx-eyebrow">ADMINISTRATOR · PREVIEW</div>
                <h2 id="mx-modal-title">Add doctor profile & account</h2>
                <p>
                  Creates a browser-local profile and login. The assigned
                  credentials are shown once after saving.
                </p>
                <form onSubmit={addDoctor}>
                  <label>
                    Doctor name
                    <input
                      value={newDoctor.name}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          name: event.target.value,
                          email: defaultDoctorEmail(event.target.value),
                        })
                      }
                      required
                      placeholder="Dr. Name"
                    />
                  </label>
                  <label>
                    Specialty
                    <select
                      value={newDoctor.specialty}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          specialty: event.target.value,
                        })
                      }
                    >
                      <option>Cardiology</option>
                      <option>Pediatrics</option>
                      <option>Internal Medicine</option>
                      <option>Dermatology</option>
                      <option>General Medicine</option>
                      <option>Neurology</option>
                    </select>
                  </label>
                  <label>
                    Qualifications
                    <input
                      value={newDoctor.qualifications}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          qualifications: event.target.value,
                        })
                      }
                      required
                      placeholder="Qualifications"
                    />
                  </label>
                  <label>
                    Experience
                    <input
                      value={newDoctor.experience}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          experience: event.target.value,
                        })
                      }
                      required
                      placeholder="Example: 8 years"
                    />
                  </label>
                  <label>
                    Assigned demo email
                    <input
                      type="email"
                      value={newDoctor.email}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          email: event.target.value,
                        })
                      }
                      required
                    />
                  </label>
                  <label>
                    Assigned demo password
                    <input
                      type="password"
                      value={newDoctor.password}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          password: event.target.value,
                        })
                      }
                      minLength={6}
                      required
                      placeholder="Choose a demo password"
                    />
                  </label>
                  <label>
                    Doctor photograph
                    <input
                      type="file"
                      accept="image/*"
                      onChange={async event => {
                        const file = event.target.files?.[0];
                        if (file) {
                          try {
                            setNewDoctorPhoto(await imageDataUrl(file));
                          } catch {
                            notify(
                              "Could not read this photograph; try a JPEG or PNG."
                            );
                          }
                        }
                      }}
                    />
                  </label>
                  {newDoctorPhoto && (
                    <img
                      className="mx-doctor-upload-preview"
                      src={newDoctorPhoto}
                      alt="Doctor profile upload preview"
                    />
                  )}
                  <label>
                    Consultation fee
                    <input
                      type="number"
                      min="0"
                      value={newDoctor.fee}
                      onChange={event =>
                        setNewDoctor({ ...newDoctor, fee: event.target.value })
                      }
                    />
                  </label>
                  <label>
                    Working hours
                    <input
                      value={newDoctor.hours}
                      onChange={event =>
                        setNewDoctor({
                          ...newDoctor,
                          hours: event.target.value,
                        })
                      }
                    />
                  </label>
                  <button className="mx-primary-button" type="submit">
                    Create doctor account
                  </button>
                </form>
              </>
            )}
            {modal === "zapia" && (
              <>
                <div className="mx-eyebrow">
                  PATIENT SUPPORT · ZAPIA AI ASSISTANCE
                </div>
                <h2 id="mx-modal-title">ZAPIA Assistance</h2>
                <p>
                  For urgent assistance, call the ZAPIA support number below.
                  This preview does not claim that an AI voice agent or
                  telephony provider is connected.
                </p>
                <div className="mx-resource-row">
                  <Phone size={18} />
                  <span>
                    <b>+91 9166894377</b>
                    <small>
                      Assistance number · verify availability before relying on
                      it
                    </small>
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    marginTop: 12,
                    flexWrap: "wrap",
                  }}
                >
                  <a className="mx-primary-button" href="tel:+919166894377">
                    <Phone size={15} /> Call ZAPIA Assistance
                  </a>
                  <button
                    className="mx-outline-button"
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText("+91 9166894377").then(
                        () => notify("ZAPIA number copied."),
                        () =>
                          notify("Select and copy the number: +91 9166894377")
                      );
                    }}
                  >
                    <Copy size={15} /> Copy Number
                  </button>
                </div>
                <button
                  className="mx-outline-button mx-modal-done"
                  type="button"
                  onClick={() => setModal("")}
                >
                  Close
                </button>
              </>
            )}
            {modal === "credentials" && (
              <>
                <div className="mx-eyebrow">
                  ADMINISTRATOR · FICTIONAL ACCOUNTS
                </div>
                <h2 id="mx-modal-title">Assigned demo credentials</h2>
                <p>
                  Copy these credentials now. Passwords are hashed in the
                  browser store; they are not production credentials.
                </p>
                <div className="mx-credential-list">
                  {credentialReport.map((item, index) => (
                    <div
                      className="mx-credential-row"
                      key={`${item.email}-${index}`}
                    >
                      <b>{item.name}</b>
                      <span>{item.email}</span>
                      <code>{item.password}</code>
                    </div>
                  ))}
                </div>
                <button
                  className="mx-primary-button"
                  type="button"
                  onClick={() => {
                    const text = credentialReport
                      .map(
                        item => `${item.name}\t${item.email}\t${item.password}`
                      )
                      .join("\n");
                    navigator.clipboard?.writeText(text).then(
                      () => notify("Credentials copied."),
                      () =>
                        notify(
                          "Select and copy the displayed demo credentials."
                        )
                    );
                  }}
                >
                  Copy credentials
                </button>
                <button
                  className="mx-outline-button mx-modal-done"
                  type="button"
                  onClick={() => setModal("")}
                >
                  Done
                </button>
              </>
            )}
          </section>
        </div>
      )}
      {role === "Administrator" && <EmergencySOS />}
    </main>
  );
}

async function imageDataUrl(file: File): Promise<string> {
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = objectUrl;
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error("Unable to load image"));
    });
    const scale = Math.min(1, 480 / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas unavailable");
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.76);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function DashboardHome({
  role,
  actor,
  appointments,
  patientAppointments,
  doctorAppointments,
  prescriptions,
  doctors,
  tasks,
  setTasks,
  bedStatus,
  setBedStatus,
  navigate,
  setModal,
  setSelectedDoctor,
  setAppointmentDate,
  setReason,
  setAppointmentStatus,
  openPrescription,
  followUp,
  isSlotBusy,
}: {
  role: Role;
  actor: { name: string; email: string; title: string; initials: string };
  appointments: Appointment[];
  patientAppointments: Appointment[];
  doctorAppointments: Appointment[];
  prescriptions: Prescription[];
  doctors: Doctor[];
  tasks: boolean[];
  setTasks: (callback: (rows: boolean[]) => boolean[]) => void;
  bedStatus: string;
  setBedStatus: (value: string) => void;
  navigate: (page: string) => void;
  setModal: (modal: Modal) => void;
  setSelectedDoctor: (name: string) => void;
  setAppointmentDate: (date: string) => void;
  setReason: (reason: string) => void;
  setAppointmentStatus: (id: number, status: Appointment["status"]) => void;
  openPrescription: (id?: number) => void;
  followUp?: string;
  isSlotBusy: (
    doctor: Doctor | undefined,
    date: string,
    time: string
  ) => boolean;
}) {
  const cards = heroCards[role];
  const metrics: Record<Role, [string, string, string, string][]> = {
    Patient: [
      [
        "Upcoming Appointment",
        String(
          patientAppointments.filter(item => item.status !== "Completed").length
        ),
        "Next visit",
        "teal",
      ],
      ["Prescriptions", String(prescriptions.length), "Care plans", "blue"],
      [
        "Follow-ups",
        String(prescriptions.filter(item => item.followUpDate).length),
        "From visits",
        "violet",
      ],
      [
        "Medical Records",
        String(
          patientAppointments.filter(item => item.consultationNotes).length
        ),
        "Consultations",
        "green",
      ],
    ],
    Doctor: [
      [
        "Today's Appointments",
        String(doctorAppointments.length),
        "In your schedule",
        "teal",
      ],
      [
        "Pending Requests",
        String(
          doctorAppointments.filter(item => item.status === "Pending").length
        ),
        "Need review",
        "amber",
      ],
      [
        "Follow-ups",
        String(doctorAppointments.filter(item => item.followUpDate).length),
        "From visits",
        "blue",
      ],
      [
        "Total Patients",
        String(new Set(doctorAppointments.map(item => item.patientEmail)).size),
        "Medical records",
        "green",
      ],
    ],
    "Hospital Staff": [
      [
        "Assigned Tasks",
        String(tasks.filter(Boolean).length),
        "Completed",
        "teal",
      ],
      ["Patient Check-in", "0", "Waiting", "amber"],
      ["Bed Requests", "0", "Need review", "violet"],
      ["Ambulance Requests", "0", "Preview", "blue"],
    ],
    Administrator: [
      ["Total Doctors", String(doctors.length), "Profiles", "blue"],
      [
        "Total Patients",
        String(new Set(appointments.map(item => item.patientEmail)).size),
        "Accounts",
        "rose",
      ],
      [
        "Today's Appointments",
        String(appointments.length),
        "Across hospital",
        "amber",
      ],
      ["Available Beds", bedStatus, "Reported count", "teal"],
    ],
  };
  const upcoming = patientAppointments.find(
    item => item.status !== "Completed"
  );
  return (
    <>
      <section
        className={`mx-greeting ${role === "Patient" ? "mx-patient-welcome" : ""}`}
      >
        <div>
          <div className="mx-eyebrow">
            MEDNEXUS GENERAL HOSPITAL · FICTIONAL PREVIEW
          </div>
          <h1>
            {role === "Patient"
              ? `Hello, ${actor.name}`
              : role === "Doctor"
                ? `Welcome, ${actor.name}`
                : role === "Hospital Staff"
                  ? `Welcome, ${actor.name}!`
                  : "Hospital Overview"}
          </h1>
          <p>
            {role === "Patient"
              ? "Your appointments, records, and healthcare support in one place."
              : role === "Doctor"
                ? "Here's your visit schedule."
                : role === "Hospital Staff"
                  ? "Here are your demo tasks for today."
                  : "A clear view of hospital operations."}
          </p>
        </div>
        {role === "Patient" ? (
          <div className="mx-patient-welcome-actions">
            <button
              className="mx-primary-button"
              onClick={() => navigate("Find Doctors")}
            >
              <CalendarDays size={16} /> Book Appointment
            </button>
            <button
              className="mx-outline-button"
              onClick={() => navigate("Medical Records")}
            >
              <FileText size={16} /> My Records
            </button>
          </div>
        ) : (
          <div className="mx-health-promo">
            <span>
              Your Health,
              <br />
              Our Priority
            </span>
            <span className="mx-promo-icon">
              <HeartPulse size={30} />
            </span>
          </div>
        )}
      </section>
      {role === "Patient" && (
        <div className="mx-private-workspace">
          <ShieldCheck size={18} />
          <span>
            <b>Private Patient Workspace</b>
            <small>Profile and medical records · This browser only</small>
          </span>
          <span className="mx-patient-lock">LOCAL PREVIEW</span>
        </div>
      )}
      <section className="mx-stat-grid">
        {metrics[role].map(([label, value, hint, color]) => (
          <article className="mx-stat-card" key={label}>
            <span className={`mx-stat-icon ${color}`}>
              {label.includes("Appointment") ? (
                <CalendarDays size={19} />
              ) : label.includes("Prescription") ? (
                <Pill size={19} />
              ) : label.includes("Doctor") || label.includes("Patients") ? (
                <Users size={19} />
              ) : label.includes("Bed") ? (
                <BedDouble size={19} />
              ) : (
                <Activity size={19} />
              )}
            </span>
            <small>{label}</small>
            <strong>{value}</strong>
            <span className="mx-stat-hint">{hint}</span>
          </article>
        ))}
      </section>
      <section className="mx-action-grid">
        {cards.map(({ title, sub, icon: Icon, color, page }) => (
          <button
            key={title}
            className="mx-action-card"
            onClick={() => {
              if (title === "Book Appointment") {
                if (doctors.length) setModal("book");
                else navigate("Find Doctors");
              } else if (title === "Write Prescription") openPrescription();
              else navigate(page);
            }}
          >
            <span className={`mx-action-icon ${color}`}>
              <Icon size={20} />
            </span>
            <strong>{title}</strong>
            <small>{sub}</small>
          </button>
        ))}
      </section>
      {role === "Patient" && (
        <div className="mx-panels patient-panels">
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Upcoming Appointment</h2>
              <button onClick={() => navigate("My Appointments")}>
                View all
              </button>
            </div>
            {upcoming ? (
              <AppointmentCard appointment={upcoming} />
            ) : (
              <Empty
                text="No upcoming appointment."
                button="Book an appointment"
                onClick={() => setModal("book")}
              />
            )}
          </section>
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Latest Prescription</h2>
              <button onClick={() => navigate("Prescriptions")}>
                View all
              </button>
            </div>
            <PrescriptionCard prescription={prescriptions[0]} />
          </section>
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Follow-Up Reminder</h2>
            </div>
            <div className="mx-follow">
              <CalendarDays />
              <span>
                <b>
                  {followUp
                    ? `Your demo follow-up is due ${followUp}.`
                    : "No follow-up has been recommended yet."}
                </b>
                <small>Reminder from a consultation</small>
              </span>
              <button
                onClick={() => {
                  setSelectedDoctor(
                    prescriptions.find(item => item.followUpDate)?.doctor ||
                      prescriptions[0]?.doctor ||
                      doctors[0]?.name ||
                      ""
                  );
                  setAppointmentDate(followUp || "2026-10-26");
                  setReason("Follow-up");
                  setModal("book");
                }}
              >
                Book Follow-Up
              </button>
            </div>
          </section>
        </div>
      )}
      {role === "Patient" && (
        <div className="mx-patient-records-grid">
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Medical Records</h2>
              <button onClick={() => navigate("Medical Records")}>
                View records
              </button>
            </div>
            {patientAppointments.filter(item => item.consultationNotes)
              .length ? (
              patientAppointments
                .filter(item => item.consultationNotes)
                .slice(0, 3)
                .map(item => (
                  <article className="mx-patient-record-item" key={item.id}>
                    <FileText size={17} />
                    <span>
                      <b>Consultation · {item.doctor}</b>
                      <small>{item.date} · local record</small>
                      <p>{item.consultationNotes}</p>
                    </span>
                  </article>
                ))
            ) : (
              <Empty text="No consultation records are available for this account yet." />
            )}
          </section>
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Prescriptions</h2>
              <button onClick={() => navigate("Prescriptions")}>
                View all
              </button>
            </div>
            {prescriptions.length ? (
              prescriptions.slice(0, 3).map(item => (
                <article className="mx-patient-record-item" key={item.id}>
                  <Pill size={17} />
                  <span>
                    <b>
                      {item.doctor} · {item.date}
                    </b>
                    <small>{item.medicines.join(" · ")}</small>
                    {item.followUpDate && (
                      <small>Follow-up: {item.followUpDate}</small>
                    )}
                  </span>
                </article>
              ))
            ) : (
              <Empty text="No prescriptions are available for this account yet." />
            )}
          </section>
        </div>
      )}
      {role === "Doctor" && (
        <section className="mx-panel mx-wide-panel">
          <div className="mx-panel-head">
            <h2>Today's Appointments</h2>
            <button onClick={() => navigate("My Appointments")}>
              View calendar
            </button>
          </div>
          <AppointmentTable
            rows={doctorAppointments}
            role={role}
            action={setAppointmentStatus}
            openPrescription={openPrescription}
          />
        </section>
      )}
      {role === "Hospital Staff" && (
        <div className="mx-panels">
          <section className="mx-panel mx-wide-panel">
            <div className="mx-panel-head">
              <h2>Today's Tasks</h2>
              <button onClick={() => navigate("Assigned Tasks")}>
                View all
              </button>
            </div>
            {[
              "Patient admission – Room 203",
              "Update bed status – ICU 2",
              "Prepare discharge documents",
              "Inventory check – IV fluids",
            ].map((task, index) => (
              <label className="mx-task" key={task}>
                <input
                  type="checkbox"
                  checked={!!tasks[index]}
                  onChange={() =>
                    setTasks(rows =>
                      rows.map((value, i) => (i === index ? !value : value))
                    )
                  }
                />
                <span>{task}</span>
                <b className={index === 0 ? "high" : "medium"}>
                  {index === 0 ? "High" : index === 1 ? "Medium" : "Low"}
                </b>
              </label>
            ))}
          </section>
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Bed Management</h2>
              <button onClick={() => navigate("Bed Management")}>Open</button>
            </div>
            <div className="mx-bed-count">
              <strong>{bedStatus}</strong>
              <span>Available beds</span>
              <select
                value={bedStatus}
                onChange={event => setBedStatus(event.target.value)}
              >
                <option>0</option>
                <option>1</option>
                <option>2</option>
                <option>36</option>
              </select>
            </div>
          </section>
        </div>
      )}
      {role === "Administrator" && (
        <div className="mx-panels admin-panels">
          <section className="mx-panel mx-wide-panel">
            <div className="mx-panel-head">
              <h2>Recent Appointments</h2>
              <button onClick={() => navigate("Appointments")}>View all</button>
            </div>
            <AppointmentTable
              rows={appointments.slice(0, 5)}
              role={role}
              action={setAppointmentStatus}
            />
          </section>
          <section className="mx-panel">
            <div className="mx-panel-head">
              <h2>Hospital Resources</h2>
              <button onClick={() => navigate("Hospital Resources")}>
                Manage
              </button>
            </div>
            <div className="mx-resource-row">
              <BedDouble />
              <span>
                <b>General beds</b>
                <small>Reported capacity</small>
              </span>
              <strong>{bedStatus} available</strong>
            </div>
            <div className="mx-resource-row">
              <Pill />
              <span>
                <b>Inventory</b>
                <small>No live stock connected</small>
              </span>
              <strong>Preview</strong>
            </div>
          </section>
        </div>
      )}
      {role === "Patient" && (
        <PatientDoctorDirectory
          doctors={doctors}
          setSelectedDoctor={setSelectedDoctor}
          onBook={doctor => {
            setSelectedDoctor(doctor.name);
            setModal("book");
          }}
          isSlotBusy={isSlotBusy}
        />
      )}
    </>
  );
}

function AppointmentCard({ appointment }: { appointment: Appointment }) {
  return (
    <div className="mx-appointment-card">
      <DoctorAvatar name={appointment.doctor} />
      <div className="mx-appointment-info">
        <b>{appointment.doctor}</b>
        <small>{appointment.specialty}</small>
        <span>
          <CalendarDays size={13} /> {appointment.date} · {appointment.time}
        </span>
        <i>
          {appointment.type} consultation · {appointment.status}
        </i>
      </div>
    </div>
  );
}
function DoctorAvatar({ name, photo }: { name: string; photo?: string }) {
  return photo ? (
    <img className="mx-doctor-avatar" src={photo} alt={`Profile of ${name}`} />
  ) : (
    <span className="mx-doctor-avatar mx-initials">
      {name
        .split(" ")
        .filter(Boolean)
        .slice(-2)
        .map(part => part[0])
        .join("")}
    </span>
  );
}
function PrescriptionCard({ prescription }: { prescription?: Prescription }) {
  if (!prescription) return <Empty text="No prescription available." />;
  return (
    <div className="mx-rx-card">
      <DoctorAvatar name={prescription.doctor} />
      <div>
        <b>{prescription.doctor}</b>
        <small>Consultation · {prescription.date}</small>
        {prescription.medicines.slice(0, 2).map(medicine => (
          <span key={medicine}>
            <Pill size={12} /> {medicine}
          </span>
        ))}
      </div>
      <i>Preview</i>
    </div>
  );
}
function AppointmentTable({
  rows,
  role,
  action,
  openPrescription,
}: {
  rows: Appointment[];
  role: Role;
  action: (id: number, status: Appointment["status"]) => void;
  openPrescription?: (id: number) => void;
}) {
  return (
    <div className="mx-table-wrap">
      <table className="mx-table">
        <thead>
          <tr>
            <th>Time</th>
            <th>Patient</th>
            <th>Doctor</th>
            <th>Type</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {rows.length ? (
            rows.map(item => (
              <tr key={item.id}>
                <td>
                  {item.time}
                  <small className="mx-cell-sub">{item.date}</small>
                </td>
                <td>
                  <DoctorAvatar name={item.patient} />
                  {item.patient}
                  <small className="mx-cell-sub">{item.reason}</small>
                </td>
                <td>{item.doctor}</td>
                <td>
                  <span className="mx-type-pill">{item.type}</span>
                </td>
                <td>
                  <span className={`mx-status ${item.status.toLowerCase()}`}>
                    {item.status}
                  </span>
                </td>
                <td>
                  {role === "Doctor" ? (
                    <button
                      className="mx-mini-button"
                      onClick={() => openPrescription?.(item.id)}
                    >
                      {item.status === "Completed" ? "History" : "Open visit"}
                    </button>
                  ) : item.status === "Pending" ? (
                    <button
                      className="mx-mini-button"
                      onClick={() => action(item.id, "Confirmed")}
                    >
                      Confirm
                    </button>
                  ) : item.status === "Confirmed" ? (
                    <button
                      className="mx-mini-button"
                      onClick={() => action(item.id, "Completed")}
                    >
                      Complete
                    </button>
                  ) : (
                    <Check size={15} />
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={6}>No appointments yet.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
function DoctorCards({
  doctors,
  setSelectedDoctor,
}: {
  doctors: Doctor[];
  setSelectedDoctor: (doctor: Doctor) => void;
}) {
  return doctors.length ? (
    <div className="mx-doctor-grid">
      {doctors.map(doctor => (
        <article className="mx-doctor-card" key={doctor.id}>
          <DoctorAvatar name={doctor.name} photo={doctor.photo} />
          <div>
            <b>{doctor.name}</b>
            <small>{doctor.specialty}</small>
            <small>
              {doctor.qualifications} · {doctor.experience} experience
            </small>
            <span>Local preview profile · No reviews</span>
            <small>
              ₹{doctor.fee} · {doctor.hours}
            </small>
            <button onClick={() => setSelectedDoctor(doctor)}>
              Book Appointment
            </button>
          </div>
        </article>
      ))}
    </div>
  ) : (
    <Empty text="No doctors have been added to this directory yet." />
  );
}
function PatientDoctorDirectory({
  doctors,
  setSelectedDoctor,
  onBook,
  isSlotBusy,
}: {
  doctors: Doctor[];
  setSelectedDoctor: (name: string) => void;
  onBook: (doctor: Doctor) => void;
  isSlotBusy: (
    doctor: Doctor | undefined,
    date: string,
    time: string
  ) => boolean;
}) {
  const [query, setQuery] = useState("");
  const [specialty, setSpecialty] = useState("All specialties");
  const [language, setLanguage] = useState("All languages");
  const [availability, setAvailability] = useState("Any availability");
  const [date, setDate] = useState("2026-10-26");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const specialties = Array.from(
    new Set(doctors.map(doctor => doctor.specialty).filter(Boolean))
  );
  const languages = Array.from(
    new Set(
      doctors.flatMap(doctor =>
        ((doctor as Doctor & { languages?: string }).languages || "")
          .split(/[,/]/)
          .map(value => value.trim())
          .filter(Boolean)
      )
    )
  );
  const openSlots = (doctor: Doctor) =>
    slots.filter(time => !isSlotBusy(doctor, date, time));
  const filtered = doctors.filter(doctor => {
    const doctorLanguages = (
      (doctor as Doctor & { languages?: string }).languages || ""
    ).toLowerCase();
    const matchesQuery =
      `${doctor.name} ${doctor.specialty} ${doctor.qualifications}`
        .toLowerCase()
        .includes(query.trim().toLowerCase());
    const matchesLanguage =
      language === "All languages" ||
      (language === "Not specified"
        ? !doctorLanguages
        : doctorLanguages.includes(language.toLowerCase()));
    const hasAvailability = openSlots(doctor).length > 0;
    return (
      matchesQuery &&
      (specialty === "All specialties" || doctor.specialty === specialty) &&
      matchesLanguage &&
      (availability === "Any availability" ||
        (availability === "Has open slots"
          ? hasAvailability
          : !hasAvailability))
    );
  });
  const selected =
    filtered.find(doctor => doctor.id === selectedId) || filtered[0];
  return (
    <section className="mx-patient-directory">
      <div className="mx-patient-directory-head">
        <div>
          <div className="mx-eyebrow">CARE TEAM DIRECTORY</div>
          <h2>Find your doctor</h2>
          <p>
            Browse administrator-added profiles. Availability is checked again
            before a booking is saved.
          </p>
        </div>
        <button
          className="mx-primary-button"
          onClick={() => selected && onBook(selected)}
          disabled={!selected}
        >
          <CalendarDays size={15} /> Book Appointment
        </button>
      </div>
      <div className="mx-patient-filters">
        <label className="mx-patient-search">
          <Search size={16} />
          <input
            value={query}
            onChange={event => setQuery(event.target.value)}
            placeholder="Search by doctor or specialty"
            aria-label="Search doctors"
          />
        </label>
        <label>
          <span>Specialty</span>
          <select
            value={specialty}
            onChange={event => setSpecialty(event.target.value)}
          >
            <option>All specialties</option>
            {specialties.map(value => (
              <option key={value}>{value}</option>
            ))}
          </select>
        </label>
        <label>
          <span>Language</span>
          <select
            value={language}
            onChange={event => setLanguage(event.target.value)}
          >
            <option>All languages</option>
            <option>Not specified</option>
            {languages.map(value => (
              <option key={value}>{value}</option>
            ))}
          </select>
        </label>
        <label>
          <span>Availability date</span>
          <input
            type="date"
            value={date}
            onChange={event => setDate(event.target.value)}
          />
        </label>
        <label>
          <span>Availability</span>
          <select
            value={availability}
            onChange={event => setAvailability(event.target.value)}
          >
            <option>Any availability</option>
            <option>Has open slots</option>
            <option>No open slots</option>
          </select>
        </label>
      </div>
      {filtered.length ? (
        <div className="mx-patient-doctor-grid">
          {filtered.map(doctor => (
            <article
              className={`mx-patient-doctor-card ${selected?.id === doctor.id ? "selected" : ""}`}
              key={doctor.id}
            >
              <div className="mx-patient-doctor-image">
                <DoctorAvatar name={doctor.name} photo={doctor.photo} />
              </div>
              <div className="mx-patient-doctor-copy">
                <span className="mx-patient-specialty">{doctor.specialty}</span>
                <h3>{doctor.name}</h3>
                <p>
                  {doctor.experience || "Experience not provided"} experience ·{" "}
                  {doctor.qualifications || "Qualifications not provided"}
                </p>
                <p>
                  <Hospital size={13} /> MEDNEXUS General Hospital
                </p>
                <p>
                  <Users size={13} />{" "}
                  {(doctor as Doctor & { languages?: string }).languages ||
                    "Languages not specified"}
                </p>
                <div className="mx-patient-doctor-meta">
                  <span>No reviews yet</span>
                  <span>₹{doctor.fee}</span>
                </div>
                <small className="mx-open-slots">
                  {openSlots(doctor).length
                    ? `Open slots: ${openSlots(doctor).slice(0, 3).join(" · ")}`
                    : `No open slots on ${date}`}
                </small>
                <div className="mx-patient-doctor-actions">
                  <button
                    className="mx-outline-button"
                    onClick={() => setSelectedId(doctor.id)}
                  >
                    View Profile
                  </button>
                  <button
                    className="mx-primary-button"
                    onClick={() => onBook(doctor)}
                  >
                    Book
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="mx-patient-empty">
          <Stethoscope size={22} />
          <span>
            No active doctor profiles match these filters. An administrator must
            add a profile before booking.
          </span>
        </div>
      )}
      <div className="mx-selected-doctor">
        <div className="mx-eyebrow">SELECTED DOCTOR PROFILE</div>
        {selected ? (
          <div className="mx-selected-doctor-row">
            <div className="mx-selected-doctor-photo">
              <DoctorAvatar name={selected.name} photo={selected.photo} />
            </div>
            <div>
              <h3>{selected.name}</h3>
              <p>
                {selected.specialty} ·{" "}
                {selected.qualifications || "Qualifications not provided"} ·{" "}
                {selected.experience || "Experience not provided"} experience
              </p>
              <p>
                MEDNEXUS General Hospital ·{" "}
                {(selected as Doctor & { languages?: string }).languages ||
                  "Languages not specified"}{" "}
                · {selected.hours || "Hours not provided"}
              </p>
              <small>
                Administrator profile. No reviews or verified availability are
                claimed.
              </small>
            </div>
            <button
              className="mx-primary-button"
              onClick={() => onBook(selected)}
            >
              <CalendarDays size={15} /> Book Appointment
            </button>
          </div>
        ) : (
          <div className="mx-patient-empty">
            Select an administrator-added doctor to view the profile.
          </div>
        )}
      </div>
    </section>
  );
}

function Empty({
  text,
  button,
  onClick,
}: {
  text: string;
  button?: string;
  onClick?: () => void;
}) {
  return (
    <div className="mx-empty">
      <CircleHelp size={18} />
      <span>{text}</span>
      {button && <button onClick={onClick}>{button}</button>}
    </div>
  );
}

function SectionView(props: any) {
  const {
    role,
    page,
    doctors,
    allDoctors,
    accounts,
    toggleDoctor,
    deleteDoctor,
    appointments,
    allAppointments,
    prescriptions,
    search,
    isSlotBusy,
    navigate,
    setModal,
    setSelectedDoctor,
    setAppointmentStatus,
    openPrescription,
    dateText,
    blockedSlots,
    toggleBlockedSlot,
    toggleDayOff,
    daysOff,
    availabilityDate,
    setAvailabilityDate,
    availabilityTime,
    setAvailabilityTime,
    uploadDoctors,
    uploadStaff,
    serverStaff,
    serverStaffLoading,
    setStaffAccess,
    notify,
    medicineSearch,
    setMedicineSearch,
    medicineResult,
    setMedicineResult,
    reportText,
    setReportText,
    reportResult,
    setReportResult,
  } = props;
  if (page === "Find Doctors")
    return role === "Patient" ? (
      <PatientDoctorDirectory
        doctors={doctors}
        setSelectedDoctor={setSelectedDoctor}
        onBook={doctor => {
          setSelectedDoctor(doctor.name);
          setModal("book");
        }}
        isSlotBusy={isSlotBusy}
      />
    ) : (
      <>
        <SectionHeading
          title="Find Doctors"
          sub="Only administrator-added profiles appear here."
        />
        <DoctorCards
          doctors={doctors}
          setSelectedDoctor={(doctor: Doctor) => {
            setSelectedDoctor(doctor.name);
            setModal("book");
          }}
        />
      </>
    );
  if (page === "Doctors" && role === "Administrator")
    return (
      <>
        <SectionHeading
          title="Doctors"
          sub="Manage profiles, photographs, availability and assigned accounts."
          action={
            <div className="mx-admin-doctor-actions">
              <label className="mx-upload-control">
                Import CSV / Excel
                <input
                  type="file"
                  accept=".csv,.xlsx,.xls,text/csv"
                  onChange={uploadDoctors}
                />
              </label>
              <button
                className="mx-primary-button"
                onClick={() => setModal("doctor")}
              >
                <Plus size={15} /> Add Doctor
              </button>
            </div>
          }
        />
        <p className="mx-upload-hint">
          Spreadsheet columns: name, specialty, qualifications, experience,
          email, password, fee, hours, photoUrl. Missing passwords are generated
          and displayed after import.
        </p>
        <DoctorCards
          doctors={doctors}
          setSelectedDoctor={(doctor: Doctor) => {
            setSelectedDoctor(doctor.name);
            setModal("book");
          }}
        />
        <div className="mx-panel">
          <div className="mx-panel-head">
            <h2>Doctor accounts</h2>
            <span>Login accounts; local to this browser.</span>
          </div>
          {allDoctors.length ? (
            allDoctors.map((doctor: Doctor) => (
              <div className="mx-resource-row" key={doctor.id}>
                <DoctorAvatar name={doctor.name} photo={doctor.photo} />
                <span>
                  <b>{doctor.name}</b>
                  <small>
                    {doctor.specialty} · {doctor.qualifications} ·{" "}
                    {doctor.experience} · {doctor.email} · ₹{doctor.fee} ·{" "}
                    {doctor.hours}
                  </small>
                </span>
                <button
                  className="mx-outline-button"
                  onClick={() => toggleDoctor(doctor.id)}
                >
                  {doctor.active ? "Deactivate" : "Activate"}
                </button>
                <button
                  className="mx-outline-button"
                  onClick={() => deleteDoctor(doctor.id)}
                >
                  Delete
                </button>
              </div>
            ))
          ) : (
            <Empty text="No doctors yet. Add one or import a CSV/Excel file." />
          )}
        </div>
      </>
    );
  if (page === "Staff" && role === "Administrator")
    return (
      <>
        <SectionHeading
          title="Staff"
          sub="Import staff credentials and manage browser-local staff access."
          action={
            <label className="mx-upload-control">
              Import Staff CSV / Excel
              <input type="file" accept=".csv,.xlsx,.xls,text/csv" onChange={uploadStaff} />
            </label>
          }
        />
        <p className="mx-upload-hint">Columns: name, email, password. Imported staff can sign in with the same credentials.</p>
        <section className="mx-panel">
          <div className="mx-panel-head"><h2>Staff accounts</h2><span>{serverStaff.length} SQLite account(s)</span></div>
          {serverStaffLoading ? <Empty text="Loading staff records from SQLite…" /> : serverStaff.map((staff: any) => (
            <div className="mx-resource-row" key={staff.id}>
              <Users />
              <span><b>{staff.name}</b><small>{staff.email} · Hospital Staff</small></span>
              <span className={`mx-status ${staff.status === "active" ? "confirmed" : "pending"}`}>{staff.status === "active" ? "Active" : "Pending Activation"}</span>
              <button className="mx-outline-button" onClick={() => {
                const password = window.prompt(`Set a password for ${staff.name} (minimum 8 characters):`, "");
                if (password === null) return;
                if (password.length < 8) { notify("Password must be at least 8 characters."); return; }
                setStaffAccess(staff.email, "active", password);
              }}>{staff.status === "active" ? "Reset password" : "Activate & set password"}</button>
            </div>
          ))}
          {!serverStaffLoading && !serverStaff.length && <Empty text="No staff accounts yet. Import the CSV/Excel file to add staff members." />}
        </section>
      </>
    );
  if (
    ["My Appointments", "Appointments", "Today's Appointments"].includes(page)
  )
    return (
      <>
        <SectionHeading
          title={page}
          sub="Appointments are stored in the shared browser-local workspace."
        />
        {role === "Patient" && (
          <div className="mx-panel-head">
            <span />{" "}
            <button
              className="mx-primary-button"
              onClick={() => setModal("book")}
            >
              Book Appointment
            </button>
          </div>
        )}
        <section className="mx-panel">
          <AppointmentTable
            rows={appointments}
            role={role}
            action={setAppointmentStatus}
            openPrescription={openPrescription}
          />
        </section>
      </>
    );
  if (["Prescriptions", "Medical Records"].includes(page))
    return (
      <>
        <SectionHeading
          title={page}
          sub="Patient records are limited to this browser-local preview."
          action={
            role === "Doctor" ? (
              <button
                className="mx-primary-button"
                onClick={() => openPrescription()}
              >
                <Plus size={15} /> Open visit / prescription
              </button>
            ) : null
          }
        />
        <section className="mx-panel">
          {page === "Prescriptions" ? (
            prescriptions.length ? (
              prescriptions.map((item: Prescription) => (
                <div className="mx-resource-row" key={item.id}>
                  <Pill />
                  <span>
                    <b>
                      {item.patient} · {item.doctor}
                    </b>
                    <small>
                      {item.date} · {item.medicines.join(" · ")} · Notes:{" "}
                      {item.notes}
                    </small>
                    {item.followUpDate && (
                      <small>Follow-up: {item.followUpDate}</small>
                    )}
                  </span>
                  <span className="mx-status confirmed">Preview</span>
                </div>
              ))
            ) : (
              <Empty text="No prescriptions yet." />
            )
          ) : (
            <div className="mx-record-grid">
              {appointments
                .filter(
                  (item: Appointment) =>
                    role !== "Patient" ||
                    item.patientEmail === props.accountEmail
                )
                .map((item: Appointment) => (
                  <article className="mx-record-card" key={item.id}>
                    <FileText />
                    <b>Consultation · {item.doctor}</b>
                    <small>{dateText(item.date)} · consultation record</small>
                    <p>
                      {item.consultationNotes || "No consultation notes yet."}
                    </p>
                  </article>
                ))}
            </div>
          )}
        </section>
      </>
    );
  if (
    ["Schedule & Leave", "Manage Schedule"].includes(page) &&
    role === "Doctor"
  )
    return (
      <>
        <SectionHeading
          title="Schedule & Leave"
          sub="Availability changes are saved to this doctor account in this browser."
        />
        <section className="mx-panel">
          <div className="mx-panel-head">
            <h2>Mark a day off</h2>
            <span>{daysOff.length} day(s) blocked</span>
          </div>
          <div className="mx-availability-controls">
            <label>
              Date
              <input
                type="date"
                value={availabilityDate}
                onChange={(event: ChangeEvent<HTMLInputElement>) =>
                  setAvailabilityDate(event.target.value)
                }
              />
            </label>
            <button
              className="mx-outline-button"
              onClick={() => toggleDayOff(availabilityDate)}
            >
              {daysOff.includes(availabilityDate)
                ? "Reopen this day"
                : "Block this day off"}
            </button>
          </div>
          {daysOff.map((date: string) => (
            <div className="mx-resource-row" key={date}>
              <CalendarDays />
              <span>
                <b>{date}</b>
                <small>Unavailable for bookings</small>
              </span>
              <button
                className="mx-outline-button"
                onClick={() => toggleDayOff(date)}
              >
                Reopen
              </button>
            </div>
          ))}
        </section>
        <section className="mx-panel">
          <div className="mx-panel-head">
            <h2>Block a time slot</h2>
            <span>New bookings will be prevented.</span>
          </div>
          <div className="mx-availability-controls">
            <label>
              Date
              <input
                type="date"
                value={availabilityDate}
                onChange={(event: ChangeEvent<HTMLInputElement>) =>
                  setAvailabilityDate(event.target.value)
                }
              />
            </label>
            <label>
              Time
              <select
                value={availabilityTime}
                onChange={(event: ChangeEvent<HTMLSelectElement>) =>
                  setAvailabilityTime(event.target.value)
                }
              >
                {slots.map((time: string) => (
                  <option key={time}>{time}</option>
                ))}
              </select>
            </label>
            <button
              className="mx-outline-button"
              onClick={() =>
                toggleBlockedSlot(`${availabilityDate}|${availabilityTime}`)
              }
            >
              {blockedSlots.includes(`${availabilityDate}|${availabilityTime}`)
                ? "Reopen slot"
                : "Block slot"}
            </button>
          </div>
          {slots.map((time: string) => {
            const key = `${availabilityDate}|${time}`;
            const blocked = blockedSlots.includes(key);
            return (
              <button
                className={`mx-slot-toggle ${blocked ? "blocked" : ""}`}
                key={time}
                onClick={() => toggleBlockedSlot(key)}
              >
                {time}
                <small>
                  {blocked ? "Unavailable · reopen" : "Available · block slot"}
                </small>
              </button>
            );
          })}
        </section>
      </>
    );
  if (["Consultations", "My Patients"].includes(page) && role === "Doctor")
    return (
      <>
        <SectionHeading
          title={page}
          sub="Visit history and prescription handoffs for this assigned doctor."
        />
        <section className="mx-panel">
          <div className="mx-panel-head">
            <h2>Appointment queue</h2>
            <button
              className="mx-primary-button"
              onClick={() => openPrescription()}
            >
              Open visit / write prescription
            </button>
          </div>
          <AppointmentTable
            rows={appointments}
            role={role}
            action={setAppointmentStatus}
            openPrescription={openPrescription}
          />
        </section>
        <section className="mx-panel">
          <div className="mx-panel-head">
            <h2>Previous consultation history</h2>
            <span>Visible only in this doctor's local demo login.</span>
          </div>
          {allAppointments
            .filter(
              (item: Appointment) =>
                item.doctorId === props.doctorId && item.consultationNotes
            )
            .map((item: Appointment) => (
              <div className="mx-resource-row" key={item.id}>
                <FileText />
                <span>
                  <b>
                    {item.patient} · {dateText(item.date)}
                  </b>
                  <small>{item.consultationNotes}</small>
                  {item.followUpDate && (
                    <small>Follow-up: {item.followUpDate}</small>
                  )}
                </span>
                <button
                  className="mx-outline-button"
                  onClick={() => openPrescription(item.id)}
                >
                  History
                </button>
              </div>
            ))}
          {!allAppointments.some(
            (item: Appointment) =>
              item.doctorId === props.doctorId && item.consultationNotes
          ) && <Empty text="Completed demo consultations will appear here." />}
        </section>
      </>
    );
  if ([MV_PAGE, "Verify Medicine"].includes(page)) {
    if (role === "Patient" || role === "Doctor")
      return <MedicineVerifier mode={role === "Doctor" ? "doctor" : "patient"} />;
    return <Empty text="The Medicine Verifier is available to patients and doctors only." />;
  }
  if (
    [
      LAB_PAGE,
      "Lab Report Analyzer",
      "Report Simplifier",
      "AI Report Simplifier",
    ].includes(page)
  )
    return role === "Patient" ? (
      <LabReportAnalyzer />
    ) : (
      <Empty text="The AI Medical Report Analyzer is available in the patient portal only." />
    );
  if (
    [
      "Bed Management",
      "Hospital Resources",
      "Beds & Ambulance",
      "Ambulance",
      "Ambulance Requests",
    ].includes(page)
  )
    return (
      <>
        <SectionHeading
          title={page}
          sub="Resource counts below are browser-local reported values, not live capacity."
        />
        <section className="mx-panel">
          <div className="mx-resource-row">
            <BedDouble />
            <span>
              <b>General beds</b>
              <small>Availability</small>
            </span>
            <strong>{props.bedStatus || "36"} reported beds</strong>
          </div>
          <div className="mx-resource-row">
            <BedDouble />
            <span>
              <b>ICU beds</b>
              <small>Availability</small>
            </span>
            <strong>8 reported beds</strong>
          </div>
          <div className="mx-resource-row">
            <Ambulance />
            <span>
              <b>Ambulance enquiry</b>
              <small>No dispatch integration is configured</small>
            </span>
            <button
              className="mx-outline-button"
              onClick={() => notify("No live ambulance dispatch is connected.")}
            >
              Make enquiry
            </button>
          </div>
        </section>
      </>
    );
  if (page === "Staff" && role !== "Administrator")
    return <Empty text="This role does not have administrator access." />;
  return (
    <>
      <SectionHeading
        title={page}
        sub={`${role} workspace · Browser-local preview.`}
      />
      <section className="mx-panel">
        <div className="mx-empty">
          <ShieldCheck />
          <span>
            This page remains part of the existing MEDNEXUS preview. No live
            hospital data or external service is connected.
          </span>
        </div>
        <button
          className="mx-outline-button"
          onClick={() => navigate("Dashboard")}
        >
          Back to dashboard
        </button>
      </section>
    </>
  );
}

function SectionHeading({
  title,
  sub,
  action,
}: {
  title: string;
  sub: string;
  action?: ReactNode;
}) {
  return (
    <div className="mx-section-heading">
      <div>
        <div className="mx-eyebrow">MEDNEXUS AI · PREVIEW</div>
        <h1>{title}</h1>
        <p>{sub}</p>
      </div>
      {action}
    </div>
  );
}
