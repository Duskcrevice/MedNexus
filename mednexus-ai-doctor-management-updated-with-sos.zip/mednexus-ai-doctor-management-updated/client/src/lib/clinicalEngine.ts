export type BiologicalSex = "Female" | "Male";
export type MetricKey =
  | "hemoglobin"
  | "glucose"
  | "systolic"
  | "diastolic"
  | "spo2"
  | "ldl"
  | "triglycerides"
  | "creatinine"
  | "egfr"
  | "alt"
  | "ast";

export type Status = "normal" | "warning" | "critical" | "context";

export type ClinicalProfile = {
  name: string;
  age: number;
  sex: BiologicalSex;
  history: string;
  vitals: Record<MetricKey, number>;
};

export type ClinicalResult = {
  key: MetricKey;
  label: string;
  value: number;
  unit: string;
  status: Status;
  statusLabel: string;
  condition: string;
  shortTerm: string;
  longTerm: string;
  nextStep: string;
  system: string;
};

export type MetricDefinition = {
  key: MetricKey;
  label: string;
  simpleLabel: string;
  unit: string;
  min: number;
  max: number;
  step: number;
};

export const metricDefinitions: MetricDefinition[] = [
  {
    key: "hemoglobin",
    label: "Hemoglobin",
    simpleLabel: "Blood oxygen",
    unit: "g/dL",
    min: 5,
    max: 20,
    step: 0.1,
  },
  {
    key: "glucose",
    label: "Fasting glucose",
    simpleLabel: "Blood sugar",
    unit: "mg/dL",
    min: 40,
    max: 300,
    step: 1,
  },
  {
    key: "systolic",
    label: "Blood pressure · top",
    simpleLabel: "BP top number",
    unit: "mmHg",
    min: 70,
    max: 220,
    step: 1,
  },
  {
    key: "diastolic",
    label: "Blood pressure · bottom",
    simpleLabel: "BP bottom number",
    unit: "mmHg",
    min: 40,
    max: 140,
    step: 1,
  },
  {
    key: "spo2",
    label: "Oxygen saturation",
    simpleLabel: "Blood oxygen %",
    unit: "%",
    min: 80,
    max: 100,
    step: 1,
  },
  {
    key: "ldl",
    label: "LDL cholesterol",
    simpleLabel: "Bad cholesterol",
    unit: "mg/dL",
    min: 40,
    max: 260,
    step: 1,
  },
  {
    key: "triglycerides",
    label: "Triglycerides",
    simpleLabel: "Blood fats",
    unit: "mg/dL",
    min: 40,
    max: 700,
    step: 1,
  },
  {
    key: "creatinine",
    label: "Creatinine",
    simpleLabel: "Kidney waste",
    unit: "mg/dL",
    min: 0.3,
    max: 6,
    step: 0.1,
  },
  {
    key: "egfr",
    label: "eGFR",
    simpleLabel: "Kidney filtering",
    unit: "mL/min/1.73m²",
    min: 5,
    max: 130,
    step: 1,
  },
  {
    key: "alt",
    label: "ALT",
    simpleLabel: "Liver enzyme ALT",
    unit: "U/L",
    min: 5,
    max: 300,
    step: 1,
  },
  {
    key: "ast",
    label: "AST",
    simpleLabel: "Liver enzyme AST",
    unit: "U/L",
    min: 5,
    max: 300,
    step: 1,
  },
];

export const defaultProfile: ClinicalProfile = {
  name: "Patient",
  age: 35,
  sex: "Female",
  history: "No history entered",
  vitals: {
    hemoglobin: 10.2,
    glucose: 98,
    systolic: 118,
    diastolic: 76,
    spo2: 98,
    ldl: 92,
    triglycerides: 145,
    creatinine: 0.9,
    egfr: 95,
    alt: 24,
    ast: 22,
  },
};

const consequence = {
  hemoglobin: {
    system: "Blood oxygen",
    condition: "Possible anemia pattern",
    short:
      "Less oxygen may reach the body. Tiredness, weakness, pale skin, dizziness, or breathlessness can happen.",
    long: "If a low result continues, the cause should be checked. Untreated severe anemia can strain the heart and other organs.",
    next: "Arrange a clinician review. Seek urgent help for fainting, chest pain, severe breathlessness, or a very low result.",
  },
  glucoseLow: {
    system: "Energy balance",
    condition: "Low blood sugar pattern",
    short:
      "Shakiness, sweating, fast heartbeat, hunger, dizziness, confusion, or weakness can happen quickly.",
    long: "Repeated very low readings can become dangerous and need investigation by a doctor.",
    next: "Consume fast-acting sugar if conscious and safe. Seek immediate medical attention if unable to swallow or symptoms worsen.",
  },
  glucoseHigh: {
    system: "Metabolism",
    condition: "Elevated fasting glucose",
    short:
      "Increased thirst, frequent urination, fatigue, or blurred vision may be noticed over time.",
    long: "Persistent high blood sugar over months to years can affect blood vessels, eyes, kidneys, and nerves.",
    next: "Arrange clinician follow-up for repeat fasting or HbA1c testing. Seek prompt help for severe vomiting or breathlessness.",
  },
  bloodPressureLow: {
    system: "Circulation",
    condition: "Low blood pressure pattern",
    short:
      "Dizziness, weakness, blurred vision, or fainting can happen when organs receive less blood flow.",
    long: "The cause may include dehydration, medicines, bleeding, or illness and needs context.",
    next: "Sit or lie down safely and recheck. Seek urgent help for fainting, chest pain, confusion, or severe weakness.",
  },
  bloodPressureHigh: {
    system: "Circulation",
    condition: "High blood pressure pattern",
    short:
      "High blood pressure often has no symptoms, but it puts extra force on blood vessels.",
    long: "Over time it can raise the risk of stroke, heart disease, kidney disease, and blood-vessel damage.",
    next: "Repeat the reading correctly and arrange clinician follow-up. If it is over 180/120 with chest pain, breathlessness, weakness, vision change, or trouble speaking, seek emergency help.",
  },
  spo2: {
    system: "Breathing",
    condition: "Low oxygen reading",
    short:
      "Low oxygen can be linked with breathlessness, blue lips, fast breathing, tiredness, or confusion.",
    long: "Persistent low oxygen can affect the brain, heart, and other organs.",
    next: "Warm the hand, sit still, and repeat once. Seek urgent medical help for a persistent reading below 90% or severe breathing trouble.",
  },
  ldl: {
    system: "Heart and blood vessels",
    condition: "High LDL pattern",
    short:
      "High LDL usually has no immediate symptoms; it can contribute to plaque in arteries.",
    long: "Over time, plaque can raise the risk of heart attack, stroke, and circulation problems.",
    next: "Discuss the result and overall risk with a clinician. Do not start or stop medicine from this simulator.",
  },
  triglycerides: {
    system: "Heart and blood vessels",
    condition: "High triglyceride pattern",
    short: "High triglycerides often have no immediate symptoms.",
    long: "Very high levels can increase the risk of pancreatitis and may add to heart risk.",
    next: "Arrange clinician review, especially for very high results or severe upper-abdominal pain or vomiting.",
  },
  creatinine: {
    system: "Kidneys",
    condition: "Creatinine needs review",
    short:
      "A higher creatinine can mean the kidneys are clearing waste less efficiently, but one result is not enough to diagnose a condition.",
    long: "Persistent kidney problems can affect fluid balance, blood pressure, bones, and blood counts.",
    next: "Discuss repeat testing with a clinician; interpretation depends on age, sex, body size, medicines, and eGFR.",
  },
  egfr: {
    system: "Kidneys",
    condition: "Kidney filtering needs review",
    short: "A lower eGFR means the estimated kidney filtering rate is lower.",
    long: "Persistently low eGFR can be associated with chronic kidney disease and related complications.",
    next: "Arrange clinician review. An eGFR below 15 is an urgent medical finding that needs prompt care.",
  },
  alt: {
    system: "Liver",
    condition: "ALT enzyme elevation",
    short:
      "ALT can rise when liver cells are irritated or injured, but many causes are possible.",
    long: "Persistent elevation should be evaluated so the underlying cause is not missed.",
    next: "Discuss the result with a clinician and compare it with symptoms, medicines, alcohol use, and other liver tests.",
  },
  ast: {
    system: "Liver",
    condition: "AST enzyme elevation",
    short: "AST can rise from liver, muscle, heart, or other causes.",
    long: "Persistent elevation needs context and follow-up rather than a diagnosis from this number alone.",
    next: "Discuss the result with a clinician and compare it with ALT, symptoms, and other tests.",
  },
};

function adultContext(age: number): string | null {
  if (age < 18)
    return "Pediatric reference ranges differ. Ask a pediatric clinician to interpret this result.";
  if (age >= 65)
    return "Older-adult context matters. A clinician should interpret this with medicines and medical history.";
  return null;
}

function result(
  def: MetricDefinition,
  value: number,
  status: Status,
  statusLabel: string,
  detail: (typeof consequence)[keyof typeof consequence],
  context: string | null,
  conditionOverride?: string
): ClinicalResult {
  const normal = status === "normal";
  return {
    key: def.key,
    label: def.label,
    value,
    unit: def.unit,
    status: context ? "context" : status,
    statusLabel: context ? "Needs age context" : statusLabel,
    condition:
      context ||
      conditionOverride ||
      (normal ? "Within this guide range" : detail.condition),
    shortTerm:
      context ||
      (normal
        ? "No warning is raised by this educational screen. A normal result does not rule out every health problem."
        : detail.short),
    longTerm: context
      ? "Age-specific ranges are needed before making a clinical interpretation."
      : normal
        ? "Keep the report and discuss it with a clinician if you have symptoms or concerns."
        : detail.long,
    nextStep: context
      ? "Use the reference range on the report and ask a clinician."
      : normal
        ? "No urgent action is suggested by this screen. Follow your clinician's plan."
        : detail.next,
    system: detail.system,
  };
}

export function evaluateMetric(
  key: MetricKey,
  value: number,
  profile: ClinicalProfile
): ClinicalResult {
  const def = metricDefinitions.find(item => item.key === key)!;
  const context = adultContext(profile.age);

  if (key === "hemoglobin") {
    const low = profile.sex === "Female" ? 12 : 13.5;
    const severity =
      value < 8
        ? "Severe anemia pattern"
        : value < 10
          ? "Moderate anemia pattern"
          : value < low
            ? "Mild anemia pattern"
            : undefined;
    return result(
      def,
      value,
      value < 8 ? "critical" : value < low ? "warning" : "normal",
      value < 8 ? "Critical danger" : value < low ? "Warning" : "Looks usual",
      consequence.hemoglobin,
      context,
      severity
    );
  }
  if (key === "glucose") {
    return result(
      def,
      value,
      value < 54 || value >= 250
        ? "critical"
        : value < 70 || value >= 126
          ? "warning"
          : "normal",
      value < 54 || value >= 250
        ? "Critical danger"
        : value < 70 || value >= 126
          ? "Warning"
          : "Looks usual",
      value < 70 ? consequence.glucoseLow : consequence.glucoseHigh,
      context
    );
  }
  if (key === "systolic" || key === "diastolic") {
    const low = key === "systolic" ? value < 90 : value < 60;
    const high = key === "systolic" ? value >= 140 : value >= 90;
    const critical = key === "systolic" ? value > 180 : value > 120;
    return result(
      def,
      value,
      low || critical ? "critical" : high ? "warning" : "normal",
      low || critical ? "Critical danger" : high ? "Warning" : "Looks usual",
      low ? consequence.bloodPressureLow : consequence.bloodPressureHigh,
      context
    );
  }
  if (key === "spo2") {
    return result(
      def,
      value,
      value < 90 ? "critical" : value < 94 ? "warning" : "normal",
      value < 90 ? "Critical danger" : value < 94 ? "Warning" : "Looks usual",
      consequence.spo2,
      context
    );
  }
  if (key === "ldl") {
    return result(
      def,
      value,
      value >= 190 ? "critical" : value >= 100 ? "warning" : "normal",
      value >= 190
        ? "Critical danger"
        : value >= 100
          ? "Warning"
          : "Looks usual",
      consequence.ldl,
      context
    );
  }
  if (key === "triglycerides") {
    return result(
      def,
      value,
      value >= 500 ? "critical" : value >= 150 ? "warning" : "normal",
      value >= 500
        ? "Critical danger"
        : value >= 150
          ? "Warning"
          : "Looks usual",
      consequence.triglycerides,
      context
    );
  }
  if (key === "creatinine") {
    const high = profile.sex === "Female" ? 1.1 : 1.3;
    return result(
      def,
      value,
      value >= 3 ? "critical" : value > high ? "warning" : "normal",
      value >= 3 ? "Critical danger" : value > high ? "Warning" : "Looks usual",
      consequence.creatinine,
      context
    );
  }
  if (key === "egfr") {
    return result(
      def,
      value,
      value < 15 ? "critical" : value < 60 ? "warning" : "normal",
      value < 15 ? "Critical danger" : value < 60 ? "Warning" : "Looks usual",
      consequence.egfr,
      context
    );
  }
  if (key === "alt") {
    const high = profile.sex === "Female" ? 35 : 45;
    return result(
      def,
      value,
      value > 120 ? "critical" : value > high ? "warning" : "normal",
      value > 120
        ? "Critical danger"
        : value > high
          ? "Warning"
          : "Looks usual",
      consequence.alt,
      context
    );
  }
  const high = profile.sex === "Female" ? 35 : 40;
  return result(
    def,
    value,
    value > 120 ? "critical" : value > high ? "warning" : "normal",
    value > 120 ? "Critical danger" : value > high ? "Warning" : "Looks usual",
    consequence.ast,
    context
  );
}

export function evaluateProfile(profile: ClinicalProfile): ClinicalResult[] {
  return metricDefinitions.map(metric =>
    evaluateMetric(metric.key, profile.vitals[metric.key], profile)
  );
}
