import * as pdfjsLib from 'pdfjs-dist';

// Configure pdfjs worker using CDN matching the installed version or local worker
try {
  // @ts-ignore
  if (typeof window !== 'undefined' && pdfjsLib.GlobalWorkerOptions) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version || '4.10.38'}/pdf.worker.min.mjs`;
  }
} catch (e) {
  console.warn('Could not set pdf.js worker URL:', e);
}

export interface ExtractedDocument {
  fileName: string;
  mimeType: string;
  text: string;
  base64: string;
  pageCount: number;
}

/**
 * Extracts raw text and base64 representation from an uploaded PDF, text, or image file.
 */
export async function extractDocumentContent(file: File): Promise<ExtractedDocument> {
  const fileName = file.name;
  const mimeType = file.type || (fileName.endsWith('.pdf') ? 'application/pdf' : 'text/plain');

  // Convert file to base64
  const base64 = await fileToBase64(file);

  // If text or markdown file, read directly
  if (file.type.startsWith('text/') || fileName.endsWith('.txt') || fileName.endsWith('.csv')) {
    const text = await fileToText(file);
    return {
      fileName,
      mimeType: 'text/plain',
      text,
      base64,
      pageCount: 1,
    };
  }

  // If PDF, extract text across pages
  if (file.type === 'application/pdf' || fileName.toLowerCase().endsWith('.pdf')) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;
      const numPages = pdf.numPages;
      let fullText = '';

      for (let i = 1; i <= Math.min(numPages, 10); i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          // @ts-ignore
          .map((item) => (item && 'str' in item ? item.str : ''))
          .join(' ');
        fullText += `--- Page ${i} ---\n` + pageText + '\n\n';
      }

      return {
        fileName,
        mimeType: 'application/pdf',
        text: fullText.trim(),
        base64,
        pageCount: numPages,
      };
    } catch (pdfErr) {
      console.warn('pdf.js extraction failed, falling back to base64 only:', pdfErr);
      return {
        fileName,
        mimeType: 'application/pdf',
        text: '',
        base64,
        pageCount: 1,
      };
    }
  }

  // Image file (JPG/PNG) - base64 provided for Gemini multimodal OCR
  return {
    fileName,
    mimeType: file.type || 'image/jpeg',
    text: '',
    base64,
    pageCount: 1,
  };
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip data url prefix (e.g. data:application/pdf;base64,...)
      const base64Data = result.split(',')[1] || result;
      resolve(base64Data);
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

function fileToText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string) || '');
    reader.onerror = (err) => reject(err);
    reader.readAsText(file);
  });
}
