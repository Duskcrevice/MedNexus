export type DemoRole = "Patient" | "Doctor" | "Hospital Staff" | "Administrator";

export type DemoAccount = {
  id: string;
  email: string;
  displayName: string;
  role: DemoRole;
  salt: string;
  passwordHash: string;
  doctorId?: number;
};

export type DemoDoctor = {
  id: number;
  name: string;
  specialty: string;
  qualifications: string;
  experience: string;
  fee: number;
  photo: string;
  active: boolean;
  hours: string;
  email: string;
  daysOff: string[];
  blockedSlots: string[];
};

export type DemoAppointment = {
  id: number;
  patient: string;
  patientEmail: string;
  doctor: string;
  doctorId: number;
  specialty: string;
  date: string;
  time: string;
  type: "Online" | "In-Person";
  reason: string;
  status: "Confirmed" | "Pending" | "Completed";
  consultationNotes?: string;
  followUpDate?: string;
};

export type DemoPrescription = {
  id: number;
  appointmentId: number;
  patient: string;
  patientEmail: string;
  doctor: string;
  doctorId: number;
  date: string;
  notes: string;
  medicines: string[];
  status: string;
  followUpDate?: string;
};

export type DemoStore = {
  version: 1;
  accounts: DemoAccount[];
  doctors: DemoDoctor[];
  appointments: DemoAppointment[];
  prescriptions: DemoPrescription[];
  tasks: boolean[];
  bedStatus: string;
};

export type DemoSession = { email: string; role: DemoRole };

const STORE_KEY = "mednexus-hackathon-demo-v1";
const SESSION_KEY = "mednexus-hackathon-session-v1";
let memoryStore: DemoStore | null = null;
let memorySession: DemoSession | null = null;
let persistentStorage = true;
let writeFailed = false;

export const DEMO_LOGIN_HINTS: Record<Exclude<DemoRole, "Doctor">, { email: string; password: string }> = {
  Patient: { email: "patient@mednexus.demo", password: "PatientDemo!2026" },
  "Hospital Staff": { email: "staff@mednexus.demo", password: "StaffDemo!2026" },
  Administrator: { email: "vittikaadmin@medicarehospital.com", password: "12345678" },
};
export const DEMO_DOCTOR_LOGIN = { email: "doctor@medicarehospital.com", password: "DoctorDemo!2026" };

function safeStorage(): Storage | null {
  if (typeof window === "undefined") return null;
  try {
    const key = `${STORE_KEY}-probe`;
    window.localStorage.setItem(key, "1");
    window.localStorage.removeItem(key);
    persistentStorage = !writeFailed;
    return window.localStorage;
  } catch {
    persistentStorage = false;
    return null;
  }
}

export function demoPersistenceMode(): "localStorage" | "memory-only" {
  safeStorage();
  return persistentStorage && !writeFailed ? "localStorage" : "memory-only";
}

function randomHex(bytes = 16): string {
  const data = new Uint8Array(bytes);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) crypto.getRandomValues(data);
  else for (let i = 0; i < bytes; i++) data[i] = Math.floor(Math.random() * 256);
  return Array.from(data, n => n.toString(16).padStart(2, "0")).join("");
}

async function passwordHash(password: string, salt: string): Promise<string> {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${salt}:${password}`));
    return Array.from(new Uint8Array(digest), n => n.toString(16).padStart(2, "0")).join("");
  }
  // This fallback is for local-only demo access on browsers without Web Crypto.
  let value = 2166136261;
  for (const ch of `${salt}:${password}`) value = Math.imul(value ^ ch.charCodeAt(0), 16777619);
  return (value >>> 0).toString(16).padStart(8, "0");
}

function newId(): number {
  return Date.now() + Math.floor(Math.random() * 1000);
}

function readStored(): DemoStore | null {
  if (memoryStore) return memoryStore;
  const storage = safeStorage();
  if (!storage) return null;
  const raw = storage.getItem(STORE_KEY);
  if (!raw) return null;
  const parsed = JSON.parse(raw) as DemoStore;
  if (parsed.version !== 1 || !Array.isArray(parsed.accounts) || !Array.isArray(parsed.doctors) || !Array.isArray(parsed.appointments) || !Array.isArray(parsed.prescriptions)) {
    throw new Error("The local demo store is unreadable. Existing browser data was left untouched.");
  }
  return parsed;
}

export function persistDemoStore(store: DemoStore): DemoStore {
  memoryStore = store;
  const storage = safeStorage();
  if (storage) {
    try {
      storage.setItem(STORE_KEY, JSON.stringify(store));
      writeFailed = false;
      persistentStorage = true;
    } catch {
      writeFailed = true;
      persistentStorage = false;
    }
  }
  return store;
}

export async function ensureDemoStore(): Promise<DemoStore> {
  const existing = readStored();
  if (existing) {
    let next = existing;
    const adminHint = DEMO_LOGIN_HINTS.Administrator;
    const existingAdmin = next.accounts.find(account => account.role === "Administrator");
    if (!existingAdmin || existingAdmin.email !== adminHint.email) {
      const salt = randomHex();
      const admin: DemoAccount = {
        id: existingAdmin?.id || "seed-administrator",
        email: adminHint.email,
        displayName: "Administrator",
        role: "Administrator",
        salt,
        passwordHash: await passwordHash(adminHint.password, salt),
      };
      const accounts = next.accounts.filter(account => account.role !== "Administrator");
      next = { ...next, accounts: [...accounts, admin] };
    }
    if (!next.accounts.some(account => account.role === "Doctor") && !next.doctors.length) {
      const doctorId = 1001;
      const salt = randomHex();
      const doctor: DemoDoctor = {
        id: doctorId,
        name: "Dr. Demo Sharma",
        specialty: "Cardiology",
        qualifications: "MBBS, MD Cardiology",
        experience: "10 years",
        fee: 800,
        photo: "/doctor-portraits/elena-fernandez.jpg",
        active: true,
        hours: "09:00–17:00",
        email: DEMO_DOCTOR_LOGIN.email,
        daysOff: [],
        blockedSlots: [],
      };
      const account: DemoAccount = {
        id: "seed-doctor",
        email: DEMO_DOCTOR_LOGIN.email,
        displayName: doctor.name,
        role: "Doctor",
        salt,
        passwordHash: await passwordHash(DEMO_DOCTOR_LOGIN.password, salt),
        doctorId,
      };
      next = { ...next, accounts: [...next.accounts, account], doctors: [doctor] };
    }
    return next === existing ? existing : persistDemoStore(next);
  }
  const seeds = Object.entries(DEMO_LOGIN_HINTS) as [Exclude<DemoRole, "Doctor">, { email: string; password: string }][];
  const accounts: DemoAccount[] = await Promise.all(seeds.map(async ([role, credentials]) => {
    const salt = randomHex();
    return {
      id: `seed-${role.toLowerCase().replaceAll(" ", "-")}`,
      email: credentials.email,
      displayName: role === "Patient" ? "Demo Patient" : role === "Hospital Staff" ? "Demo Staff" : "Demo Administrator",
      role,
      salt,
      passwordHash: await passwordHash(credentials.password, salt),
    } satisfies DemoAccount;
  }));
  const doctorSalt = randomHex();
  const doctor: DemoDoctor = {
    id: 1001,
    name: "Dr. Demo Sharma",
    specialty: "Cardiology",
    qualifications: "MBBS, MD Cardiology",
    experience: "10 years",
    fee: 800,
    photo: "/doctor-portraits/elena-fernandez.jpg",
    active: true,
    hours: "09:00–17:00",
    email: DEMO_DOCTOR_LOGIN.email,
    daysOff: [],
    blockedSlots: [],
  };
  accounts.push({
    id: "seed-doctor",
    email: DEMO_DOCTOR_LOGIN.email,
    displayName: doctor.name,
    role: "Doctor",
    salt: doctorSalt,
    passwordHash: await passwordHash(DEMO_DOCTOR_LOGIN.password, doctorSalt),
    doctorId: doctor.id,
  });
  const created: DemoStore = {
    version: 1,
    accounts,
    doctors: [doctor],
    appointments: [],
    prescriptions: [],
    tasks: [false, false, false, false],
    bedStatus: "36",
  };
  return persistDemoStore(created);
}

export async function loginDemo(email: string, password: string, role: DemoRole): Promise<DemoAccount | null> {
  const store = await ensureDemoStore();
  const account = store.accounts.find(a => a.email.toLowerCase() === email.trim().toLowerCase() && a.role === role);
  if (!account || await passwordHash(password, account.salt) !== account.passwordHash) return null;
  if (role === "Doctor" && (!account.doctorId || !store.doctors.find(doctor => doctor.id === account.doctorId)?.active)) return null;
  const session: DemoSession = { email: account.email, role: account.role };
  memorySession = session;
  try { window.localStorage.setItem(SESSION_KEY, JSON.stringify(session)); } catch { persistentStorage = false; }
  return account;
}

export function getDemoSession(): DemoSession | null {
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as DemoSession;
    if (["Patient", "Doctor", "Hospital Staff", "Administrator"].includes(session.role) && typeof session.email === "string") return session;
  } catch {}
  return memorySession;
}

export async function getSessionAccount(): Promise<DemoAccount | null> {
  const session = getDemoSession();
  if (session) {
    const store = await ensureDemoStore();
    const account = store.accounts.find(account => account.email === session.email && account.role === session.role);
    if (account) return account;
  }
  try {
    const response = await fetch("/api/trpc/auth.me", { credentials: "include" });
    const responseText = await response.text();
    let payload: any = null;
    try { payload = responseText ? JSON.parse(responseText) : null; } catch { payload = null; }
    const user = payload?.result?.data?.json;
    if (user?.role === "admin" || user?.role === "doctor" || user?.role === "staff") {
      return {
        id: `server-${user.role}-${user.id}`,
        email: user.email,
        displayName: user.name || (user.role === "doctor" ? "Doctor" : user.role === "staff" ? "Hospital Staff" : "Administrator"),
        role: user.role === "admin" ? "Administrator" : user.role === "doctor" ? "Doctor" : "Hospital Staff",
        salt: "server",
        passwordHash: "server",
      };
    }
  } catch {}
  return null;
}

export function logoutDemo(): void {
  memorySession = null;
  try { window.localStorage.removeItem(SESSION_KEY); } catch {}
}

export function makeDemoPassword(): string {
  return `DemoDoc-${Math.floor(1000 + Math.random() * 9000)}!`;
}

export async function addDemoDoctor(
  base: DemoStore,
  input: Omit<DemoDoctor, "id" | "active" | "daysOff" | "blockedSlots"> & { password: string },
): Promise<{ store: DemoStore; doctor: DemoDoctor }> {
  const email = input.email.trim().toLowerCase();
  if (base.accounts.some(account => account.email.toLowerCase() === email)) throw new Error("That demo account email is already assigned.");
  const doctorId = newId();
  const salt = randomHex();
  const account: DemoAccount = {
    id: `doctor-${doctorId}`,
    email,
    displayName: input.name,
    role: "Doctor",
    salt,
    passwordHash: await passwordHash(input.password, salt),
    doctorId,
  };
  const doctor: DemoDoctor = {
    id: doctorId,
    name: input.name,
    specialty: input.specialty,
    qualifications: input.qualifications,
    experience: input.experience,
    fee: input.fee,
    photo: input.photo,
    active: true,
    hours: input.hours,
    email,
    daysOff: [],
    blockedSlots: [],
  };
  return { store: { ...base, accounts: [...base.accounts, account], doctors: [...base.doctors, doctor] }, doctor };
}

export async function addDemoStaff(
  base: DemoStore,
  input: { name: string; email: string; password: string },
): Promise<{ store: DemoStore; account: DemoAccount }> {
  const email = input.email.trim().toLowerCase();
  if (!input.name.trim() || !email || !input.password) throw new Error("Staff name, email and password are required.");
  if (base.accounts.some(account => account.email.toLowerCase() === email)) throw new Error("That demo account email is already assigned.");
  const salt = randomHex();
  const account: DemoAccount = {
    id: `staff-${newId()}`,
    email,
    displayName: input.name.trim(),
    role: "Hospital Staff",
    salt,
    passwordHash: await passwordHash(input.password, salt),
  };
  return { store: { ...base, accounts: [...base.accounts, account] }, account };
}

export function isDemoSlotBusy(store: DemoStore, doctorId: number, date: string, time: string): boolean {
  const doctor = store.doctors.find(item => item.id === doctorId);
  return !doctor || !doctor.active || doctor.daysOff.includes(date) || doctor.blockedSlots.includes(`${date}|${time}`) ||
    store.appointments.some(item => item.doctorId === doctorId && item.date === date && item.time === time);
}

export function defaultDoctorEmail(name: string): string {
  const slug = name.toLowerCase().replace(/^(dr\.?\s*)/, "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, ".").replace(/^\.|\.$/g, "") || "doctor";
  return `${slug}@medicarehospital.com`;
}
