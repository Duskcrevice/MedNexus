export type BiomarkerStatus = 'attention' | 'normal';
export type SeverityType = 'low' | 'normal' | 'high';

export interface Biomarker {
  name: string;
  plainName: string;
  value: number;
  valueDisplay: string;
  unit: string;
  refRange: string;
  minNormal: number;
  maxNormal: number;
  status: BiomarkerStatus;
  statusLabel: string;
  meaning: string;
  severity: SeverityType;
}

export interface DiagnosticSection {
  sectionName: string;
  originalText: string;
  simplifiedMeaning: string;
}

export interface ParsedLabReport {
  fileName: string;
  reportTitle: string;
  laboratory: string;
  date: string;
  patientName: string;
  summary: string;
  biomarkers: Biomarker[];
  diagnosticSections: DiagnosticSection[];
  doctorQuestions: string[];
  rawText?: string;
}

/**
 * Calculates the percentage position on a horizontal gauge:
 * [Low (0-25%) | Normal Reference Range (25-75%) | High (75-100%)]
 */
export function calculateGaugePosition(
  value: number,
  minNormal: number,
  maxNormal: number
): number {
  if (minNormal >= maxNormal || isNaN(value)) return 50;

  const normalSpan = maxNormal - minNormal;
  if (value < minNormal) {
    // Falls in low band (0% to 25%)
    const lowRatio = Math.max(0, (value - (minNormal - normalSpan * 0.8)) / (normalSpan * 0.8));
    return Math.max(5, Math.min(24, lowRatio * 25));
  } else if (value > maxNormal) {
    // Falls in high band (75% to 100%)
    const highRatio = Math.min(1, (value - maxNormal) / (normalSpan * 0.8));
    return Math.max(76, Math.min(95, 75 + highRatio * 25));
  } else {
    // Falls within normal band (25% to 75%)
    const normalRatio = (value - minNormal) / normalSpan;
    return Math.max(26, Math.min(74, 25 + normalRatio * 50));
  }
}
