import React from 'react';
import { calculateGaugePosition, type Biomarker } from '@/lib/reportTypes';

interface VisualRangeBarProps {
  biomarker: Biomarker;
}

export const VisualRangeBar: React.FC<VisualRangeBarProps> = ({ biomarker }) => {
  const { value, minNormal, maxNormal, unit, refRange, status, severity } = biomarker;
  const pinPosition = calculateGaugePosition(value, minNormal, maxNormal);

  const isLow = severity === 'low';
  const isHigh = severity === 'high';
  const isNormal = status === 'normal';

  const pinColor = isNormal ? 'bg-teal-600 text-teal-900 border-teal-700' : 'bg-amber-600 text-amber-900 border-amber-700';

  return (
    <div className="w-full mt-2 pt-1 pb-1">
      {/* Gauge Container */}
      <div className="relative pt-6 pb-2">
        {/* Pointer Pin / Tag floating above the bar */}
        <div
          className="absolute top-0 transform -translate-x-1/2 flex flex-col items-center transition-all duration-300 z-10"
          style={{ left: `${pinPosition}%` }}
        >
          <span
            className={`px-1.5 py-0.5 text-[10px] font-bold rounded-sm shadow-xs whitespace-nowrap ${
              isNormal
                ? 'bg-[#d6efe9] text-[#135f57] border border-[#a2d8cc]'
                : isLow
                ? 'bg-[#fae5dc] text-[#a84432] border border-[#f0c2b6]'
                : 'bg-[#fff1cb] text-[#96631b] border border-[#f4db96]'
            }`}
          >
            {value} {unit}
          </span>
          <span
            className={`w-0 h-0 border-x-4 border-x-transparent border-t-4 ${
              isNormal ? 'border-t-[#135f57]' : isLow ? 'border-t-[#a84432]' : 'border-t-[#96631b]'
            }`}
          />
        </div>

        {/* 3-Zone Track: Low | Normal | High */}
        <div className="h-3 w-full rounded-full overflow-hidden flex bg-[#eae6dc] p-0.5 border border-[#ded8cb]">
          {/* Low Band (0% to 25%) */}
          <div
            className={`w-1/4 h-full rounded-l-full flex items-center justify-center transition-colors ${
              isLow ? 'bg-[#f4cfc3]' : 'bg-[#f5e7e1]'
            }`}
            title="Below reference range"
          />

          {/* Normal Band (25% to 75% -> width 50%) */}
          <div
            className={`w-1/2 h-full flex items-center justify-center border-x border-[#cddfd9] transition-colors ${
              isNormal ? 'bg-[#bce6dc]' : 'bg-[#d4ede6]'
            }`}
            title={`Normal Reference Range: ${minNormal} – ${maxNormal} ${unit}`}
          />

          {/* High Band (75% to 100% -> width 25%) */}
          <div
            className={`w-1/4 h-full rounded-r-full flex items-center justify-center transition-colors ${
              isHigh ? 'bg-[#f7dfb3]' : 'bg-[#faeed8]'
            }`}
            title="Above reference range"
          />
        </div>

        {/* Pin marker line through the track */}
        <div
          className="absolute top-5 h-4 w-1 bg-[#1a332f] rounded-full transform -translate-x-1/2 shadow-xs"
          style={{ left: `${pinPosition}%` }}
        />
      </div>

      {/* Axis Labels Below Track */}
      <div className="flex justify-between items-center text-[10px] text-[#7d8882] font-medium px-1">
        <span className={isLow ? 'text-[#a84432] font-bold' : ''}>
          Low (&lt; {minNormal})
        </span>
        <span className={`text-center ${isNormal ? 'text-[#0f766e] font-bold' : ''}`}>
          Normal ({minNormal} – {maxNormal} {unit})
        </span>
        <span className={isHigh ? 'text-[#96631b] font-bold' : ''}>
          High (&gt; {maxNormal})
        </span>
      </div>
    </div>
  );
};
