import React from 'react';
import { FileText, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import type { DiagnosticSection } from '@/lib/reportTypes';

interface OriginalVsSimplifiedCardProps {
  sections: DiagnosticSection[];
}

export const OriginalVsSimplifiedCard: React.FC<OriginalVsSimplifiedCardProps> = ({ sections }) => {
  if (!sections || sections.length === 0) return null;

  return (
    <div className="bg-[#fcfbf8] border border-[#e5e1d8] rounded-xl shadow-xs overflow-hidden mt-5">
      <div className="px-5 py-4 bg-[#f4f2ec] border-b border-[#e5e1d8] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#0f766e] text-white flex items-center justify-center">
            <Sparkles size={14} />
          </div>
          <div>
            <h3 className="font-serif text-base font-normal text-[#22302f]">
              Diagnostic Impressions: Original vs. Plain-English
            </h3>
            <p className="text-xs text-[#75817a]">
              Translating complex diagnostic findings, pathology notes, and imaging language into plain English.
            </p>
          </div>
        </div>
        <span className="text-[10px] font-bold uppercase tracking-wider bg-[#e2ede8] text-[#135f57] px-2.5 py-1 rounded-full">
          Side-by-Side Clarity
        </span>
      </div>

      <div className="divide-y divide-[#ece7de]">
        {sections.map((section, idx) => (
          <div key={idx} className="p-5">
            {section.sectionName && (
              <div className="text-[11px] font-bold text-[#0f766e] uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <FileText size={13} />
                <span>Section: {section.sectionName}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Left Column: Original Medical Text */}
              <div className="bg-[#f8f6f0] border border-[#e5e0d3] rounded-lg p-3.5 flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#7e8781] bg-[#ece7dd] px-2 py-0.5 rounded">
                    Original Clinical Terminology
                  </span>
                  <span className="text-[10px] text-[#9ca59f]">Exact report wording</span>
                </div>
                <p className="text-xs font-mono text-[#33423d] leading-relaxed whitespace-pre-wrap bg-white/70 p-2.5 rounded border border-[#eae4d7] flex-1">
                  "{section.originalText}"
                </p>
              </div>

              {/* Right Column: Plain-English Meaning */}
              <div className="bg-[#f2faf7] border border-[#cbe5dc] rounded-lg p-3.5 flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#145d53] bg-[#d9efe7] px-2 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 size={11} />
                    Plain-English Meaning
                  </span>
                  <span className="text-[10px] text-[#2c776b]">Simplified for patient</span>
                </div>
                <p className="text-[13px] text-[#243f38] leading-relaxed bg-white/80 p-2.5 rounded border border-[#d5ece4] flex-1">
                  {section.simplifiedMeaning}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
