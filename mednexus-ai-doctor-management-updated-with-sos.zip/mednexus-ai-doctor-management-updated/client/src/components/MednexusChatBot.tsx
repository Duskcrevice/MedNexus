import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  Sparkles,
  Bot,
  User,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  Maximize2,
  Minimize2,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Stethoscope
} from 'lucide-react';
import type { ParsedLabReport } from '@/lib/reportTypes';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
}

interface MednexusChatBotProps {
  isOpen: boolean;
  onClose: () => void;
  uploadedReport: ParsedLabReport | null;
  patientName?: string;
  initialQuery?: string;
}

export const MednexusChatBot: React.FC<MednexusChatBotProps> = ({
  isOpen,
  onClose,
  uploadedReport,
  patientName = 'Patient',
  initialQuery
}) => {
  const attentionCount = uploadedReport?.biomarkers?.filter((b) => b.status === 'attention').length || 0;

  const getInitialGreeting = () => {
    if (!uploadedReport) {
      return `Hello ${patientName}, I am your **MEDNEXUS Clinical AI Assistant** powered by **MEDNEXUS AI**.

No laboratory or diagnostic report has been uploaded yet. 

You can upload a PDF or document using the dropzone on your dashboard, or ask me any general medical question about lab values, reference ranges, and symptoms!`;
    }

    const attentionList = uploadedReport.biomarkers
      ?.filter((b) => b.status === 'attention')
      .map((b) => `- **${b.name} (${b.plainName}):** ${b.valueDisplay || b.value} ${b.unit} *(Ref: ${b.refRange})* — ${b.statusLabel}`)
      .join('\n');

    return `Hello ${patientName}, I am your **MEDNEXUS Clinical AI Assistant** powered by **MEDNEXUS AI**.

I have analyzed your uploaded document: **${uploadedReport.fileName}**

${attentionCount > 0 ? `**Findings Requiring Attention (${attentionCount}):**\n${attentionList}\n` : '**All extracted biomarkers fall within normal reference ranges.**'}

How can I help you understand these findings or prepare questions for your doctor?`;
  };

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync greeting when report changes or on first mount
  useEffect(() => {
    setMessages([
      {
        id: 'welcome-' + (uploadedReport?.fileName || 'none'),
        role: 'assistant',
        content: getInitialGreeting(),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  }, [uploadedReport?.fileName]);

  // Handle triggered initial query (e.g. from clicking chip on main page)
  useEffect(() => {
    if (initialQuery && isOpen) {
      handleSendMessage(initialQuery);
    }
  }, [initialQuery, isOpen]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setTimeout(() => inputRef.current?.focus(), 200);
    } else {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        setSpeakingId(null);
      }
    }
  }, [isOpen]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    const userMessage: ChatMessage = {
      id: 'user-' + Date.now(),
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const historyForApi = messages
        .filter((m) => !m.id.startsWith('welcome'))
        .map((m) => ({
          role: m.role,
          content: m.content,
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: historyForApi,
          uploadedReportData: uploadedReport,
          patientContext: {
            name: patientName,
          },
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      const botResponse: ChatMessage = {
        id: 'bot-' + Date.now(),
        role: 'assistant',
        content: data.text || 'I could not generate a response. Please try rephrasing your question.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botResponse]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const fallbackResponse: ChatMessage = {
        id: 'bot-err-' + Date.now(),
        role: 'assistant',
        content: `### Clinical Explanation (Offline Assistance)

I encountered a network delay while contacting the MEDNEXUS AI service, but here is what I can tell you regarding your question:

If you are asking about abnormal or flagged values, the first recommended step is to confirm whether these represent a known personal baseline or a new change. 

**Recommended Action:**
Contact your primary physician's office to share your findings, especially if accompanied by symptoms such as persistent fatigue, chest discomfort, or dizziness.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackResponse]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (id: string, text: string) => {
    if (!window.speechSynthesis) return;

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text
      .replace(/[*#_`]/g, '')
      .replace(/\n+/g, '. ')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleResetChat = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
    }
    setMessages([
      {
        id: 'welcome-reset-' + Date.now(),
        role: 'assistant',
        content: getInitialGreeting(),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  const renderFormattedText = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      if (line.startsWith('### ')) {
        return (
          <h4 key={idx} className="text-sm font-bold text-[#1a332f] mt-2 mb-1">
            {line.replace('### ', '')}
          </h4>
        );
      }
      if (line.startsWith('## ')) {
        return (
          <h3 key={idx} className="text-base font-bold text-[#1a332f] mt-3 mb-1">
            {line.replace('## ', '')}
          </h3>
        );
      }
      if (line.startsWith('- ') || line.startsWith('* ')) {
        const itemText = line.substring(2);
        return (
          <li key={idx} className="ml-4 list-disc text-[13px] leading-relaxed text-[#2c3d38] mb-1">
            {renderBoldText(itemText)}
          </li>
        );
      }
      if (/^\d+\.\s/.test(line)) {
        return (
          <li key={idx} className="ml-4 list-decimal text-[13px] leading-relaxed text-[#2c3d38] mb-1">
            {renderBoldText(line.replace(/^\d+\.\s/, ''))}
          </li>
        );
      }
      if (line.trim() === '') {
        return <div key={idx} className="h-1.5" />;
      }
      return (
        <p key={idx} className="text-[13px] leading-relaxed text-[#2c3d38] mb-1.5">
          {renderBoldText(line)}
        </p>
      );
    });
  };

  const renderBoldText = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-[#14423b]">
            {part.slice(2, -2)}
          </strong>
        );
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return (
          <em key={i} className="italic text-[#465c55]">
            {part.slice(1, -1)}
          </em>
        );
      }
      return part;
    });
  };

  const dynamicChips = [
    "Why are my highlighted numbers out of range?",
    "What diet or lifestyle changes can help improve these results?",
    "Generate 3 specific questions for my next doctor visit",
    "हिंदी में समझाइए (Explain in Hindi)"
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-stretch justify-start bg-black/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} aria-hidden="true" />

      {/* Main Chat Drawer on the Left */}
      <div
        className={`relative z-10 flex flex-col bg-[#fbfaf6] text-[#22302f] border-r border-[#dcd7cb] shadow-2xl transition-all duration-300 ease-in-out h-full ${
          isExpanded ? 'w-full md:w-[740px]' : 'w-full sm:w-[490px] md:w-[530px]'
        }`}
      >
        {/* Top Header */}
        <header className="flex items-center justify-between px-4 py-3.5 bg-[#253d3b] text-white border-b border-[#36514e]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#0f766e] flex items-center justify-center text-white shadow-xs">
              <Sparkles size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif text-base font-medium tracking-tight text-white">
                  MEDNEXUS Clinical AI
                </h3>
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold tracking-wide bg-[#375e59] text-[#bbf0e4] px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#52d5b6] animate-pulse"></span>
                  MEDNEXUS AI
                </span>
              </div>
              <p className="text-[11px] text-[#b2c8c3]">
                Empathetic medical report simplification &amp; doctor dialogue coach
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 rounded-md text-[#b2c8c3] hover:text-white hover:bg-white/10 transition-colors"
              title={isExpanded ? 'Collapse' : 'Expand'}
              aria-label={isExpanded ? 'Collapse' : 'Expand'}
            >
              {isExpanded ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            </button>
            <button
              onClick={handleResetChat}
              className="p-1.5 rounded-md text-[#b2c8c3] hover:text-white hover:bg-white/10 transition-colors"
              title="Reset conversation"
              aria-label="Reset conversation"
            >
              <RotateCcw size={16} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md text-[#b2c8c3] hover:text-white hover:bg-white/10 transition-colors ml-1"
              title="Close chat"
              aria-label="Close chat"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Current Document Context Ribbon */}
        <div className="bg-[#eeece3] border-b border-[#ded9cb] px-4 py-2 flex items-center justify-between text-xs text-[#52605b]">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="inline-flex items-center gap-1 font-semibold text-[#18534b] shrink-0">
              <FileText size={13} />
              Active Doc:
            </span>
            <span className="truncate font-medium">
              {uploadedReport ? uploadedReport.fileName : 'None (Awaiting upload)'}
            </span>
          </div>

          {uploadedReport && attentionCount > 0 ? (
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#fae5dc] text-[#a84432] shrink-0 flex items-center gap-1">
              <AlertTriangle size={11} />
              {attentionCount} Flagged
            </span>
          ) : uploadedReport ? (
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#dff0e5] text-[#2d6e4d] shrink-0">
              All Normal
            </span>
          ) : (
            <span className="text-[10px] text-[#818a83] italic">
              Upload report to attach
            </span>
          )}
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-[#f8f6f0]">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="w-7 h-7 rounded-full bg-[#1b4e47] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  <Bot size={15} />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-xl px-3.5 py-3 shadow-xs ${
                  msg.role === 'user'
                    ? 'bg-[#1e433f] text-[#f7f9f8] rounded-tr-xs'
                    : 'bg-white text-[#22302f] border border-[#e2ddd1] rounded-tl-xs'
                }`}
              >
                {msg.role === 'assistant' ? (
                  <div>{renderFormattedText(msg.content)}</div>
                ) : (
                  <p className="text-[13px] leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                )}

                {msg.role === 'assistant' && (
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#ece7dc] text-[10px] text-[#828c86]">
                    <span>{msg.timestamp}</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopy(msg.id, msg.content)}
                        className="inline-flex items-center gap-1 p-1 hover:text-[#0f766e] transition-colors rounded hover:bg-[#eef5f2]"
                        title="Copy answer"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check size={12} className="text-emerald-600" />
                            <span className="text-emerald-700">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy size={12} />
                            <span>Copy</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => handleSpeak(msg.id, msg.content)}
                        className={`inline-flex items-center gap-1 p-1 transition-colors rounded hover:bg-[#eef5f2] ${
                          speakingId === msg.id ? 'text-[#0f766e] font-semibold' : 'hover:text-[#0f766e]'
                        }`}
                        title={speakingId === msg.id ? 'Stop reading' : 'Read aloud'}
                      >
                        {speakingId === msg.id ? (
                          <>
                            <VolumeX size={12} />
                            <span>Stop</span>
                          </>
                        ) : (
                          <>
                            <Volume2 size={12} />
                            <span>Listen</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded-full bg-[#48635c] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  <User size={14} />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-2.5 justify-start">
              <div className="w-7 h-7 rounded-full bg-[#1b4e47] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                <Bot size={15} />
              </div>
              <div className="bg-white border border-[#e2ddd1] rounded-xl rounded-tl-xs px-4 py-3 shadow-xs">
                <div className="flex items-center gap-2 text-xs text-[#5b6a64]">
                  <span className="flex space-x-1">
                    <span className="w-1.5 h-1.5 bg-[#0f766e] rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-1.5 h-1.5 bg-[#0f766e] rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-1.5 h-1.5 bg-[#0f766e] rounded-full animate-bounce"></span>
                  </span>
                  <span>MEDNEXUS AI is reviewing clinical standards...</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Doctor Question Generator Chips */}
        <div className="px-4 py-2.5 bg-[#f0eee6] border-t border-[#ded9cb]">
          <div className="text-[10px] font-bold tracking-wider text-[#79857e] uppercase mb-1.5 flex items-center gap-1">
            <Sparkles size={11} className="text-[#0f766e]" />
            One-Click Clinical Inquiries:
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            {dynamicChips.map((item, index) => (
              <button
                key={index}
                onClick={() => handleSendMessage(item)}
                disabled={isLoading}
                className="shrink-0 px-2.5 py-1 bg-white hover:bg-[#e4f1ed] text-[#2d4943] hover:text-[#0f766e] border border-[#d6d0c2] hover:border-[#9ecfc3] rounded-full text-[11px] transition-all disabled:opacity-50"
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        {/* Input Form */}
        <div className="p-3.5 bg-white border-t border-[#ded9cb]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask MEDNEXUS AI about your lab results, terms, or doctor visit..."
              disabled={isLoading}
              className="flex-1 bg-[#f8f6f0] border border-[#d5cebf] focus:border-[#0f766e] focus:bg-white text-xs text-[#22302f] rounded-lg px-3.5 py-2.5 outline-hidden transition-all placeholder:text-[#9ea69f]"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-[#0f766e] hover:bg-[#0c625c] text-white disabled:opacity-40 disabled:hover:bg-[#0f766e] transition-all shadow-xs shrink-0 cursor-pointer"
              aria-label="Send message"
            >
              <Send size={15} />
            </button>
          </form>

          {/* Clinical Safety Disclaimer */}
          <div className="flex items-center gap-1.5 mt-2 text-[10px] text-[#869089] justify-center text-center">
            <ShieldCheck size={12} className="text-[#0f766e] shrink-0" />
            <span>
              MEDNEXUS AI is an educational simplification tool. Not a medical diagnosis.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
