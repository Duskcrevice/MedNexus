import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import { createPortal } from "react-dom";
import {
  Activity,
  AlertTriangle,
  BedDouble,
  Check,
  CheckCircle2,
  Clock3,
  HeartPulse,
  LoaderCircle,
  Radio,
  ShieldAlert,
  Truck,
  Wind,
  X,
} from "lucide-react";
import "./emergency-sos.css";

type ShortageItem = "ICU Beds" | "Oxygen Cylinders" | "Blood Units" | "Ventilators";
type BroadcastStatus = "broadcasting" | "searching" | "offers_received" | "complete";
type WorkflowState = "selecting" | "submitting" | "tracking" | "error";

interface AidOffer {
  id: string;
  hospital: string;
  item: ShortageItem;
  quantity: number;
  unit: string;
  etaMinutes: number;
  status: string;
}

interface BroadcastSnapshot {
  broadcastId: string;
  status: BroadcastStatus;
  demoMode: boolean;
  offers: AidOffer[];
  message?: string;
  isFinal?: boolean;
}

interface EmergencySOSProps {
  /** Same-origin endpoint; replace with the network gateway path if needed. */
  endpoint?: string;
  /** Polling interval for incoming offers. Defaults to 2.5 seconds. */
  pollIntervalMs?: number;
}

const shortageOptions: Array<{
  value: ShortageItem;
  description: string;
  icon: typeof BedDouble;
}> = [
  { value: "ICU Beds", description: "Critical-care capacity", icon: BedDouble },
  { value: "Oxygen Cylinders", description: "Oxygen supply", icon: Wind },
  { value: "Blood Units", description: "Blood bank inventory", icon: HeartPulse },
  { value: "Ventilators", description: "Respiratory support", icon: Activity },
];

const statusLabel: Record<BroadcastStatus, string> = {
  broadcasting: "Sending to the network",
  searching: "Waiting for nearby hospitals",
  offers_received: "Aid offers received",
  complete: "Broadcast complete",
};

export default function EmergencySOS({
  endpoint = "/api/emergency/broadcast",
  pollIntervalMs = 2500,
}: EmergencySOSProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState<ShortageItem[]>([]);
  const [workflow, setWorkflow] = useState<WorkflowState>("selecting");
  const [snapshot, setSnapshot] = useState<BroadcastSnapshot | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const triggerRef = useRef<HTMLButtonElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const lastFocusedRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    lastFocusedRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const focusTimer = window.setTimeout(() => {
      dialogRef.current?.querySelector<HTMLElement>("button, input, [tabindex='0']")?.focus();
    }, 0);
    return () => window.clearTimeout(focusTimer);
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) return;
    if (lastFocusedRef.current && document.contains(lastFocusedRef.current)) {
      lastFocusedRef.current.focus();
    } else {
      triggerRef.current?.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    if (workflow !== "tracking" || !snapshot || snapshot.isFinal) return;
    let cancelled = false;
    const poll = async () => {
      try {
        const response = await fetch(`${endpoint}/${encodeURIComponent(snapshot.broadcastId)}`, {
          headers: { Accept: "application/json" },
          credentials: "same-origin",
        });
        if (!response.ok) throw new Error("Could not refresh the broadcast status.");
        const latest = (await response.json()) as BroadcastSnapshot;
        if (!cancelled) setSnapshot(latest);
      } catch {
        // Keep the last known status visible; the next interval retries automatically.
      }
    };
    const timer = window.setInterval(poll, pollIntervalMs);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [endpoint, pollIntervalMs, snapshot, workflow]);

  const toggleItem = (item: ShortageItem) => {
    setSelectedItems(current =>
      current.includes(item) ? current.filter(value => value !== item) : [...current, item],
    );
  };

  const resetAndOpen = () => {
    if (workflow === "tracking" && snapshot && !snapshot.isFinal) {
      setIsOpen(true);
      return;
    }
    setSelectedItems([]);
    setSnapshot(null);
    setErrorMessage("");
    setWorkflow("selecting");
    setIsOpen(true);
  };

  const submitBroadcast = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedItems.length || workflow === "submitting") return;
    setWorkflow("submitting");
    setErrorMessage("");
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ items: selectedItems }),
      });
      const result = (await response.json()) as BroadcastSnapshot & { error?: string };
      if (!response.ok) throw new Error(result.error || "The emergency broadcast could not be sent.");
      setSnapshot(result);
      setWorkflow("tracking");
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Unable to send the broadcast. Please try again.");
      setWorkflow("error");
    }
  };

  const closeModal = () => setIsOpen(false);

  const onDialogKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Escape") {
      event.stopPropagation();
      closeModal();
      return;
    }
    if (event.key !== "Tab" || !dialogRef.current) return;
    const focusable = dialogRef.current.querySelectorAll<HTMLElement>(
      "button:not(:disabled), input:not(:disabled), [tabindex='0']",
    );
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  const hasOffers = Boolean(snapshot?.offers.length);
  const status = snapshot?.status ?? "broadcasting";
  const showTracker = workflow === "tracking" && snapshot;

  return createPortal(
    <>
      <button
        ref={triggerRef}
        className="sos-trigger"
        type="button"
        onClick={resetAndOpen}
        aria-label="Open SOS emergency broadcast"
        aria-haspopup="dialog"
        aria-expanded={isOpen}
      >
        <span className="sos-trigger-label">SOS</span>
      </button>

      {isOpen && (
        <div className="sos-overlay" onMouseDown={event => event.target === event.currentTarget && closeModal()}>
          <div
            ref={dialogRef}
            className="sos-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="sos-dialog-title"
            aria-describedby="sos-dialog-description"
            tabIndex={-1}
            onKeyDown={onDialogKeyDown}
          >
            <header className="sos-dialog-header">
              <div className="sos-header-icon" aria-hidden="true"><ShieldAlert size={19} /></div>
              <div className="sos-heading-copy">
                <p className="sos-eyebrow">HOSPITAL RESOURCE ALERT</p>
                <h2 id="sos-dialog-title">Request emergency aid</h2>
              </div>
              <button className="sos-close" type="button" onClick={closeModal} aria-label="Close emergency broadcast">
                <X size={19} />
              </button>
            </header>

            <p id="sos-dialog-description" className="sos-dialog-description">
              Select critical low-stock items to alert nearby hospitals in your care network.
            </p>

            {workflow !== "tracking" || !snapshot ? (
              <form onSubmit={submitBroadcast}>
                <fieldset className="sos-options-fieldset" disabled={workflow === "submitting"}>
                  <legend>What does your hospital need?</legend>
                  <div className="sos-options-list">
                    {shortageOptions.map(({ value, description, icon: Icon }) => (
                      <label className={`sos-option${selectedItems.includes(value) ? " is-selected" : ""}`} key={value}>
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(value)}
                          onChange={() => toggleItem(value)}
                        />
                        <span className="sos-option-icon" aria-hidden="true"><Icon size={18} /></span>
                        <span className="sos-option-copy">
                          <span className="sos-option-title">{value}</span>
                          <span className="sos-option-description">{description}</span>
                        </span>
                        <span className="sos-checkmark" aria-hidden="true"><Check size={13} /></span>
                      </label>
                    ))}
                  </div>
                </fieldset>

                {workflow === "error" && (
                  <div className="sos-inline-error" role="alert">
                    <AlertTriangle size={16} />
                    <span>{errorMessage}</span>
                    <button className="sos-retry" type="button" onClick={() => setWorkflow("selecting")}>Retry</button>
                  </div>
                )}

                <div className="sos-privacy-note">
                  <Radio size={15} aria-hidden="true" />
                  <span>Only selected resource needs are shared with the hospital network.</span>
                </div>
                <button className="sos-submit" type="submit" disabled={!selectedItems.length || workflow === "submitting"}>
                  {workflow === "submitting" ? <LoaderCircle className="sos-spin" size={17} /> : <Radio size={17} />}
                  {workflow === "submitting" ? "Sending alert…" : "Broadcast shortage"}
                </button>
              </form>
            ) : (
              <section className="sos-tracker" aria-live="polite" aria-atomic="false">
                <div className="sos-tracker-topline">
                  <span className="sos-live-state">
                    {status === "complete" ? <CheckCircle2 size={15} /> : <span className="sos-live-dot" />}
                    {statusLabel[status]}
                  </span>
                  {snapshot.demoMode && <span className="sos-demo-badge">DEMO DATA</span>}
                </div>
                <div className="sos-progress-track">
                  <div className={`sos-progress-step is-done`}>
                    <span className="sos-step-icon"><Check size={12} /></span>
                    <span>Alert accepted</span>
                  </div>
                  <div className={`sos-progress-step${status !== "broadcasting" ? " is-done" : " is-current"}`}>
                    <span className="sos-step-icon">{status !== "broadcasting" ? <Check size={12} /> : <LoaderCircle className="sos-spin" size={12} />}</span>
                    <span>{snapshot.demoMode ? "Simulated network step" : "Network notified"}</span>
                  </div>
                  <div className={`sos-progress-step${hasOffers ? " is-done" : " is-current"}`}>
                    <span className="sos-step-icon">{hasOffers ? <Check size={12} /> : <Clock3 size={12} />}</span>
                    <span>Aid offers</span>
                  </div>
                </div>

                <div className="sos-request-summary">
                  <span className="sos-summary-label">REQUESTED RESOURCES</span>
                  <span className="sos-summary-items">{selectedItems.join(" · ")}</span>
                </div>

                <div className="sos-offers-heading">
                  <div>
                    <h3>Incoming aid</h3>
                    <p>{hasOffers ? `${snapshot.offers.length} hospital offer${snapshot.offers.length === 1 ? "" : "s"} received` : "Waiting for network responses"}</p>
                  </div>
                  {!snapshot.isFinal && <LoaderCircle className="sos-offer-loader sos-spin" size={18} aria-label="Checking for offers" />}
                </div>

                {hasOffers ? (
                  <div className="sos-offers-list">
                    {snapshot.offers.map(offer => (
                      <article className="sos-offer" key={offer.id}>
                        <span className="sos-offer-icon" aria-hidden="true"><Truck size={17} /></span>
                        <div className="sos-offer-main">
                          <div className="sos-offer-title-row">
                            <strong>{offer.hospital}</strong>
                            <span className="sos-offer-kind">{offer.status}</span>
                          </div>
                          <span>{offer.quantity} {offer.unit} · {offer.item}</span>
                        </div>
                        <span className="sos-offer-eta"><Clock3 size={13} /> {offer.etaMinutes} min</span>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="sos-waiting-card">
                    <LoaderCircle size={19} className="sos-spin" />
                    <div><strong>Alert is active</strong><span>Offers will appear here as hospitals respond.</span></div>
                  </div>
                )}
                {snapshot.message && <p className="sos-network-message">{snapshot.message}</p>}
                <button className="sos-done-button" type="button" onClick={closeModal}>
                  {snapshot.isFinal ? "Close tracker" : "Close — keep tracking"}
                </button>
              </section>
            )}
            <footer className="sos-dialog-footer">
              <HeartPulse size={14} aria-hidden="true" />
              <span>MEDNEXUS secure healthcare network</span>
            </footer>
          </div>
        </div>
      )}
    </>,
    document.body,
  );
}
