import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { mvMedicineReferences, mvPatientProfiles, mvPrescriptionMedicines, mvPrescriptions, mvVerificationFindings, mvVerificationReports } from "../../drizzle/schema";
import { getDb } from "../db";
import { canDoctorAccessPatient, getPatientDashboard, getPatientProfileForUser } from "./db";
import { lookupMedicine } from "./medicine";
import { runSafetyChecks } from "./verification";
import { generateGroundedExplanation } from "./explanation";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { sqliteSavePatientProfile } from "../localSqlite";

const medicineInput = z.object({
  medicineName: z.string().min(1),
  prescribedStrength: z.string().optional(),
  dosageForm: z.string().optional(),
  dose: z.string().optional(),
  frequency: z.string().optional(),
  duration: z.string().optional(),
  timing: z.string().optional(),
  instructions: z.string().optional(),
});

export const medicineVerifierRouter = router({
    dashboard: protectedProcedure.query(({ ctx }) => getPatientDashboard(ctx.user.id)),
    profile: router({
      upsert: protectedProcedure.input(z.object({
      displayName: z.string().min(1),
      dateOfBirth: z.string().optional(),
        bloodGroup: z.string().optional(),
        basicDetails: z.string().optional(),
        conditions: z.string().optional(),
        medicationAllergies: z.string().optional(),
        otherAllergies: z.string().optional(),
        currentMedications: z.string().optional(),
        medicalHistory: z.string().optional(),
        surgeries: z.string().optional(),
        notes: z.string().optional(),
      })).mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) {
          const missing = [input.conditions, input.medicationAllergies, input.currentMedications].filter(value => !value?.trim());
          sqliteSavePatientProfile({
            userId: ctx.user.id,
            openId: ctx.user.openId,
            displayName: input.displayName,
            bloodGroup: input.bloodGroup,
            basicDetails: input.basicDetails,
            conditions: input.conditions,
            medicationAllergies: input.medicationAllergies,
            currentMedications: input.currentMedications,
            surgeries: input.surgeries,
            ongoingConcerns: input.notes,
          });
          return { success: true, completeness: missing.length === 0 ? "complete" : "needs_review" };
        }
        const existing = await getPatientProfileForUser(ctx.user.id);
        const missing = [input.conditions, input.medicationAllergies, input.currentMedications].filter(value => !value?.trim());
        const completeness = missing.length === 0 ? "complete" : "needs_review";
        if (!existing) {
          await db.insert(mvPatientProfiles).values({ ...input, userId: ctx.user.id, completeness, profileVersion: 1 });
        } else {
          await db.update(mvPatientProfiles).set({ ...input, completeness, profileVersion: existing.profileVersion + 1, updatedAt: new Date() }).where(eq(mvPatientProfiles.id, existing.id));
          await db.update(mvVerificationReports).set({ isOutdated: 1 }).where(eq(mvVerificationReports.patientProfileId, existing.id));
        }
        return { success: true, completeness };
      }),
    }),
    prescriptions: router({
      create: protectedProcedure.input(z.object({ patientProfileId: z.number(), clinicianNote: z.string().optional(), medicines: z.array(medicineInput).min(1) })).mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is not available." });
        const ownProfile = await getPatientProfileForUser(ctx.user.id);
        const isPatient = ownProfile?.id === input.patientProfileId;
        const isAuthorizedDoctor = await canDoctorAccessPatient(ctx.user.id, input.patientProfileId);
        if (!isPatient && !isAuthorizedDoctor) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only the patient or an authorized care-team doctor can create this prescription." });
        }
        const inserted = await db.insert(mvPrescriptions).values({ patientProfileId: input.patientProfileId, doctorUserId: ctx.user.id, clinicianNote: input.clinicianNote ?? null });
        const prescriptionId = Number(inserted[0].insertId);
        for (const medicine of input.medicines) await db.insert(mvPrescriptionMedicines).values({ ...medicine, prescriptionId });
        return { prescriptionId };
      }),
    }),
    verification: router({
      reverify: protectedProcedure.input(z.object({ prescriptionId: z.number() })).mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is not available." });
        const prescriptionRows = await db.select().from(mvPrescriptions).where(eq(mvPrescriptions.id, input.prescriptionId)).limit(1);
        const prescription = prescriptionRows[0];
        if (!prescription) throw new TRPCError({ code: "NOT_FOUND", message: "Prescription not found." });
        const ownProfile = await getPatientProfileForUser(ctx.user.id);
        const isPatient = ownProfile?.id === prescription.patientProfileId;
        const isDoctor = prescription.doctorUserId === ctx.user.id || await canDoctorAccessPatient(ctx.user.id, prescription.patientProfileId);
        if (!isPatient && !isDoctor) throw new TRPCError({ code: "FORBIDDEN", message: "You are not authorized to verify this prescription." });
        const profileRows = await db.select().from(mvPatientProfiles).where(eq(mvPatientProfiles.id, prescription.patientProfileId)).limit(1);
        const profile = profileRows[0];
        if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Patient profile not found." });
        const medicines = await db.select().from(mvPrescriptionMedicines).where(eq(mvPrescriptionMedicines.prescriptionId, prescription.id));
        const references = new Map<number, any>();
        for (const medicine of medicines) {
          const lookup = await lookupMedicine(medicine.medicineName);
          if (lookup.status !== "verified") {
            references.set(medicine.id, null);
            continue;
          }
          const insertedReference = await db.insert(mvMedicineReferences).values({
            medicineName: medicine.medicineName,
            genericName: lookup.genericName ?? null,
            activeIngredients: lookup.activeIngredients ?? null,
            category: lookup.category ?? null,
            commonUses: lookup.commonUses ?? null,
            howItWorks: lookup.howItWorks ?? null,
            commonSideEffects: lookup.commonSideEffects ?? null,
            seriousSideEffects: lookup.seriousSideEffects ?? null,
            longTermPrecautions: lookup.longTermPrecautions ?? null,
            source: lookup.source,
            sourceRetrievedAt: lookup.retrievedAt,
            externalId: lookup.externalId ?? null,
            rawEvidence: lookup.rawEvidence ?? null,
          });
          references.set(medicine.id, { ...lookup, id: Number(insertedReference[0].insertId) });
        }
        const result = runSafetyChecks({ profile, medicines, references });
        const firstReference = references.get(medicines[0]?.id);
        const aiExplanation = medicines[0] && firstReference
          ? await generateGroundedExplanation({ medicineName: medicines[0].medicineName, purpose: firstReference.commonUses, findings: result.findings })
          : null;
        const previous = await db.select({ version: mvVerificationReports.reportVersion }).from(mvVerificationReports).where(eq(mvVerificationReports.prescriptionId, prescription.id)).orderBy(desc(mvVerificationReports.reportVersion)).limit(1);
        const nextVersion = (previous[0]?.version ?? 0) + 1;
        const missingInformation = result.findings.filter(item => item.severity === "grey").map(item => item.title).join("; ") || null;
        const insertedReport = await db.insert(mvVerificationReports).values({ prescriptionId: prescription.id, patientProfileId: profile.id, reportVersion: nextVersion, status: result.status, checksCompleted: result.checksCompleted, checksTotal: result.checksTotal, missingInformation, isOutdated: 0, aiExplanation });
        const reportId = Number(insertedReport[0].insertId);
        for (const finding of result.findings) await db.insert(mvVerificationFindings).values({ reportId, prescriptionMedicineId: finding.medicineId ?? null, findingType: finding.findingType, severity: finding.severity, title: finding.title, detail: finding.detail, evidenceSource: finding.evidenceSource ?? null, recommendedNextStep: finding.recommendedNextStep ?? null });
        return { reportId, version: nextVersion, status: result.status, checksCompleted: result.checksCompleted, checksTotal: result.checksTotal };
      }),
      acknowledge: protectedProcedure.input(z.object({ findingId: z.number() })).mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is not available." });
        const rows = await db.select().from(mvVerificationFindings).where(eq(mvVerificationFindings.id, input.findingId)).limit(1);
        const finding = rows[0];
        if (!finding) throw new TRPCError({ code: "NOT_FOUND", message: "Finding not found." });
        const reportRows = await db.select().from(mvVerificationReports).where(eq(mvVerificationReports.id, finding.reportId)).limit(1);
        const report = reportRows[0];
        if (!report) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
        const patient = await getPatientProfileForUser(ctx.user.id);
        const authorized = patient?.id === report.patientProfileId;
        if (!authorized) {
          const prescriptionRows = await db.select().from(mvPrescriptions).where(eq(mvPrescriptions.id, report.prescriptionId)).limit(1);
          const prescription = prescriptionRows[0];
          if (!prescription || prescription.doctorUserId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "Only the patient or authorized prescribing doctor can acknowledge this finding." });
        }
        await db.update(mvVerificationFindings).set({ acknowledgedAt: new Date(), acknowledgedBy: ctx.user.id }).where(eq(mvVerificationFindings.id, finding.id));
        return { success: true };
      }),
    }),
    doctor: router({
      reports: protectedProcedure.query(async ({ ctx }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database is not available." });
        const rows = await db.select().from(mvPrescriptions).orderBy(desc(mvPrescriptions.updatedAt));
        const result = [];
        for (const prescription of rows) {
          if (prescription.doctorUserId !== ctx.user.id && !(await canDoctorAccessPatient(ctx.user.id, prescription.patientProfileId))) continue;
          const profile = (await db.select().from(mvPatientProfiles).where(eq(mvPatientProfiles.id, prescription.patientProfileId)).limit(1))[0];
          const report = (await db.select().from(mvVerificationReports).where(eq(mvVerificationReports.prescriptionId, prescription.id)).orderBy(desc(mvVerificationReports.reportVersion)).limit(1))[0];
          const findings = report ? await db.select().from(mvVerificationFindings).where(eq(mvVerificationFindings.reportId, report.id)) : [];
          result.push({ prescription, profile, report: report ? { ...report, findings } : null });
        }
        return result;
      }),
    }),
  });
