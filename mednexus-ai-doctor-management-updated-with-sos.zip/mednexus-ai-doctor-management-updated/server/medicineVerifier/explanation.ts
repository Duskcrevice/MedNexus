type ExplanationInput = {
  medicineName: string;
  purpose?: string | null;
  findings: Array<{ severity: string; title: string; detail: string }>;
};

export async function generateGroundedExplanation(input: ExplanationInput): Promise<string | null> {
  const baseUrl = process.env.MANUS_API_URL;
  const apiKey = process.env.MANUS_API_KEY;
  if (!baseUrl || !apiKey) return null;

  const evidence = input.findings.map(item => `[${item.severity}] ${item.title}: ${item.detail}`).join("\n");
  const prompt = [
    "Write a short patient-friendly medicine verification explanation.",
    "Use only the supplied medicine reference and findings. Do not diagnose, prescribe, say the medicine is safe, or invent missing facts.",
    "Mention that the patient should discuss warnings with the prescribing doctor or pharmacist.",
    "Return three labeled paragraphs: English, Hindi, Hinglish.",
    `Medicine: ${input.medicineName}`,
    `Verified purpose: ${input.purpose || "Not available"}`,
    `Findings:\n${evidence}`,
  ].join("\n\n");

  try {
    const response = await fetch(`${baseUrl}/v1/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: "You are a safety-support explanation layer. Be accurate, calm, and explicit about uncertainty." },
          { role: "user", content: prompt },
        ],
      }),
    });
    if (!response.ok) return null;
    const body = await response.json() as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } };
    const content = body.choices?.[0]?.message?.content?.trim();
    return content || null;
  } catch {
    return null;
  }
}
