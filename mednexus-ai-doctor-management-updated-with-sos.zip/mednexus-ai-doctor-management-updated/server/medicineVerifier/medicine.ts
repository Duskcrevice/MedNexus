export type MedicineLookup = {
  status: "verified" | "not_found" | "unavailable";
  source: string;
  retrievedAt: Date;
  externalId?: string;
  genericName?: string;
  activeIngredients?: string;
  category?: string;
  commonUses?: string;
  howItWorks?: string;
  commonSideEffects?: string;
  seriousSideEffects?: string;
  longTermPrecautions?: string;
  rawEvidence?: string;
  error?: string;
};

const RXNORM_URL = "https://rxnav.nlm.nih.gov/REST";

async function readJson(url: string) {
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`RxNorm returned ${response.status}`);
  return response.json() as Promise<Record<string, any>>;
}

/**
 * Resolves identity only. RxNorm is deliberately not treated as a clinical
 * safety oracle; downstream checks remain incomplete until fields are present.
 */
export async function lookupMedicine(medicineName: string): Promise<MedicineLookup> {
  const retrievedAt = new Date();
  try {
    const name = encodeURIComponent(medicineName.trim());
    const rxcuiResponse = await readJson(`${RXNORM_URL}/rxcui.json?name=${name}`);
    const rxcui = rxcuiResponse.idGroup?.rxnormId?.[0] as string | undefined;

    if (!rxcui) {
      return {
        status: "not_found",
        source: "NIH RxNorm / RxNav",
        retrievedAt,
        error: "The medicine name was not resolved by RxNorm.",
      };
    }

    const properties = await readJson(`${RXNORM_URL}/rxcui/${rxcui}/properties.json`);
    const concept = properties.properties ?? {};

    return {
      status: "verified",
      source: "NIH RxNorm / RxNav",
      retrievedAt,
      externalId: rxcui,
      genericName: typeof concept.name === "string" ? concept.name : medicineName,
      // Do not infer ingredients from a brand or product name. A later
      // clinical source can fill this field before allergy matching is green.
      rawEvidence: JSON.stringify({ rxcui, properties: concept }),
    };
  } catch (error) {
    return {
      status: "unavailable",
      source: "NIH RxNorm / RxNav",
      retrievedAt,
      error: error instanceof Error ? error.message : "Reference service unavailable.",
    };
  }
}
