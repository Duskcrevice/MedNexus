import { and, desc, eq } from "drizzle-orm";
import { mvCareTeamAccess, mvPatientProfiles, mvPrescriptionMedicines, mvPrescriptions, mvVerificationFindings, mvVerificationReports } from "../../drizzle/schema";
import { getDb } from "../db";
import { sqliteGetPatientProfileByUserId } from "../localSqlite";

export async function getPatientProfileForUser(userId: number) {
  const db = await getDb();
  if (!db) return sqliteGetPatientProfileByUserId(userId) as any;
  const result = await db.select().from(mvPatientProfiles).where(eq(mvPatientProfiles.userId, userId)).limit(1);
  return result[0];
}

export async function getPatientDashboard(userId: number) {
  const db = await getDb();
  if (!db) {
    const profile = await getPatientProfileForUser(userId);
    return { profile: profile ?? null, prescriptions: [] };
  }
  const profile = await getPatientProfileForUser(userId);
  if (!profile) return { profile: null, prescriptions: [] };

  const prescriptionRows = await db
    .select()
    .from(mvPrescriptions)
    .where(eq(mvPrescriptions.patientProfileId, profile.id))
    .orderBy(desc(mvPrescriptions.updatedAt));

  const result = [];
  for (const prescription of prescriptionRows) {
    const medicines = await db
      .select()
      .from(mvPrescriptionMedicines)
      .where(eq(mvPrescriptionMedicines.prescriptionId, prescription.id));
    const reportRows = await db
      .select()
      .from(mvVerificationReports)
      .where(eq(mvVerificationReports.prescriptionId, prescription.id))
      .orderBy(desc(mvVerificationReports.reportVersion))
      .limit(1);
    const report = reportRows[0];
    const findings = report
      ? await db.select().from(mvVerificationFindings).where(eq(mvVerificationFindings.reportId, report.id))
      : [];
    result.push({ prescription, medicines, report: report ? { ...report, findings } : null });
  }
  return { profile, prescriptions: result };
}

export async function canDoctorAccessPatient(doctorUserId: number, patientProfileId: number) {
  const db = await getDb();
  if (!db) return false;
  const access = await db
    .select()
    .from(mvCareTeamAccess)
    .where(and(eq(mvCareTeamAccess.doctorUserId, doctorUserId), eq(mvCareTeamAccess.patientProfileId, patientProfileId), eq(mvCareTeamAccess.status, "active")))
    .limit(1);
  return access.length > 0;
}
