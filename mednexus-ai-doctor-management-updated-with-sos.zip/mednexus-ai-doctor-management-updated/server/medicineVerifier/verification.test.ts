import { describe, expect, it } from "vitest";
import { runSafetyChecks } from "./verification";

const medicine = { id: 1, medicineName: "Amoxicillin", prescribedStrength: "500 mg" };
const verifiedReference = { source: "NIH RxNorm / RxNav", genericName: "amoxicillin", activeIngredients: "amoxicillin", category: "antibiotic" };

describe("MEDNEXUS verification semantics", () => {
  it("flags an ingredient match as red and explains the reason", () => {
    const result = runSafetyChecks({
      profile: { medicationAllergies: "penicillin, amoxicillin", conditions: "asthma", currentMedications: "salbutamol" },
      medicines: [medicine],
      references: new Map([[1, verifiedReference]]),
    });
    const finding = result.findings.find(item => item.findingType === "allergy");
    expect(result.status).toBe("red");
    expect(finding?.severity).toBe("red");
    expect(finding?.detail).toContain("amoxicillin");
  });

  it("does not treat missing profile fields as a green safety result", () => {
    const result = runSafetyChecks({
      profile: { medicationAllergies: "", conditions: "", currentMedications: "" },
      medicines: [medicine],
      references: new Map([[1, verifiedReference]]),
    });
    expect(result.status).toBe("grey");
    expect(result.findings.filter(item => item.severity === "grey").length).toBeGreaterThan(0);
  });

  it("flags the documented interaction pair for clinician review", () => {
    const result = runSafetyChecks({
      profile: { medicationAllergies: "none recorded", conditions: "hypertension", currentMedications: "warfarin" },
      medicines: [{ ...medicine, medicineName: "ibuprofen" }],
      references: new Map([[1, { ...verifiedReference, genericName: "ibuprofen", activeIngredients: "ibuprofen" }]]),
    });
    const finding = result.findings.find(item => item.findingType === "interaction");
    expect(finding?.severity).toBe("yellow");
    expect(finding?.recommendedNextStep).toContain("pharmacist");
  });

  it("returns grey when the reference lookup is unavailable", () => {
    const result = runSafetyChecks({
      profile: { medicationAllergies: "penicillin", conditions: "asthma", currentMedications: "salbutamol" },
      medicines: [medicine],
      references: new Map([[1, null]]),
    });
    expect(result.status).toBe("grey");
    expect(result.findings[0].title).toBe("Medicine information could not be verified.");
  });
});
