export type VerificationSeverity = "green" | "yellow" | "red" | "grey";

export type VerificationProfile = {
  conditions?: string | null;
  medicationAllergies?: string | null;
  currentMedications?: string | null;
};

export type VerificationMedicine = {
  id: number;
  medicineName: string;
  prescribedStrength?: string | null;
  dose?: string | null;
  frequency?: string | null;
  duration?: string | null;
  timing?: string | null;
};

export type VerificationReference = {
  id?: number;
  medicineName?: string | null;
  genericName?: string | null;
  activeIngredients?: string | null;
  category?: string | null;
  commonUses?: string | null;
  howItWorks?: string | null;
  commonSideEffects?: string | null;
  seriousSideEffects?: string | null;
  longTermPrecautions?: string | null;
  source?: string | null;
  sourceRetrievedAt?: Date | null;
};

export type VerificationFinding = {
  medicineId?: number;
  findingType: "medicine" | "allergy" | "condition" | "interaction" | "information";
  severity: VerificationSeverity;
  title: string;
  detail: string;
  evidenceSource?: string;
  recommendedNextStep?: string;
};

function list(value?: string | null) {
  return (value ?? "")
    .split(/[,;\n]/)
    .map(item => item.trim().toLowerCase())
    .filter(Boolean);
}

function containsTerm(text: string, term: string) {
  return text.toLowerCase().includes(term.toLowerCase());
}

const documentedInteractions: Array<{ one: string; two: string; detail: string }> = [
  {
    one: "warfarin",
    two: "ibuprofen",
    detail: "NSAIDs such as ibuprofen can increase bleeding risk when combined with warfarin; the combination needs clinician or pharmacist review.",
  },
  {
    one: "simvastatin",
    two: "clarithromycin",
    detail: "Clarithromycin can increase simvastatin exposure and the risk of muscle toxicity; the combination needs clinician or pharmacist review.",
  },
  {
    one: "sertraline",
    two: "tramadol",
    detail: "Both medicines can contribute to serotonin toxicity; a prescriber or pharmacist should review the combination.",
  },
];

export function runSafetyChecks(input: {
  profile: VerificationProfile;
  medicines: VerificationMedicine[];
  references: Map<number, VerificationReference | null>;
}) {
  const findings: VerificationFinding[] = [];
  const allergies = list(input.profile.medicationAllergies);
  const conditions = list(input.profile.conditions);
  const currentMeds = list(input.profile.currentMedications);
  const medicinesWithNames = input.medicines.map(medicine => ({
    medicine,
    searchable: `${medicine.medicineName} ${medicine.prescribedStrength ?? ""}`.toLowerCase(),
  }));

  for (const { medicine, searchable } of medicinesWithNames) {
    const reference = input.references.get(medicine.id);
    if (!reference) {
      findings.push({
        medicineId: medicine.id,
        findingType: "medicine",
        severity: "grey",
        title: "Medicine information could not be verified.",
        detail: "The medicine reference service did not return a usable identity record, so personalized checks for this medicine are incomplete.",
        evidenceSource: "NIH RxNorm / RxNav",
        recommendedNextStep: "Confirm the medicine name and strength with the prescribing doctor or pharmacist, then retry verification.",
      });
      continue;
    }

    findings.push({
      medicineId: medicine.id,
      findingType: "medicine",
      severity: "green",
      title: "Medicine identity retrieved",
      detail: `Identity was resolved from ${reference.source ?? "the configured medicine reference"}. This is not a complete safety conclusion.`,
      evidenceSource: reference.source ?? undefined,
      recommendedNextStep: "Review the remaining personalized checks below.",
    });

    const ingredientText = `${reference.activeIngredients ?? ""} ${reference.genericName ?? ""} ${searchable}`.trim();
    if (!allergies.length) {
      findings.push({
        medicineId: medicine.id,
        findingType: "allergy",
        severity: "grey",
        title: "Medication allergy information is missing",
        detail: "No medication allergy is recorded. That is not evidence that an allergy is absent, so an ingredient match could not be completed.",
        recommendedNextStep: "Confirm medication allergies with the patient and add them to the health profile.",
      });
    } else if (!reference.activeIngredients) {
      findings.push({
        medicineId: medicine.id,
        findingType: "allergy",
        severity: "grey",
        title: "Ingredient-level allergy match is incomplete",
        detail: "Allergy information is present, but the reference record did not provide active ingredients for a reliable comparison.",
        evidenceSource: reference.source ?? undefined,
        recommendedNextStep: "Ask a pharmacist to confirm the active ingredients before relying on this check.",
      });
    } else {
      const match = allergies.find(allergy => containsTerm(ingredientText, allergy));
      findings.push({
        medicineId: medicine.id,
        findingType: "allergy",
        severity: match ? "red" : "green",
        title: match ? "Recorded allergy may match an active ingredient" : "No recorded ingredient match found",
        detail: match
          ? `The profile records an allergy to “${match}”, which appears in the retrieved medicine identity. This requires prompt clinical review.`
          : "No recorded medication allergy matched the retrieved active ingredient text. This does not mean the medicine is completely safe.",
        evidenceSource: reference.source ?? undefined,
        recommendedNextStep: "Do not independently stop or change treatment; discuss this finding with the prescribing doctor or pharmacist.",
      });
    }

    if (!conditions.length) {
      findings.push({
        medicineId: medicine.id,
        findingType: "condition",
        severity: "grey",
        title: "Condition check is incomplete",
        detail: "No medical conditions are recorded, so condition-specific precautions could not be evaluated. No condition has been inferred from the medicine.",
        recommendedNextStep: "Confirm relevant medical conditions, including kidney, liver, heart, and pregnancy information where applicable.",
      });
    } else if (!reference.category) {
      findings.push({
        medicineId: medicine.id,
        findingType: "condition",
        severity: "grey",
        title: "Condition check needs a clinical reference",
        detail: "The medicine identity was found, but the configured reference did not provide enough clinical category information for an evidence-supported condition check.",
        evidenceSource: reference.source ?? undefined,
        recommendedNextStep: "Ask a pharmacist or clinician to review condition-specific precautions.",
      });
    } else {
      findings.push({
        medicineId: medicine.id,
        findingType: "condition",
        severity: "green",
        title: "No documented condition flag in the configured check",
        detail: `The available profile conditions were checked against the retrieved ${reference.category} reference. This is not a complete safety conclusion.`,
        evidenceSource: reference.source ?? undefined,
      });
    }
  }

  if (!currentMeds.length) {
    findings.push({
      findingType: "interaction",
      severity: "grey",
      title: "Current medication list is missing",
      detail: "Drug-drug interaction checking could not compare the prescription against current medicines.",
      recommendedNextStep: "Add all current prescription medicines, over-the-counter medicines, and supplements to the health profile.",
    });
  } else {
    let matched = false;
    for (const current of currentMeds) {
      for (const { medicine } of medicinesWithNames) {
        const pair = documentedInteractions.find(item =>
          (containsTerm(current, item.one) && containsTerm(medicine.medicineName, item.two)) ||
          (containsTerm(current, item.two) && containsTerm(medicine.medicineName, item.one)),
        );
        if (pair) {
          matched = true;
          findings.push({
            medicineId: medicine.id,
            findingType: "interaction",
            severity: "yellow",
            title: `Potential interaction: ${medicine.medicineName} + ${current}`,
            detail: pair.detail,
            evidenceSource: "Configured interaction reference",
            recommendedNextStep: "Ask the prescribing doctor or pharmacist to review the combination; do not independently stop either medicine.",
          });
        }
      }
    }
    if (!matched) {
      findings.push({
        findingType: "interaction",
        severity: "green",
        title: "No configured interaction match found",
        detail: "The recorded current medicines were compared with the configured interaction reference. This is not a complete interaction guarantee.",
        evidenceSource: "Configured interaction reference",
      });
    }
  }

  const hasRed = findings.some(finding => finding.severity === "red");
  const hasYellow = findings.some(finding => finding.severity === "yellow");
  const hasGrey = findings.some(finding => finding.severity === "grey");
  const status: VerificationSeverity = hasRed ? "red" : hasYellow ? "yellow" : hasGrey ? "grey" : "green";
  const checksTotal = findings.length;
  const checksCompleted = findings.filter(finding => finding.severity !== "grey").length;

  return { findings, status, checksCompleted, checksTotal };
}
