import express from "express";
import type { AddressInfo } from "node:net";
import type { Server } from "node:http";
import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { emergencyRouter } from "./emergency";

let server: Server;
let baseUrl: string;

beforeAll(async () => {
  const app = express();
  app.use(express.json());
  app.use("/api/emergency", emergencyRouter);
  server = await new Promise<Server>(resolve => {
    const listening = app.listen(0, "127.0.0.1", () => resolve(listening));
  });
  const { port } = server.address() as AddressInfo;
  baseUrl = `http://127.0.0.1:${port}/api/emergency`;
});

afterAll(async () => {
  await new Promise<void>(resolve => server.close(() => resolve()));
});

beforeEach(() => {
  // Force demo mode unless a test opts into the live adapter.
  delete process.env.EMERGENCY_NETWORK_API_URL;
  delete process.env.EMERGENCY_NETWORK_API_TOKEN;
});

async function post(body: unknown) {
  return fetch(`${baseUrl}/broadcast`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("SOS broadcast router (demo mode)", () => {
  it("accepts a valid shortage and labels the response as demo data", async () => {
    const response = await post({ items: ["Oxygen Cylinders", "Blood Units"] });
    expect(response.status).toBe(202);
    const body = (await response.json()) as {
      broadcastId: string;
      status: string;
      demoMode: boolean;
      offers: unknown[];
      message: string;
    };
    expect(body.demoMode).toBe(true);
    expect(body.status).toBe("broadcasting");
    expect(body.broadcastId).toMatch(/^[0-9a-f-]{36}$/);
    expect(body.offers).toEqual([]);
    expect(body.message).toMatch(/not sent to real hospitals/i);
  });

  it("de-duplicates repeated items and drops unknown ones", async () => {
    const response = await post({ items: ["ICU Beds", "ICU Beds", "Unknown thing"] });
    expect(response.status).toBe(202);
  });

  it("rejects a request with no valid shortage items", async () => {
    const response = await post({ items: ["Not a resource"] });
    expect(response.status).toBe(400);
    expect(((await response.json()) as { error: string }).error).toMatch(/at least one valid critical resource/);
  });

  it("rejects a malformed body", async () => {
    const response = await post("not-an-object");
    expect(response.status).toBe(400);
  });

  it("returns 404 for an unknown broadcast ID", async () => {
    const response = await fetch(`${baseUrl}/broadcast/does-not-exist`);
    expect(response.status).toBe(404);
  });

  it("returns the tracked status for a known demo broadcast", async () => {
    const created = (await (await post({ items: ["Ventilators"] })).json()) as { broadcastId: string };
    const response = await fetch(`${baseUrl}/broadcast/${created.broadcastId}`);
    expect(response.status).toBe(200);
    const body = (await response.json()) as { broadcastId: string; demoMode: boolean };
    expect(body.broadcastId).toBe(created.broadcastId);
    expect(body.demoMode).toBe(true);
  });
});

describe("SOS broadcast router (live network gate)", () => {
  it("refuses to contact the live hospital network without administrator sign-in", async () => {
    process.env.EMERGENCY_NETWORK_API_URL = "http://127.0.0.1:9/unreachable";
    const response = await post({ items: ["ICU Beds"] });
    expect(response.status).toBe(401);
    expect(((await response.json()) as { error: string }).error).toMatch(/Administrator sign-in is required/);
  });
});
