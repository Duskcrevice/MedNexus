import { randomUUID } from "node:crypto";
import { Router, type Request, type Response } from "express";
import { sdk } from "./sdk";

type ShortageItem = "ICU Beds" | "Oxygen Cylinders" | "Blood Units" | "Ventilators";
type BroadcastStatus = "broadcasting" | "searching" | "offers_received" | "complete";

interface AidOffer {
  id: string;
  hospital: string;
  item: ShortageItem;
  quantity: number;
  unit: string;
  etaMinutes: number;
  status: string;
}

interface BroadcastRecord {
  id: string;
  items: ShortageItem[];
  createdAt: number;
  demoMode: boolean;
  externalId?: string;
}

interface BroadcastSnapshot {
  broadcastId: string;
  status: BroadcastStatus;
  demoMode: boolean;
  offers: AidOffer[];
  message: string;
  isFinal: boolean;
}

type JsonObject = Record<string, unknown>;

const allowedItems = new Set<ShortageItem>([
  "ICU Beds",
  "Oxygen Cylinders",
  "Blood Units",
  "Ventilators",
]);
const records = new Map<string, BroadcastRecord>();
const requestsByIp = new Map<string, { startedAt: number; count: number }>();
const recordRetentionMs = 60 * 60 * 1000;
const rateWindowMs = 60 * 1000;
const maxBroadcastsPerWindow = 15;
export const emergencyRouter = Router();

function isObject(value: unknown): value is JsonObject {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function networkBaseUrl(): string | null {
  const value = process.env.EMERGENCY_NETWORK_API_URL?.trim();
  return value ? `${value.replace(/\/+$/, "")}/` : null;
}

function networkHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json", Accept: "application/json" };
  const token = process.env.EMERGENCY_NETWORK_API_TOKEN?.trim();
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}

async function parseResponse(response: globalThis.Response): Promise<JsonObject> {
  const text = await response.text();
  if (!text) return {};
  try {
    const parsed: unknown = JSON.parse(text);
    return isObject(parsed) ? parsed : {};
  } catch {
    throw new Error("The hospital network returned an unreadable response.");
  }
}

function asShortageItem(value: unknown): ShortageItem | null {
  return typeof value === "string" && allowedItems.has(value as ShortageItem)
    ? (value as ShortageItem)
    : null;
}

function normalizeOffers(value: unknown): AidOffer[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((entry, index) => {
    if (!isObject(entry)) return [];
    const item = asShortageItem(entry.item);
    const hospital = typeof entry.hospital === "string" ? entry.hospital.trim().slice(0, 120) : "";
    const quantity = Number(entry.quantity);
    const etaMinutes = Number(entry.etaMinutes);
    if (!item || !hospital || !Number.isFinite(quantity) || quantity < 1) return [];
    return [{
      id: typeof entry.id === "string" ? entry.id.slice(0, 100) : `network-offer-${index + 1}`,
      hospital,
      item,
      quantity: Math.min(Math.floor(quantity), 9999),
      unit: typeof entry.unit === "string" ? entry.unit.slice(0, 30) : "units",
      etaMinutes: Number.isFinite(etaMinutes) ? Math.max(0, Math.min(Math.floor(etaMinutes), 9999)) : 0,
      status: typeof entry.status === "string" ? entry.status.slice(0, 40) : "Aid offer",
    }];
  });
}

function remoteStatus(value: unknown, offers: AidOffer[]): BroadcastStatus {
  if (value === "complete") return "complete";
  if (value === "offers_received" || offers.length > 0) return "offers_received";
  if (value === "searching") return "searching";
  return "broadcasting";
}

function snapshotFromRemote(record: BroadcastRecord, payload: JsonObject): BroadcastSnapshot {
  const offers = normalizeOffers(payload.offers);
  const status = remoteStatus(payload.status, offers);
  return {
    broadcastId: record.id,
    status,
    demoMode: false,
    offers,
    message: "Broadcast routed through the configured hospital network.",
    isFinal: payload.isFinal === true || status === "complete",
  };
}

function demoOffers(record: BroadcastRecord, elapsedMs: number): AidOffer[] {
  const units: Record<ShortageItem, string> = {
    "ICU Beds": "beds",
    "Oxygen Cylinders": "cylinders",
    "Blood Units": "units",
    Ventilators: "ventilators",
  };
  const offers: AidOffer[] = [];
  if (elapsedMs >= 3500) {
    const item = record.items[0];
    offers.push({
      id: `${record.id}-demo-1`,
      hospital: "Northstar General Hospital",
      item,
      quantity: item === "Oxygen Cylinders" ? 8 : 3,
      unit: units[item],
      etaMinutes: 12,
      status: "Aid offer",
    });
  }
  if (elapsedMs >= 9000) {
    const item = record.items[1] ?? record.items[0];
    offers.push({
      id: `${record.id}-demo-2`,
      hospital: "Riverside Medical Centre",
      item,
      quantity: item === "ICU Beds" ? 1 : 4,
      unit: units[item],
      etaMinutes: 24,
      status: "Transfer offer",
    });
  }
  return offers;
}

function demoSnapshot(record: BroadcastRecord): BroadcastSnapshot {
  const elapsedMs = Date.now() - record.createdAt;
  const offers = demoOffers(record, elapsedMs);
  const isFinal = elapsedMs >= 15000;
  const status: BroadcastStatus = isFinal
    ? "complete"
    : offers.length > 0
      ? "offers_received"
      : elapsedMs >= 1200
        ? "searching"
        : "broadcasting";
  return {
    broadcastId: record.id,
    status,
    demoMode: true,
    offers,
    message: "Demo mode: these simulated aid offers were not sent to real hospitals.",
    isFinal,
  };
}

function sendError(res: Response, status: number, message: string) {
  return res.status(status).json({ error: message });
}

function pruneExpiredRecords(now = Date.now()) {
  for (const [id, record] of records) {
    if (now - record.createdAt > recordRetentionMs) records.delete(id);
  }
}

function isWithinBroadcastLimit(req: Request, now = Date.now()): boolean {
  const key = req.ip || req.socket.remoteAddress || "unknown";
  for (const [ip, entry] of requestsByIp) {
    if (now - entry.startedAt >= rateWindowMs) requestsByIp.delete(ip);
  }
  const current = requestsByIp.get(key);
  if (!current || now - current.startedAt >= rateWindowMs) {
    requestsByIp.set(key, { startedAt: now, count: 1 });
    return true;
  }
  if (current.count >= maxBroadcastsPerWindow) return false;
  current.count += 1;
  return true;
}

async function requireNetworkAdministrator(req: Request, res: Response): Promise<boolean> {
  try {
    const user = await sdk.authenticateRequest(req);
    if (user.role !== "admin") {
      sendError(res, 403, "Only a server-authorized hospital administrator can contact the live network.");
      return false;
    }
    return true;
  } catch {
    sendError(res, 401, "Administrator sign-in is required to contact the live hospital network.");
    return false;
  }
}

emergencyRouter.post("/broadcast", async (req: Request, res: Response) => {
  const now = Date.now();
  pruneExpiredRecords(now);
  if (!isWithinBroadcastLimit(req, now)) {
    return sendError(res, 429, "Broadcast request limit reached. Please wait before trying again.");
  }
  const input: unknown = req.body;
  const items = isObject(input) && Array.isArray(input.items)
    ? [...new Set(input.items.map(asShortageItem).filter((item): item is ShortageItem => item !== null))]
    : [];
  if (!items.length) return sendError(res, 400, "Select at least one valid critical resource before broadcasting.");

  const id = randomUUID();
  const baseUrl = networkBaseUrl();
  const record: BroadcastRecord = { id, items, createdAt: Date.now(), demoMode: !baseUrl };

  if (!baseUrl) {
    records.set(id, record);
    return res.status(202).json(demoSnapshot(record));
  }

  if (!(await requireNetworkAdministrator(req, res))) return;

  try {
    const response = await fetch(new URL("broadcasts", baseUrl), {
      method: "POST",
      headers: networkHeaders(),
      body: JSON.stringify({ items, source: "MEDNEXUS AI", broadcastId: id }),
      signal: AbortSignal.timeout(12000),
    });
    const payload = await parseResponse(response);
    if (!response.ok) return sendError(res, 502, "The hospital network did not accept the broadcast. Please retry.");
    const externalId = payload.broadcastId ?? payload.id;
    if (typeof externalId !== "string" || !externalId.trim()) {
      return sendError(res, 502, "The hospital network response did not include a broadcast ID.");
    }
    record.externalId = externalId.trim();
    records.set(id, record);
    return res.status(202).json(snapshotFromRemote(record, payload));
  } catch (error) {
    console.error("[Emergency broadcast] Network adapter request failed:", error instanceof Error ? error.message : "unknown error");
    return sendError(res, 502, "Could not reach the hospital network. Check the adapter and try again.");
  }
});

emergencyRouter.get("/broadcast/:id", async (req: Request, res: Response) => {
  pruneExpiredRecords();
  const record = records.get(req.params.id);
  if (!record) return sendError(res, 404, "This broadcast could not be found. Start a new SOS request.");
  if (record.demoMode) return res.json(demoSnapshot(record));

  if (!(await requireNetworkAdministrator(req, res))) return;

  const baseUrl = networkBaseUrl();
  if (!baseUrl || !record.externalId) return sendError(res, 503, "The hospital network adapter is no longer configured.");
  try {
    const response = await fetch(new URL(`broadcasts/${encodeURIComponent(record.externalId)}`, baseUrl), {
      headers: networkHeaders(),
      signal: AbortSignal.timeout(10000),
    });
    const payload = await parseResponse(response);
    if (!response.ok) return sendError(res, 502, "Could not refresh offers from the hospital network.");
    return res.json(snapshotFromRemote(record, payload));
  } catch (error) {
    console.error("[Emergency broadcast] Offer refresh failed:", error instanceof Error ? error.message : "unknown error");
    return sendError(res, 502, "Could not refresh offers from the hospital network.");
  }
});
