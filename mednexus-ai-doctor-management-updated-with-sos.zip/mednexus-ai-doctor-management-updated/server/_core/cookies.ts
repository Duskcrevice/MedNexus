import type { CookieOptions, Request } from "express";

export function getSessionCookieOptions(req: Request): CookieOptions {
  // Public previews are HTTPS, while direct local HTTP requests need a cookie
  // that curl and local browsers are allowed to store.
  const host = String(req.headers.host || "");
  const isLocalHttp = host.length > 0 && /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host);
  const isHttps = host.length === 0 || (!isLocalHttp && (req.secure || req.headers["x-forwarded-proto"] === "https"));
  return {
    httpOnly: true,
    path: "/",
    sameSite: isHttps ? "none" : "lax",
    secure: isHttps,
  };
}
