import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
import { randomUUID } from "node:crypto";

const require = createRequire(import.meta.url);
const { DatabaseSync } = require("node:sqlite") as { DatabaseSync: new (path: string) => any };

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const dbPath = resolve(process.env.MEDNEXUS_SQLITE_PATH || `${projectRoot}/.data/mednexus.sqlite`);
mkdirSync(dirname(dbPath), { recursive: true });

const sqlite = new DatabaseSync(dbPath);
sqlite.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    open_id TEXT NOT NULL UNIQUE,
    name TEXT,
    email TEXT UNIQUE,
    password_hash TEXT,
    login_method TEXT,
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_signed_in TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS patient_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    open_id TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    phone TEXT,
    preferred_hospital TEXT,
    conditions TEXT,
    medication_allergies TEXT,
    current_medications TEXT,
    surgeries TEXT,
    ongoing_concerns TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS administrators (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS doctors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    department TEXT,
    specialty TEXT,
    qualifications TEXT,
    experience TEXT,
    consultation_fee TEXT,
    working_hours TEXT,
    profile_photo TEXT,
    status TEXT NOT NULL DEFAULT 'pending_setup',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    staff_role TEXT,
    department TEXT,
    assigned_ward TEXT,
    shift TEXT,
    contact_information TEXT,
    status TEXT NOT NULL DEFAULT 'pending_setup',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS doctor_availability (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
    available_date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    UNIQUE(doctor_id, available_date, start_time, end_time)
  );
  CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_user_id INTEGER NOT NULL REFERENCES users(id),
    doctor_id INTEGER NOT NULL REFERENCES doctors(id),
    appointment_at TEXT NOT NULL,
    reason TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'requested',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(doctor_id, appointment_at)
  );
  CREATE TABLE IF NOT EXISTS prescriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    appointment_id INTEGER NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
    patient_user_id INTEGER NOT NULL REFERENCES users(id),
    doctor_id INTEGER NOT NULL REFERENCES doctors(id),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS prescription_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prescription_id INTEGER NOT NULL REFERENCES prescriptions(id) ON DELETE CASCADE,
    medicine_name TEXT NOT NULL,
    dosage TEXT,
    frequency TEXT,
    timing TEXT,
    duration TEXT,
    instructions TEXT
  );
  CREATE TABLE IF NOT EXISTS hospital_beds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ward TEXT NOT NULL,
    bed_number TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'available',
    patient_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL
  );
  CREATE TABLE IF NOT EXISTS room_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    capacity INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS room_bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_category_id INTEGER NOT NULL REFERENCES room_categories(id),
    patient_user_id INTEGER NOT NULL REFERENCES users(id),
    starts_at TEXT NOT NULL,
    ends_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'requested'
  );
  CREATE TABLE IF NOT EXISTS billing_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_user_id INTEGER NOT NULL REFERENCES users(id),
    appointment_id INTEGER REFERENCES appointments(id),
    amount TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'unpaid',
    description TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
try { sqlite.exec("ALTER TABLE patient_profiles ADD COLUMN blood_group TEXT"); } catch {}
try { sqlite.exec("ALTER TABLE patient_profiles ADD COLUMN basic_details TEXT"); } catch {}

const now = () => new Date().toISOString();
const toDate = (value: unknown) => value ? new Date(String(value)) : new Date();

export function sqlitePath() { return dbPath; }

export function sqliteFindUserByEmail(email: string) {
  return sqlite.prepare("SELECT * FROM users WHERE email = ? LIMIT 1").get(email) as any;
}

export function sqliteFindUserByOpenId(openId: string) {
  return sqlite.prepare("SELECT * FROM users WHERE open_id = ? LIMIT 1").get(openId) as any;
}

function mapUser(row: any) {
  if (!row) return undefined;
  return {
    id: Number(row.id), openId: row.open_id, name: row.name, email: row.email,
    passwordHash: row.password_hash, loginMethod: row.login_method,
    role: row.role === "admin" || row.role === "doctor" || row.role === "staff" ? row.role : "user",
    createdAt: toDate(row.created_at), updatedAt: toDate(row.updated_at),
    lastSignedIn: toDate(row.last_signed_in),
  } as any;
}

export function sqliteUserByEmail(email: string) { return mapUser(sqliteFindUserByEmail(email)); }
export function sqliteUserByOpenId(openId: string) { return mapUser(sqliteFindUserByOpenId(openId)); }

export function sqliteCreateUser(input: { openId: string; name: string; email: string; passwordHash: string | null; role?: "user" | "admin" | "doctor" | "staff" }) {
  const timestamp = now();
  sqlite.prepare(`INSERT INTO users (open_id,name,email,password_hash,login_method,role,created_at,updated_at,last_signed_in)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(input.openId, input.name, input.email, input.passwordHash, "password", input.role || "user", timestamp, timestamp, timestamp);
  return sqliteUserByOpenId(input.openId)!;
}

export function sqliteImportDoctors(records: Array<{ name: string; email: string; passwordHash?: string | null; department?: string; specialty?: string; qualifications?: string; experience?: string; consultationFee?: number; workingHours?: string; profilePhoto?: string }>) {
  const imported: any[] = [];
  sqlite.exec("BEGIN IMMEDIATE");
  try {
    for (const record of records) {
      const email = record.email.trim().toLowerCase();
      const existing = sqliteFindUserByEmail(email);
      let userId: number;
      if (existing) {
        if (existing.role !== "doctor") throw new Error(`Email already belongs to a non-doctor account: ${email}`);
        userId = Number(existing.id);
        if (record.passwordHash) sqlite.prepare("UPDATE users SET password_hash=?,updated_at=? WHERE id=?").run(record.passwordHash, now(), userId);
      } else {
        const timestamp = now();
        const result = sqlite.prepare(`INSERT INTO users (open_id,name,email,password_hash,login_method,role,created_at,updated_at,last_signed_in) VALUES (?,?,?,?,?,?,?,?,?)`)
          .run(`local_doctor_${randomUUID()}`, record.name.trim(), email, record.passwordHash || null, "password", "doctor", timestamp, timestamp, timestamp);
        userId = Number(result.lastInsertRowid);
      }
      const prior = sqlite.prepare("SELECT id FROM doctors WHERE lower(email)=? LIMIT 1").get(email) as any;
      if (prior) {
        sqlite.prepare(`UPDATE doctors SET user_id=?,full_name=?,department=?,specialty=?,qualifications=?,experience=?,consultation_fee=?,working_hours=?,profile_photo=? WHERE id=?`)
          .run(userId, record.name, record.department || null, record.specialty || null, record.qualifications || null, record.experience || null, record.consultationFee || 0, record.workingHours || null, record.profilePhoto || null, prior.id);
        if (record.passwordHash) sqlite.prepare("UPDATE doctors SET status='active' WHERE id=?").run(prior.id);
      } else {
        sqlite.prepare(`INSERT INTO doctors (user_id,full_name,email,department,specialty,qualifications,experience,consultation_fee,working_hours,profile_photo,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
          .run(userId, record.name, email, record.department || null, record.specialty || null, record.qualifications || null, record.experience || null, record.consultationFee || 0, record.workingHours || null, record.profilePhoto || null, record.passwordHash ? "active" : "pending", now());
      }
      imported.push({ name: record.name, email, status: record.passwordHash ? "active" : "pending" });
    }
    sqlite.exec("COMMIT");
    return imported;
  } catch (error) {
    sqlite.exec("ROLLBACK");
    throw error;
  }
}

export function sqliteSetDoctorStatus(email: string, status: "pending" | "active" | "suspended") {
  const result = sqlite.prepare("UPDATE doctors SET status=? WHERE lower(email)=lower(?)").run(status, email.trim());
  if (!result.changes) throw new Error("Imported doctor record not found.");
  return sqlite.prepare("SELECT email,full_name,status FROM doctors WHERE lower(email)=lower(?) LIMIT 1").get(email.trim());
}

export function sqliteDeleteDoctor(email: string) {
  const doctor = sqlite.prepare("SELECT user_id FROM doctors WHERE lower(email)=lower(?) LIMIT 1").get(email.trim()) as any;
  if (!doctor) throw new Error("Imported doctor record not found.");
  sqlite.exec("BEGIN IMMEDIATE");
  try {
    sqlite.prepare("DELETE FROM doctors WHERE user_id=?").run(doctor.user_id);
    sqlite.prepare("DELETE FROM users WHERE id=? AND role='doctor'").run(doctor.user_id);
    sqlite.exec("COMMIT");
  } catch (error) { sqlite.exec("ROLLBACK"); throw error; }
  return { email: email.trim().toLowerCase(), deleted: true };
}

export function sqliteDoctorStatus(email: string) {
  const row = sqlite.prepare("SELECT status FROM doctors WHERE lower(email)=lower(?) LIMIT 1").get(email.trim()) as any;
  return row?.status as string | undefined;
}

export function sqliteImportStaff(records: Array<{ name: string; email: string; passwordHash?: string | null }>) {
  const imported: any[] = [];
  const skipped: any[] = [];
  for (const record of records) {
    const email = record.email.trim().toLowerCase();
    const name = record.name.trim();
    if (!name || !email) { skipped.push({ email, reason: "Missing name or email" }); continue; }
    try {
      const existing = sqliteFindUserByEmail(email);
      if (existing && existing.role !== "staff") {
        skipped.push({ email, reason: "Email belongs to another account" });
        continue;
      }
      let userId: number;
      if (existing) {
        userId = Number(existing.id);
        sqlite.prepare("UPDATE users SET name=?,password_hash=COALESCE(?,password_hash),updated_at=? WHERE id=?").run(name, record.passwordHash || null, now(), userId);
      } else {
        const timestamp = now();
        const result = sqlite.prepare(`INSERT INTO users (open_id,name,email,password_hash,login_method,role,created_at,updated_at,last_signed_in) VALUES (?,?,?,?,?,?,?,?,?)`)
          .run(`local_staff_${randomUUID()}`, name, email, record.passwordHash || null, "password", "staff", timestamp, timestamp, timestamp);
        userId = Number(result.lastInsertRowid);
      }
      const prior = sqlite.prepare("SELECT id FROM staff WHERE lower(email)=? LIMIT 1").get(email) as any;
      const status = record.passwordHash ? "active" : "pending_setup";
      if (prior) {
        sqlite.prepare("UPDATE staff SET user_id=?,full_name=?,status=? WHERE id=?").run(userId, name, status, prior.id);
      } else {
        sqlite.prepare("INSERT INTO staff (user_id,full_name,email,status,created_at) VALUES (?,?,?,?,?)").run(userId, name, email, status, now());
      }
      imported.push({ name, email, status });
    } catch (error) {
      skipped.push({ email, reason: error instanceof Error ? error.message : "Could not save row" });
    }
  }
  return { imported, skipped };
}

export function sqliteListStaff() {
  return sqlite.prepare("SELECT id,full_name,email,staff_role,department,assigned_ward,shift,status,created_at FROM staff ORDER BY full_name").all().map((row: any) => ({
    id: Number(row.id), name: row.full_name, email: row.email, staffRole: row.staff_role,
    department: row.department, assignedWard: row.assigned_ward, shift: row.shift,
    status: row.status, createdAt: toDate(row.created_at),
  }));
}

export function sqliteStaffStatus(email: string) {
  const row = sqlite.prepare("SELECT status FROM staff WHERE lower(email)=lower(?) LIMIT 1").get(email.trim()) as any;
  return row?.status as string | undefined;
}

export function sqliteSetStaffAccess(email: string, status: "pending_setup" | "active" | "suspended", passwordHash?: string) {
  const staff = sqlite.prepare("SELECT user_id FROM staff WHERE lower(email)=lower(?) LIMIT 1").get(email.trim()) as any;
  if (!staff) throw new Error("Imported staff record not found.");
  sqlite.prepare("UPDATE staff SET status=? WHERE lower(email)=lower(?)").run(status, email.trim());
  if (passwordHash) sqlite.prepare("UPDATE users SET password_hash=?,updated_at=? WHERE id=? AND role='staff'").run(passwordHash, now(), staff.user_id);
  return sqlite.prepare("SELECT email,full_name,status FROM staff WHERE lower(email)=lower(?) LIMIT 1").get(email.trim());
}

export function sqliteSetUserPassword(email: string, passwordHash: string) {
  sqlite.prepare("UPDATE users SET password_hash=?,updated_at=? WHERE lower(email)=lower(?)").run(passwordHash, now(), email.trim());
}

export function sqliteActiveDoctors() {
  return sqlite.prepare("SELECT id,full_name,email,department,specialty,qualifications,experience,consultation_fee,working_hours,profile_photo FROM doctors WHERE status='active' ORDER BY full_name").all().map((row: any) => ({
    id: String(row.id), name: row.full_name, specialty: row.specialty || row.department || "General Medicine",
    experience: row.experience || "Experience not provided", rating: "—", reviews: "0",
    hospital: "MEDNEXUS AI Hospital", availability: row.working_hours || "By appointment",
    languages: "English, Hindi", image: row.profile_photo || (String(row.specialty || row.department || "").toLowerCase().includes("cardio") ? "/doctor-portraits/elena-fernandez.jpg" : String(row.specialty || "").toLowerCase().includes("pedi") ? "/doctor-portraits/om-mishra.jpg" : String(row.specialty || "").toLowerCase().includes("neuro") ? "/doctor-portraits/michael-darvis.jpg" : "/doctor-portraits/srikant-sharma.jpg"),
  }));
}

export function sqliteProvisionAdministrator(input: { openId: string; name: string; email: string; passwordHash: string; bootstrapSecret: string }) {
  const configuredSecret = process.env.MEDNEXUS_ADMIN_BOOTSTRAP_SECRET;
  if (!configuredSecret || input.bootstrapSecret !== configuredSecret)
    throw new Error("Invalid administrator bootstrap secret.");
  const existingAdmin = Number((sqlite.prepare("SELECT COUNT(*) AS count FROM administrators").get() as any).count);
  if (existingAdmin > 0) throw new Error("Administrator setup has already been completed.");
  const user = sqliteCreateUser({ ...input, role: "admin" });
  sqlite.prepare("INSERT INTO administrators (user_id,email) VALUES (?,?)").run(user.id, input.email);
  return user;
}

export function sqliteRegisterFirstAdministrator(input: { openId: string; name: string; email: string; passwordHash: string }) {
  const user = sqliteCreateUser({ ...input, role: "admin" });
  sqlite.prepare("INSERT INTO administrators (user_id,email) VALUES (?,?)").run(user.id, input.email);
  return user;
}

export function sqliteUpsertUser(input: { openId: string; name?: string | null; email?: string | null; loginMethod?: string | null; role?: "user" | "admin"; lastSignedIn?: Date }) {
  const existing = sqliteFindUserByOpenId(input.openId);
  const timestamp = (input.lastSignedIn || new Date()).toISOString();
  if (!existing) {
    sqlite.prepare(`INSERT INTO users (open_id,name,email,login_method,role,created_at,updated_at,last_signed_in) VALUES (?,?,?,?,?,?,?,?)`)
      .run(input.openId, input.name || null, input.email || null, input.loginMethod || null, input.role || "user", timestamp, timestamp, timestamp);
  } else {
    sqlite.prepare(`UPDATE users SET name=COALESCE(?,name), email=COALESCE(?,email), login_method=COALESCE(?,login_method), role=COALESCE(?,role), updated_at=?, last_signed_in=? WHERE open_id=?`)
      .run(input.name ?? null, input.email ?? null, input.loginMethod ?? null, input.role ?? null, timestamp, timestamp, input.openId);
  }
}

export function sqliteSavePatientProfile(input: { userId: number; openId: string; displayName: string; phone?: string | null; preferredHospital?: string | null; bloodGroup?: string | null; basicDetails?: string | null; conditions?: string | null; medicationAllergies?: string | null; currentMedications?: string | null; surgeries?: string | null; ongoingConcerns?: string | null }) {
  const timestamp = now();
  sqlite.prepare(`INSERT INTO patient_profiles (user_id,open_id,display_name,phone,preferred_hospital,blood_group,basic_details,conditions,medication_allergies,current_medications,surgeries,ongoing_concerns,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(open_id) DO UPDATE SET display_name=excluded.display_name,phone=excluded.phone,preferred_hospital=excluded.preferred_hospital,blood_group=excluded.blood_group,basic_details=excluded.basic_details,conditions=excluded.conditions,medication_allergies=excluded.medication_allergies,current_medications=excluded.current_medications,surgeries=excluded.surgeries,ongoing_concerns=excluded.ongoing_concerns,updated_at=excluded.updated_at`)
    .run(input.userId, input.openId, input.displayName, input.phone || null, input.preferredHospital || null, input.bloodGroup || null, input.basicDetails || null, input.conditions || null, input.medicationAllergies || null, input.currentMedications || null, input.surgeries || null, input.ongoingConcerns || null, timestamp, timestamp);
  return sqliteGetPatientProfile(input.openId);
}

export function sqliteGetPatientProfile(openId: string) {
  const row = sqlite.prepare("SELECT * FROM patient_profiles WHERE open_id = ? LIMIT 1").get(openId) as any;
  if (!row) return undefined;
  return {
    id: Number(row.id), userId: Number(row.user_id), openId: row.open_id,
    displayName: row.display_name, phone: row.phone, preferredHospital: row.preferred_hospital,
    bloodGroup: row.blood_group, basicDetails: row.basic_details,
    conditions: row.conditions, medicationAllergies: row.medication_allergies,
    currentMedications: row.current_medications, surgeries: row.surgeries,
    ongoingConcerns: row.ongoing_concerns, createdAt: toDate(row.created_at), updatedAt: toDate(row.updated_at),
  };
}

export function sqliteGetPatientProfileByUserId(userId: number) {
  const row = sqlite.prepare("SELECT open_id FROM patient_profiles WHERE user_id = ? LIMIT 1").get(userId) as any;
  return row ? sqliteGetPatientProfile(String(row.open_id)) : undefined;
}

export function sqliteHealthCheck() {
  return Number((sqlite.prepare("SELECT COUNT(*) AS count FROM users").get() as any).count);
}
