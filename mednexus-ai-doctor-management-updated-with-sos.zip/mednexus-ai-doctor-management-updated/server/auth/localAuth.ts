import {
  randomBytes,
  randomUUID,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import { eq } from "drizzle-orm";
import { users } from "../../drizzle/schema";
import { getDb } from "../db";
import {
  sqliteCreateUser,
  sqliteUserByEmail,
} from "../localSqlite";

const scrypt = promisify(scryptCallback);
const ADMIN_EMAIL = /^[a-z0-9._%+-]+admin@medicarehospital\.com$/i;

export function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

export function isAdministratorEmail(email: string) {
  return ADMIN_EMAIL.test(normalizeEmail(email));
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [, salt, encoded] = stored.split("$");
  if (!salt || !encoded) return false;
  const expected = Buffer.from(encoded, "hex");
  const actual = (await scrypt(password, salt, expected.length)) as Buffer;
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export async function findLocalUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return sqliteUserByEmail(normalizeEmail(email));
  const rows = await db
    .select()
    .from(users)
    .where(eq(users.email, normalizeEmail(email)))
    .limit(1);
  return rows[0];
}

export async function createPatientAccount(input: {
  name: string;
  email: string;
  password: string;
}) {
  const db = await getDb();
  const email = normalizeEmail(input.email);
  if (isAdministratorEmail(email)) {
    throw new Error("Administrator accounts must be provisioned by the hospital.");
  }
  const existing = await findLocalUserByEmail(email);
  if (existing) throw new Error("An account with this email already exists.");
  const passwordHash = await hashPassword(input.password);
  const openId = `local_${randomUUID()}`;
  if (!db) {
    return sqliteCreateUser({
      openId,
      name: input.name.trim(),
      email,
      passwordHash,
      role: "user",
    });
  }
  await db
    .insert(users)
    .values({
      openId,
      name: input.name.trim(),
      email,
      passwordHash,
      loginMethod: "password",
      role: "user",
      lastSignedIn: new Date(),
    });
  const created = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return created[0];
}

export { isAdministratorEmail as administratorEmailFormat };
