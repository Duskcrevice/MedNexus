import { medicineVerifierRouter } from "./medicineVerifier/router";
import { z } from "zod";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { TRPCError } from "@trpc/server";
import {
  createPatientAccount,
  findLocalUserByEmail,
  hashPassword,
  isAdministratorEmail,
  normalizeEmail,
  verifyPassword,
} from "./auth/localAuth";
import { randomUUID } from "node:crypto";
import { sqliteActiveDoctors, sqliteDeleteDoctor, sqliteDoctorStatus, sqliteImportDoctors, sqliteImportStaff, sqliteListStaff, sqliteProvisionAdministrator, sqliteRegisterFirstAdministrator, sqliteSetDoctorStatus, sqliteSetStaffAccess, sqliteStaffStatus, sqliteSetUserPassword } from "./localSqlite";
import { sdk } from "./_core/sdk";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  acknowledgeAlert,
  createEmergencyRequest,
  getDemoSnapshot,
  resetDemo,
  searchResources,
  transitionRequest,
  verifyMedicine,
} from "./demoStore";
import {
  approveRescue,
  createReferral,
  getInnovationSnapshot,
  resetInnovation,
  simulateDisaster,
  transitionReferral,
} from "./innovationStore";
import {
  applyForStaff,
  bookAppointment,
  cancelAppointment,
  createServiceRequest,
  getPortalSnapshot,
  markNotificationRead,
  registerPatient,
  saveMedicalRecord,
  reviewStaffApplication,
  uploadPrescription,
  updateStaffWorkflow,
} from "./portalStore";

const demoRole = z.enum([
  "public",
  "hospital",
  "pharmacist",
  "coordinator",
  "admin",
]);

export const appRouter = router({
  system: systemRouter,
  admin: router({
    importDoctors: protectedProcedure
      .input(z.object({
        records: z.array(z.object({
          name: z.string().min(2).max(180),
          email: z.string().email().max(320),
          password: z.string().min(8).max(200).optional(),
          department: z.string().max(180).optional(),
          specialty: z.string().max(180).optional(),
          qualifications: z.string().max(500).optional(),
          experience: z.string().max(180).optional(),
          consultationFee: z.number().nonnegative().optional(),
          workingHours: z.string().max(180).optional(),
          profilePhoto: z.string().max(2000000).optional(),
        })).min(1).max(500),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
        const records = await Promise.all(input.records.map(async record => ({ ...record, passwordHash: record.password ? await hashPassword(record.password) : null })));
        return { imported: sqliteImportDoctors(records) };
      }),
    importStaff: protectedProcedure
      .input(z.object({ records: z.array(z.object({ name: z.string().min(1).max(180), email: z.string().email().max(320), password: z.string().min(8).optional() })).min(1).max(500) }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
        const records = await Promise.all(input.records.map(async record => ({ ...record, passwordHash: record.password ? await hashPassword(record.password) : null })));
        return sqliteImportStaff(records);
      }),
    staff: protectedProcedure.query(({ ctx }) => {
      if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
      return sqliteListStaff();
    }),
    setStaffAccess: protectedProcedure
      .input(z.object({ email: z.string().email(), status: z.enum(["pending_setup", "active", "suspended"]), password: z.string().min(8).optional() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
        return sqliteSetStaffAccess(input.email, input.status, input.password ? await hashPassword(input.password) : undefined);
      }),
    setDoctorStatus: protectedProcedure
      .input(z.object({ email: z.string().email(), status: z.enum(["pending", "active", "suspended"]) }))
      .mutation(({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
        return sqliteSetDoctorStatus(input.email, input.status);
      }),
    deleteDoctor: protectedProcedure
      .input(z.object({ email: z.string().email() }))
      .mutation(({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
        return sqliteDeleteDoctor(input.email);
      }),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    register: publicProcedure
      .input(
        z.object({
          name: z.string().min(2).max(180),
          email: z.string().email().max(320),
          password: z.string().min(8).max(200),
          confirmPassword: z.string().min(8).max(200),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (input.password !== input.confirmPassword)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Passwords do not match.",
          });
        let user;
        try {
          user = await createPatientAccount({
            name: input.name,
            email: input.email,
            password: input.password,
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : "";
          if (message.includes("already exists"))
            throw new TRPCError({
              code: "CONFLICT",
              message: "An account already exists. Please sign in instead.",
            });
          if (message.includes("Database is not available"))
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "The account service is temporarily unavailable. Please try again.",
            });
          throw error;
        }
        const token = await sdk.createSessionToken(user.openId, {
          name: user.name ?? "",
          expiresInMs: ONE_YEAR_MS,
        });
        ctx.res.cookie(COOKIE_NAME, token, {
          ...getSessionCookieOptions(ctx.req),
          maxAge: ONE_YEAR_MS,
        });
        return {
          success: true,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          },
        };
      }),
    registerAdministrator: publicProcedure
      .input(z.object({
        name: z.string().min(2).max(180),
        email: z.string().email().max(320),
        password: z.string().min(8).max(200),
        confirmPassword: z.string().min(8).max(200),
      }))
      .mutation(async ({ ctx, input }) => {
        const email = normalizeEmail(input.email);
        if (!isAdministratorEmail(email))
          throw new TRPCError({ code: "BAD_REQUEST", message: "Administrator email must match nameadmin@medicarehospital.com." });
        if (input.password !== input.confirmPassword)
          throw new TRPCError({ code: "BAD_REQUEST", message: "Passwords do not match." });
        try {
          const user = sqliteRegisterFirstAdministrator({
            openId: `local_admin_${randomUUID()}`,
            name: input.name.trim(),
            email,
            passwordHash: await hashPassword(input.password),
          });
          const token = await sdk.createSessionToken(user.openId, { name: user.name ?? "", expiresInMs: ONE_YEAR_MS });
          ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS });
          return { success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
        } catch (error) {
          throw new TRPCError({ code: "CONFLICT", message: error instanceof Error ? error.message : "Administrator account could not be created." });
        }
      }),
    setupAdministrator: publicProcedure
      .input(z.object({
        name: z.string().min(2).max(180),
        email: z.string().email().max(320),
        password: z.string().min(8).max(200),
        confirmPassword: z.string().min(8).max(200),
        bootstrapSecret: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const email = normalizeEmail(input.email);
        if (!isAdministratorEmail(email))
          throw new TRPCError({ code: "BAD_REQUEST", message: "Administrator email must end with admin@medicarehospital.com." });
        if (input.password !== input.confirmPassword)
          throw new TRPCError({ code: "BAD_REQUEST", message: "Passwords do not match." });
        try {
          const user = sqliteProvisionAdministrator({
            openId: `local_admin_${randomUUID()}`,
            name: input.name.trim(),
            email,
            passwordHash: await hashPassword(input.password),
            bootstrapSecret: input.bootstrapSecret,
          });
          const token = await sdk.createSessionToken(user.openId, { name: user.name ?? "", expiresInMs: ONE_YEAR_MS });
          ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: ONE_YEAR_MS });
          return { success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } };
        } catch (error) {
          throw new TRPCError({ code: "FORBIDDEN", message: error instanceof Error ? error.message : "Administrator setup failed." });
        }
      }),
    login: publicProcedure
      .input(
        z.object({
          email: z.string().email().max(320),
          password: z.string().min(1),
          role: z.enum(["patient", "admin", "doctor", "staff"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const email = normalizeEmail(input.email);
        if (input.role === "admin" && !isAdministratorEmail(email))
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              "Administrator email must use the nameadmin@medicarehospital.com format.",
          });
        let user;
        try {
          user = await findLocalUserByEmail(email);
        } catch {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "The account service is temporarily unavailable. Please try again.",
          });
        }
        if (!user)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Account not found. Please create an account.",
          });
        if (input.role === "doctor" || input.role === "staff") {
          const status = input.role === "doctor" ? sqliteDoctorStatus(email) : sqliteStaffStatus(email);
          if (status !== "active" || !user.passwordHash)
            throw new TRPCError({ code: "FORBIDDEN", message: "Your account is pending activation or does not have an administrator-set password." });
        }
        if (!user.passwordHash || !(await verifyPassword(input.password, user.passwordHash)))
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Incorrect email or password.",
          });
        if (input.role === "admin" && user.role !== "admin")
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "This account is not an authorized administrator.",
          });
        if (input.role === "patient" && user.role !== "user")
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Use the administrator sign-in for this account.",
          });
        if (input.role === "doctor" && user.role !== "doctor")
          throw new TRPCError({ code: "FORBIDDEN", message: "This doctor account was not imported and activated by an administrator." });
        if (input.role === "staff" && user.role !== "staff")
          throw new TRPCError({ code: "FORBIDDEN", message: "This staff account was not imported and activated by an administrator." });
        const token = await sdk.createSessionToken(user.openId, {
          name: user.name ?? "",
          expiresInMs: ONE_YEAR_MS,
        });
        ctx.res.cookie(COOKIE_NAME, token, {
          ...getSessionCookieOptions(ctx.req),
          maxAge: ONE_YEAR_MS,
        });
        return {
          success: true,
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          },
        };
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  // Medicine Verifier (MySQL-backed; requires platform sign-in for live data)
  mednexus: medicineVerifierRouter,
  demo: router({
    snapshot: publicProcedure.query(() => getDemoSnapshot()),
    resources: publicProcedure
      .input(
        z
          .object({
            query: z.string().optional(),
            district: z.string().optional(),
            kind: z.string().optional(),
          })
          .optional()
      )
      .query(({ input }) => searchResources(input || {})),
    verifyMedicine: publicProcedure
      .input(
        z.object({
          identifier: z.string().min(1),
          batch: z.string().optional(),
        })
      )
      .mutation(({ input }) => verifyMedicine(input)),
    createRequest: publicProcedure
      .input(
        z.object({
          requester: z.string().min(1),
          resource: z.string().min(1),
          quantity: z.number().positive(),
          unit: z.string().min(1),
          urgency: z.enum(["Critical", "High", "Routine"]),
          note: z.string().optional(),
        })
      )
      .mutation(({ input }) => createEmergencyRequest(input)),
    transitionRequest: publicProcedure
      .input(
        z.object({
          requestId: z.string(),
          action: z.enum([
            "approve",
            "reject",
            "dispatch",
            "receive",
            "cancel",
          ]),
          role: demoRole,
        })
      )
      .mutation(({ input }) => transitionRequest(input)),
    acknowledgeAlert: publicProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) => acknowledgeAlert(input.id)),
    reset: publicProcedure.mutation(() => resetDemo()),
    innovations: publicProcedure.query(() => getInnovationSnapshot()),
    simulateDisaster: publicProcedure
      .input(
        z.object({ scenario: z.string(), severity: z.number().min(0).max(100) })
      )
      .mutation(({ input }) => simulateDisaster(input)),
    createReferral: publicProcedure
      .input(
        z.object({
          origin: z.string().min(1),
          need: z.string().min(1),
          capability: z.string().min(1),
          urgency: z.enum(["Critical", "High", "Routine"]),
        })
      )
      .mutation(({ input }) => createReferral(input)),
    transitionReferral: publicProcedure
      .input(
        z.object({
          id: z.string(),
          status: z.enum(["Accepted", "Declined", "Completed"]),
        })
      )
      .mutation(({ input }) => transitionReferral(input)),
    approveRescue: publicProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) => approveRescue(input)),
    resetInnovations: publicProcedure.mutation(() => resetInnovation()),
  }),
  portal: router({
    activeDoctors: protectedProcedure.query(({ ctx }) => sqliteActiveDoctors()),
    snapshot: protectedProcedure.query(({ ctx }) =>
      getPortalSnapshot(ctx.user)
    ),
    registerPatient: protectedProcedure
      .input(
        z.object({
          displayName: z.string().min(2).max(180),
          phone: z.string().max(40).optional(),
          preferredHospital: z.string().max(180).optional(),
        })
      )
      .mutation(({ ctx, input }) => registerPatient(ctx.user, input)),
    saveMedicalRecord: protectedProcedure
      .input(
        z.object({
          title: z.string().min(2).max(180),
          summary: z.string().min(2).max(6000),
          clinician: z.string().max(180).optional(),
        })
      )
      .mutation(({ ctx, input }) => saveMedicalRecord(ctx.user, input)),
    applyForStaff: protectedProcedure
      .input(
        z.object({
          hospitalName: z.string().min(3).max(180),
          employeeId: z.string().min(3).max(120),
          requestedRole: z.enum([
            "hospital_staff",
            "pharmacist",
            "coordinator",
          ]),
        })
      )
      .mutation(({ ctx, input }) => applyForStaff(ctx.user, input)),
    reviewStaffApplication: protectedProcedure
      .input(
        z.object({
          openId: z.string().min(1),
          status: z.enum(["approved", "rejected", "suspended"]),
          reviewNote: z.string().max(1000).optional(),
        })
      )
      .mutation(({ ctx, input }) => reviewStaffApplication(ctx.user, input)),
    bookAppointment: protectedProcedure
      .input(
        z.object({
          hospitalName: z.string().min(3).max(180),
          clinician: z.string().min(2).max(180),
          appointmentAt: z.string().datetime(),
          reason: z.string().min(5).max(500),
        })
      )
      .mutation(({ ctx, input }) => bookAppointment(ctx.user, input)),
    cancelAppointment: protectedProcedure
      .input(z.object({ appointmentId: z.string().min(1) }))
      .mutation(({ ctx, input }) =>
        cancelAppointment(ctx.user, input.appointmentId)
      ),
    createServiceRequest: protectedProcedure
      .input(
        z.object({
          hospitalName: z.string().min(3).max(180),
          category: z.string().min(2).max(100),
          description: z.string().min(5).max(2000),
        })
      )
      .mutation(({ ctx, input }) => createServiceRequest(ctx.user, input)),
    updateStaffWorkflow: protectedProcedure
      .input(
        z.object({
          type: z.enum(["appointment", "service_request"]),
          id: z.string().min(1),
          status: z.string().min(1),
          note: z.string().max(2000).optional(),
        })
      )
      .mutation(({ ctx, input }) => updateStaffWorkflow(ctx.user, input)),
    uploadPrescription: protectedProcedure
      .input(
        z.object({
          appointmentId: z.string().min(1),
          medication: z.string().min(2).max(180),
          dosage: z.string().min(2).max(180),
          instructions: z.string().min(5).max(2000),
        })
      )
      .mutation(({ ctx, input }) => uploadPrescription(ctx.user, input)),
    markNotificationRead: protectedProcedure
      .input(z.object({ notificationId: z.string().min(1) }))
      .mutation(({ ctx, input }) =>
        markNotificationRead(ctx.user, input.notificationId)
      ),
  }),
});

export type AppRouter = typeof appRouter;
