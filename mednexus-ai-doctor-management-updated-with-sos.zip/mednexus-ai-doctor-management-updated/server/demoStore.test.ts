import { describe, expect, it } from "vitest";
import { isDemoSlotBusy } from "../client/src/lib/demoStore";
import type { DemoStore } from "../client/src/lib/demoStore";

const doctorId = 42;
const day = "2026-10-26";
const time = "12:00";

function storeWith(status?: "Confirmed" | "Pending" | "Completed"): DemoStore {
  return {
    version: 1,
    accounts: [],
    doctors: [{
      id: doctorId,
      name: "Dr. Fictional Test",
      specialty: "Cardiology",
      qualifications: "Fictional",
      experience: "Fictional",
      fee: 0,
      photo: "",
      active: true,
      hours: "09:00–13:00",
      email: "doctor@test.invalid",
      daysOff: [],
      blockedSlots: [],
    }],
    appointments: status ? [{
      id: 1,
      patient: "Demo Patient",
      patientEmail: "patient@test.invalid",
      doctor: "Dr. Fictional Test",
      doctorId,
      specialty: "Cardiology",
      date: day,
      time,
      type: "Online",
      reason: "Fictional test",
      status,
    }] : [],
    prescriptions: [],
    tasks: [],
    bedStatus: "36",
  };
}

describe("isDemoSlotBusy", () => {
  it.each(["Pending", "Confirmed", "Completed"] as const)("blocks an existing %s appointment", status => {
    expect(isDemoSlotBusy(storeWith(status), doctorId, day, time)).toBe(true);
  });

  it("blocks a doctor's day off and individually blocked time", () => {
    const dayOff = storeWith();
    dayOff.doctors[0].daysOff.push(day);
    expect(isDemoSlotBusy(dayOff, doctorId, day, time)).toBe(true);

    const blocked = storeWith();
    blocked.doctors[0].blockedSlots.push(`${day}|${time}`);
    expect(isDemoSlotBusy(blocked, doctorId, day, time)).toBe(true);
  });

  it("allows a different, available date and time", () => {
    expect(isDemoSlotBusy(storeWith(), doctorId, "2026-10-27", "09:00")).toBe(false);
  });
});
