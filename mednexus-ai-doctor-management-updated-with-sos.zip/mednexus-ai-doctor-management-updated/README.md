# MEDNEXUS AI

**One Network. Smarter Healthcare.**

MEDNEXUS AI is a healthcare coordination hackathon prototype built on the existing React, TypeScript, Vite, Express, tRPC, and Drizzle/MySQL project. This update refines the login and Patient Portal presentations while preserving existing server routes, authorization checks, database schema, and workflows.

## Run locally

```bash
pnpm install
pnpm dev
```

The development server listens on port `3000`. `pnpm check` runs TypeScript diagnostics, `pnpm test` runs the automated suite, and `pnpm build` produces the production bundles.

## Two Patient experiences

The welcome page at `/` offers a clearly labelled browser-local fictional demo for Patient, Doctor, Hospital Staff, and Administrator. Seeded Patient/Staff/Administrator accounts are prefilled in the form; Administrator can add a fictional Doctor account or import doctors. The local flow verifies the assigned fictional email/password and retains demo appointments, profiles, prescriptions, photos, and availability in that browser's `localStorage`. Data is editable by the browser user, not shared across devices, and is not secure authentication or production persistence. The optional Full Name and Phone Number fields on the welcome card are not verified or saved by this demo.

The separate `/app/patient` and `/app/staff` routes remain protected by the existing Manus session and server-side role/ownership rules. Patient profile, appointment, cancellation, service-request, medical-history, prescription, and notification procedures remain in the existing tRPC portal. The Patient Portal now includes reference-aligned visual presentation and directory filters that use only current clinician records. In this preview, the Manus identity provider is not configured, so protected sign-in remains unavailable; the route does not simulate login or bypass authorization. If the backend has no clinician records, it presents an honest empty directory state.

## Demo workflows and features

Administrator can create a doctor with an optional profile photograph or import `.csv`, `.xlsx`, or `.xls` rows. Spreadsheet columns include `name`, `specialty`, `qualifications`, `experience`, `email`, `password`, `fee`, `hours`, and optional `photoUrl`. A `photoUrl` is an image URL/data URL; an image file in a spreadsheet is not ingested. Individual doctor photo upload is supported from the Add Doctor form. Import-created credentials are fictional and displayed for the administrator to assign.

Patients can search the current local doctor list by name or specialty, filter by specialty/language/availability, view a selected profile, book online/in-person demo visits, and view their own demo records and prescriptions. The local demo prevents duplicate bookings and respects doctor days off and blocked slots. Doctors see assigned bookings, record consultation notes, save fictional prescriptions, complete visits, and recommend a follow-up; the matching Patient view reflects those updates. These workflows persist only in the same browser profile.

The project retains Medicine Verifier, Report Simplifier, beds/ambulance, bills, reviews, ZAPIA, and the existing security-first portal and innovation workflows. The demo explicitly states when regulatory/pharmacy sources, clinical AI, dispatch, or other live services are not configured. The older operations/integration modules use synthetic data where identified and are not real clinical systems.

## Configuration and security

The original project uses `DATABASE_URL` and Manus authentication/platform configuration when supplied by its managed environment. No new credentials were generated, no secrets were added to client files, and no database schema or existing records were changed for this presentation update. The current preview reports that no Manus identity provider is configured. Do not enter real patient information in the local demo; its role selection is not a production authorization boundary. The local demo is not a substitute for server authentication, organization membership, or protected patient records.

All clinicians, photographs, appointments, consultation notes, prescriptions, and medical text used in the browser-local preview are synthetic. Medicine results do not establish authenticity, inventory, or regulatory status; report text is not clinically interpreted; bed and ambulance values are not live capacity or dispatch.

## Validation and known limitations

- `pnpm check` passed after the login and Patient Portal changes.
- `pnpm test` passed: 5 files, 20 tests.
- `pnpm build` passed. Vite emitted non-blocking advisories about the runtime platform-config script, an unresolved runtime asset path, and a JavaScript chunk above 500 kB.
- Browser review confirmed the split login, the local Patient portal, filtering by doctor name, current profile selection, and the protected route's unavailable-auth gate.
- The authenticated backend portal could not be entered because its identity provider is unconfigured; its mutation workflows were not manually exercised in this preview. Mobile browser rendering was not manually inspected, though responsive styles are included.
- The browser-local demo does not share data across devices. Administrator-created staff login provisioning, binary photo import embedded in spreadsheets, and production medical integrations are not configured.

## Medicine Verifier (dashboard module)

- Route: `/app/medicine-verifier` (Patient and Doctor portals, nav entry "Medicine Verifier").
- tRPC namespace `mednexus.*` (`server/medicineVerifier/`); live data requires platform sign-in and `DATABASE_URL`. Signed out, it shows a clearly labelled fictional test case.
- Tables are additive and prefixed `mv_` (migration `drizzle/0003_medicine_verifier.sql`); existing tables are untouched. Apply with `pnpm db:migrate`.
- Optional: `MANUS_API_URL` / `MANUS_API_KEY` enable the grounded English/Hindi/Hinglish explanation. Medicine identity comes from NIH RxNorm (needs outbound internet from the server).
