CREATE TABLE `mv_care_team_access` (
	`id` int AUTO_INCREMENT NOT NULL,
	`doctorUserId` int NOT NULL,
	`patientProfileId` int NOT NULL,
	`status` enum('active','revoked') NOT NULL DEFAULT 'active',
	`grantedAt` timestamp NOT NULL DEFAULT (now()),
	`revokedAt` timestamp,
	CONSTRAINT `mv_care_team_access_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mv_medicine_references` (
	`id` int AUTO_INCREMENT NOT NULL,
	`medicineName` varchar(180) NOT NULL,
	`genericName` varchar(180),
	`activeIngredients` text,
	`category` varchar(180),
	`commonUses` text,
	`howItWorks` text,
	`commonSideEffects` text,
	`seriousSideEffects` text,
	`longTermPrecautions` text,
	`source` varchar(255) NOT NULL,
	`sourceRetrievedAt` timestamp NOT NULL,
	`externalId` varchar(100),
	`rawEvidence` text,
	CONSTRAINT `mv_medicine_references_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mv_patient_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`displayName` varchar(160) NOT NULL,
	`dateOfBirth` varchar(32),
	`conditions` text,
	`medicationAllergies` text,
	`otherAllergies` text,
	`currentMedications` text,
	`medicalHistory` text,
	`surgeries` text,
	`notes` text,
	`completeness` enum('complete','needs_review','incomplete') NOT NULL DEFAULT 'incomplete',
	`profileVersion` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mv_patient_profiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mv_prescription_medicines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`prescriptionId` int NOT NULL,
	`medicineName` varchar(180) NOT NULL,
	`prescribedStrength` varchar(100),
	`dosageForm` varchar(100),
	`dose` varchar(120),
	`frequency` varchar(120),
	`duration` varchar(120),
	`timing` varchar(160),
	`instructions` text,
	CONSTRAINT `mv_prescription_medicines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mv_prescriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientProfileId` int NOT NULL,
	`doctorUserId` int NOT NULL,
	`status` enum('active','superseded','cancelled') NOT NULL DEFAULT 'active',
	`clinicianNote` text,
	`prescribedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `mv_prescriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mv_verification_findings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportId` int NOT NULL,
	`prescriptionMedicineId` int,
	`findingType` enum('medicine','allergy','condition','interaction','information') NOT NULL,
	`severity` enum('green','yellow','red','grey') NOT NULL,
	`title` varchar(255) NOT NULL,
	`detail` text NOT NULL,
	`evidenceSource` varchar(255),
	`recommendedNextStep` text,
	`acknowledgedAt` timestamp,
	`acknowledgedBy` int,
	CONSTRAINT `mv_verification_findings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mv_verification_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`prescriptionId` int NOT NULL,
	`patientProfileId` int NOT NULL,
	`reportVersion` int NOT NULL DEFAULT 1,
	`status` enum('green','yellow','red','grey') NOT NULL,
	`checksCompleted` int NOT NULL DEFAULT 0,
	`checksTotal` int NOT NULL DEFAULT 0,
	`missingInformation` text,
	`aiExplanation` text,
	`isOutdated` int NOT NULL DEFAULT 0,
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mv_verification_reports_id` PRIMARY KEY(`id`)
);
