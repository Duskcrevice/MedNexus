import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Core OAuth-backed user table. The server role is authoritative for admin access. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const staffApplications = mysqlTable("staff_applications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  applicantName: varchar("applicantName", { length: 180 }).notNull(),
  email: varchar("email", { length: 320 }),
  hospitalName: varchar("hospitalName", { length: 180 }).notNull(),
  employeeId: varchar("employeeId", { length: 120 }).notNull(),
  requestedRole: mysqlEnum("requestedRole", ["hospital_staff", "pharmacist", "coordinator"]).notNull().default("hospital_staff"),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "suspended"]).notNull().default("pending"),
  reviewNote: text("reviewNote"),
  appliedAt: timestamp("appliedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
  reviewedBy: int("reviewedBy"),
});

export const patientProfiles = mysqlTable("patient_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  displayName: varchar("displayName", { length: 180 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  preferredHospital: varchar("preferredHospital", { length: 180 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const appointments = mysqlTable("appointments", {
  id: int("id").autoincrement().primaryKey(),
  patientUserId: int("patientUserId").notNull(),
  patientOpenId: varchar("patientOpenId", { length: 64 }).notNull(),
  hospitalName: varchar("hospitalName", { length: 180 }).notNull(),
  clinician: varchar("clinician", { length: 180 }).notNull(),
  appointmentAt: timestamp("appointmentAt").notNull(),
  reason: varchar("reason", { length: 500 }).notNull(),
  status: mysqlEnum("status", ["requested", "confirmed", "cancelled", "completed"]).notNull().default("requested"),
  staffNote: text("staffNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const serviceRequests = mysqlTable("service_requests", {
  id: int("id").autoincrement().primaryKey(),
  patientUserId: int("patientUserId").notNull(),
  patientOpenId: varchar("patientOpenId", { length: 64 }).notNull(),
  hospitalName: varchar("hospitalName", { length: 180 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", ["submitted", "in_review", "resolved", "closed"]).notNull().default("submitted"),
  staffReply: text("staffReply"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const medicalRecords = mysqlTable("medical_records", {
  id: int("id").autoincrement().primaryKey(),
  patientUserId: int("patientUserId").notNull(),
  patientOpenId: varchar("patientOpenId", { length: 64 }).notNull(),
  hospitalName: varchar("hospitalName", { length: 180 }).notNull(),
  clinician: varchar("clinician", { length: 180 }).notNull(),
  recordType: varchar("recordType", { length: 100 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  summary: text("summary").notNull(),
  recordDate: timestamp("recordDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const prescriptions = mysqlTable("prescriptions", {
  id: int("id").autoincrement().primaryKey(),
  patientUserId: int("patientUserId").notNull(),
  patientOpenId: varchar("patientOpenId", { length: 64 }).notNull(),
  appointmentId: int("appointmentId").notNull(),
  hospitalName: varchar("hospitalName", { length: 180 }).notNull(),
  clinician: varchar("clinician", { length: 180 }).notNull(),
  medication: varchar("medication", { length: 180 }).notNull(),
  dosage: varchar("dosage", { length: 180 }).notNull(),
  instructions: text("instructions").notNull(),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).notNull().default("active"),
  issuedAt: timestamp("issuedAt").defaultNow().notNull(),
  uploadedByUserId: int("uploadedByUserId").notNull(),
  uploadedByOpenId: varchar("uploadedByOpenId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const portalNotifications = mysqlTable("portal_notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  openId: varchar("openId", { length: 64 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const securityAuditLogs = mysqlTable("security_audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId"),
  actorOpenId: varchar("actorOpenId", { length: 64 }),
  action: varchar("action", { length: 120 }).notNull(),
  targetType: varchar("targetType", { length: 80 }),
  targetId: varchar("targetId", { length: 120 }),
  detail: text("detail"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type StaffApplication = typeof staffApplications.$inferSelect;
export type PatientProfile = typeof patientProfiles.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type MedicalRecord = typeof medicalRecords.$inferSelect;
export type Prescription = typeof prescriptions.$inferSelect;
export type PortalNotification = typeof portalNotifications.$inferSelect;
export type SecurityAuditLog = typeof securityAuditLogs.$inferSelect;

// ---- Medicine Verifier (additive; tables are prefixed mv_ to avoid clashing with the portal tables) ----
export const mvPatientProfiles = mysqlTable("mv_patient_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  dateOfBirth: varchar("dateOfBirth", { length: 32 }),
  conditions: text("conditions"),
  medicationAllergies: text("medicationAllergies"),
  otherAllergies: text("otherAllergies"),
  currentMedications: text("currentMedications"),
  medicalHistory: text("medicalHistory"),
  surgeries: text("surgeries"),
  notes: text("notes"),
  completeness: mysqlEnum("completeness", ["complete", "needs_review", "incomplete"]).default("incomplete").notNull(),
  profileVersion: int("profileVersion").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const mvCareTeamAccess = mysqlTable("mv_care_team_access", {
  id: int("id").autoincrement().primaryKey(),
  doctorUserId: int("doctorUserId").notNull(),
  patientProfileId: int("patientProfileId").notNull(),
  status: mysqlEnum("status", ["active", "revoked"]).default("active").notNull(),
  grantedAt: timestamp("grantedAt").defaultNow().notNull(),
  revokedAt: timestamp("revokedAt"),
});

export const mvPrescriptions = mysqlTable("mv_prescriptions", {
  id: int("id").autoincrement().primaryKey(),
  patientProfileId: int("patientProfileId").notNull(),
  doctorUserId: int("doctorUserId").notNull(),
  status: mysqlEnum("status", ["active", "superseded", "cancelled"]).default("active").notNull(),
  clinicianNote: text("clinicianNote"),
  prescribedAt: timestamp("prescribedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const mvPrescriptionMedicines = mysqlTable("mv_prescription_medicines", {
  id: int("id").autoincrement().primaryKey(),
  prescriptionId: int("prescriptionId").notNull(),
  medicineName: varchar("medicineName", { length: 180 }).notNull(),
  prescribedStrength: varchar("prescribedStrength", { length: 100 }),
  dosageForm: varchar("dosageForm", { length: 100 }),
  dose: varchar("dose", { length: 120 }),
  frequency: varchar("frequency", { length: 120 }),
  duration: varchar("duration", { length: 120 }),
  timing: varchar("timing", { length: 160 }),
  instructions: text("instructions"),
});

export const mvMedicineReferences = mysqlTable("mv_medicine_references", {
  id: int("id").autoincrement().primaryKey(),
  medicineName: varchar("medicineName", { length: 180 }).notNull(),
  genericName: varchar("genericName", { length: 180 }),
  activeIngredients: text("activeIngredients"),
  category: varchar("category", { length: 180 }),
  commonUses: text("commonUses"),
  howItWorks: text("howItWorks"),
  commonSideEffects: text("commonSideEffects"),
  seriousSideEffects: text("seriousSideEffects"),
  longTermPrecautions: text("longTermPrecautions"),
  source: varchar("source", { length: 255 }).notNull(),
  sourceRetrievedAt: timestamp("sourceRetrievedAt").notNull(),
  externalId: varchar("externalId", { length: 100 }),
  rawEvidence: text("rawEvidence"),
});

export const mvVerificationReports = mysqlTable("mv_verification_reports", {
  id: int("id").autoincrement().primaryKey(),
  prescriptionId: int("prescriptionId").notNull(),
  patientProfileId: int("patientProfileId").notNull(),
  reportVersion: int("reportVersion").default(1).notNull(),
  status: mysqlEnum("status", ["green", "yellow", "red", "grey"]).notNull(),
  checksCompleted: int("checksCompleted").default(0).notNull(),
  checksTotal: int("checksTotal").default(0).notNull(),
  missingInformation: text("missingInformation"),
  aiExplanation: text("aiExplanation"),
  isOutdated: int("isOutdated").default(0).notNull(),
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
});

export const mvVerificationFindings = mysqlTable("mv_verification_findings", {
  id: int("id").autoincrement().primaryKey(),
  reportId: int("reportId").notNull(),
  prescriptionMedicineId: int("prescriptionMedicineId"),
  findingType: mysqlEnum("findingType", ["medicine", "allergy", "condition", "interaction", "information"]).notNull(),
  severity: mysqlEnum("severity", ["green", "yellow", "red", "grey"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  detail: text("detail").notNull(),
  evidenceSource: varchar("evidenceSource", { length: 255 }),
  recommendedNextStep: text("recommendedNextStep"),
  acknowledgedAt: timestamp("acknowledgedAt"),
  acknowledgedBy: int("acknowledgedBy"),
});

export type MvPatientProfile = typeof mvPatientProfiles.$inferSelect;
export type MvPrescription = typeof mvPrescriptions.$inferSelect;
export type MvPrescriptionMedicine = typeof mvPrescriptionMedicines.$inferSelect;
export type MvVerificationReport = typeof mvVerificationReports.$inferSelect;
export type MvVerificationFinding = typeof mvVerificationFindings.$inferSelect;
