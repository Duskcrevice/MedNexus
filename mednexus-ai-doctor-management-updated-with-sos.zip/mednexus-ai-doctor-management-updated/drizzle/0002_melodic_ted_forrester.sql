CREATE TABLE `medical_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientUserId` int NOT NULL,
	`patientOpenId` varchar(64) NOT NULL,
	`hospitalName` varchar(180) NOT NULL,
	`clinician` varchar(180) NOT NULL,
	`recordType` varchar(100) NOT NULL,
	`title` varchar(180) NOT NULL,
	`summary` text NOT NULL,
	`recordDate` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `medical_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `prescriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientUserId` int NOT NULL,
	`patientOpenId` varchar(64) NOT NULL,
	`appointmentId` int NOT NULL,
	`hospitalName` varchar(180) NOT NULL,
	`clinician` varchar(180) NOT NULL,
	`medication` varchar(180) NOT NULL,
	`dosage` varchar(180) NOT NULL,
	`instructions` text NOT NULL,
	`status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
	`issuedAt` timestamp NOT NULL DEFAULT (now()),
	`uploadedByUserId` int NOT NULL,
	`uploadedByOpenId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `prescriptions_id` PRIMARY KEY(`id`)
);
